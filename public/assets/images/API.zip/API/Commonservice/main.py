from fastapi import FastAPI, HTTPException,Request, File, UploadFile
from fastapi.responses import StreamingResponse
import io
import numpy as np
import faiss
from pydantic import BaseModel
from dotenv import load_dotenv
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from typing import List, Tuple, Union, Optional, Dict, Any
import os
import json
from enum import Enum
import logging
import openai
from openai import AzureOpenAI
import re
import psycopg2.extras
import psycopg2
import numpy as np
import os
import numpy as np


# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI()

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)
    
load_dotenv()

os.environ["OPENAI_API_KEY"] = os.getenv("OPENAI_API_KEY")
os.environ["AZURE_API_KEY"] = os.getenv("OPENAI_API_KEY")
os.environ["AZURE_API_BASE"] = os.getenv("OPENAI_DEPLOYMENT_ENDPOINT")
os.environ["AZURE_API_VERSION"] = "2025-01-01-preview"



openai.api_type = os.getenv("OPENAI_API_TYPE", "azure")
openai.api_base = os.getenv("OPENAI_DEPLOYMENT_ENDPOINT")
openai.api_version = os.getenv("OPENAI_DEPLOYMENT_VERSION", "2023-07-01-preview")
openai.api_key = os.getenv("OPENAI_API_KEY")
AZURE_DEPLOYMENT_NAME = os.getenv("OPENAI_DEPLOYMENT_NAME")
AZURE_OPENAI_VERSION = os.getenv("OPENAI_API_VERSION", "2023-05-15")

# AzureOpenAI client
client = AzureOpenAI(
    api_key=openai.api_key,
    api_version=AZURE_OPENAI_VERSION,
    azure_endpoint=openai.api_base
)




# Configuration
class Config:
    MODEL_NAME = "azure/iic-gpt-4.1"
    AZURE_API_KEY="BeAtRq9WxQQoV7a3Ul3t5AxZKNb0vB5VlsyS6cOiWiHW2ZQbrXavJQQJ99BEACHYHv6XJ3w3AAAAACOGPVX2"
    AZURE_API_BASE="https://sridh-maclmc4d-eastus2.openai.azure.com/"
    AZURE_API_VERSION="2025-01-01-preview"


# DB configuration
DB_HOST = "10.1.0.6"
DB_PORT = 5432
DB_USER = "ailevate"
DB_PASS = "ail3v@teu$er"
DB_NAME = "ExcelschoolAI"

def get_db_connection():
    return psycopg2.connect(
        host=DB_HOST,
        port=DB_PORT,
        database=DB_NAME,
        user=DB_USER,
        password=DB_PASS
    )


def get_exceschoolai_db_connection():
    connection = psycopg2.connect(
        dbname="ExcelschoolAI",
        user="ailevate",
        password="ail3v@teu$er",
        host="10.1.0.6",
        port=5432
    )
    return connection


class UserCredentials(BaseModel):
    username: str
    password: str
    
class ResponseStatus(BaseModel):
    status: str
    usercode: str = None
    custcode: str = None
    orgcode: str = None
    username: str = None
    userrole: str = None

# API endpoint to check user credentials
@app.post("/ExcelSchoolAI/Service/CommonService/check-user", response_model=ResponseStatus)
async def check_user(credentials: UserCredentials):
    conn = None
    try:
        conn = get_exceschoolai_db_connection()
        with conn.cursor() as cur:
            refcursor_name = 's'
            cur.execute("BEGIN;")
            cur.execute("""
                CALL admin.uspcheckuser(
                    %s, %s, NULL, %s
                );
            """, (
                credentials.username,
                credentials.password,
                refcursor_name
            ))

            # Fetch the data from the refcursor
            cur.execute(f"FETCH ALL FROM {refcursor_name};")
            result = cur.fetchall()

            # Check if result is empty or not
            if result:
                user_info = result[0]  
                
                usercode, custcode, orgcode, username, userrole = user_info

                return ResponseStatus(
                    status="S001",
                    usercode=usercode,
                    custcode=custcode,
                    orgcode=orgcode,
                    username=username,
                    userrole=userrole
                )
            else:
                return ResponseStatus(status="F001")

    except psycopg2.Error as e:
        if conn:
            conn.rollback()
        raise HTTPException(status_code=500, detail=f"Database error: {e}")
    
    finally:
        if conn:
            conn.commit()
            conn.close()

@app.get("/ExcelSchoolAI/Service/CommonService/get_classes")
def get_classes(par_custcode: str, par_orgcode: str, param: int = 1):
    try:
        conn = get_exceschoolai_db_connection()
        cursor = conn.cursor()
        
        ref_cursor_name = "class_cursor"
        cursor.execute("CALL admin.uspclass(%s::refcursor, %s, %s, %s::integer);", 
                      (ref_cursor_name, par_custcode, par_orgcode, param))
        
        fetch_cursor = conn.cursor(ref_cursor_name)
        classes = fetch_cursor.fetchall()
        
        colnames = [desc[0] for desc in fetch_cursor.description]
        result = [dict(zip(colnames, row)) for row in classes]
        fetch_cursor.close()
        cursor.close()
        conn.close()
    
        return result
    except psycopg2.Error as e:
        logger.error(f"Database error in get_classes: {e}")
        raise HTTPException(status_code=500, detail=f"Database error: {e}")
    except Exception as e:
        logger.error(f"Unexpected error in get_classes: {e}")
        raise HTTPException(status_code=500, detail=f"An unexpected error occurred: {e}")        
 
 
@app.get("/ExcelSchoolAI/Service/CommonService/get_subject")
def get_subjects(par_custcode: str, par_orgcode: str, classid: int):
    try:
        conn = get_exceschoolai_db_connection()
        cursor = conn.cursor()
        
        ref_cursor_name = "subject_cursor"
        cursor.execute(f"CALL admin.uspgetsubject(%s, %s, %s, '{ref_cursor_name}');", 
                      (par_custcode, par_orgcode, classid))
        
        fetch_cursor = conn.cursor(ref_cursor_name)
        classes = fetch_cursor.fetchall()
        
        colnames = [desc[0] for desc in fetch_cursor.description]
        result = [dict(zip(colnames, row)) for row in classes]
        fetch_cursor.close()
        cursor.close()
        conn.close()
    
        return result
    except psycopg2.Error as e:
        logger.error(f"Database error in get_subjects: {e}")
        raise HTTPException(status_code=500, detail=f"Database error: {e}")
    except Exception as e:
        logger.error(f"Unexpected error in get_subjects: {e}")
        raise HTTPException(status_code=500, detail=f"An unexpected error occurred: {e}")
     
     
@app.get("/ExcelSchoolAI/Service/CommonService/get_year")
def get_year(par_custcode: str, par_orgcode: str):
    try:
        conn = get_exceschoolai_db_connection()
        cursor = conn.cursor()
        
        ref_cursor_name = "year_cursor"
        cursor.execute(f"CALL admin.uspgetyear(%s, %s, '{ref_cursor_name}');", 
                      (par_custcode, par_orgcode))
        
        fetch_cursor = conn.cursor(ref_cursor_name)
        classes = fetch_cursor.fetchall()
        
        colnames = [desc[0] for desc in fetch_cursor.description]
        result = [dict(zip(colnames, row)) for row in classes]
        fetch_cursor.close()
        cursor.close()
        conn.close()
    
        return result
    except psycopg2.Error as e:
        logger.error(f"Database error in get_year: {e}")
        raise HTTPException(status_code=500, detail=f"Database error: {e}")
    except Exception as e:
        logger.error(f"Unexpected error in get_year: {e}")
        raise HTTPException(status_code=500, detail=f"An unexpected error occurred: {e}")
        
  
@app.get("/ExcelSchoolAI/Service/CommonService/get_chapters")
def get_chapters(par_custcode: str, par_orgcode: str, classid: int, subjectid: int):
    try:
        conn = get_exceschoolai_db_connection()
        cursor = conn.cursor()
        
        ref_cursor_name = "chapter_cursor"
        cursor.execute(f"CALL admin.uspgetchapter(%s, %s, %s, %s, '{ref_cursor_name}');", 
                      (par_custcode, par_orgcode, classid, subjectid))
        
        fetch_cursor = conn.cursor(ref_cursor_name)
        classes = fetch_cursor.fetchall()
        
        colnames = [desc[0] for desc in fetch_cursor.description]
        result = [dict(zip(colnames, row)) for row in classes]
        fetch_cursor.close()
        cursor.close()
        conn.close()
    
        return result
    except psycopg2.Error as e:
        logger.error(f"Database error in get_chapters: {e}")
        raise HTTPException(status_code=500, detail=f"Database error: {e}")
    except Exception as e:
        logger.error(f"Unexpected error in get_chapters: {e}")
        raise HTTPException(status_code=500, detail=f"An unexpected error occurred: {e}")        
        

if __name__ == "__main__":
    import uvicorn
    # uvicorn.run(app, host="0.0.0.0", port=8060)
    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("FLASK_RUN_PORT_commonservice", 8069)))
