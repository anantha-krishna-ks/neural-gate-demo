import os
import re
import fitz  # PyMuPDF
import psycopg2
import psycopg2.extras
import pdfplumber
import easyocr
import tempfile, os, zipfile, io, shutil
import pandas as pd
from typing import List, Tuple, Union, Optional, Dict, Any
from fastapi import FastAPI, File, Form, UploadFile, HTTPException, Query, Body
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv
from datetime import datetime
import numpy as np
from PIL import Image
from langchain_community.document_loaders import PyMuPDFLoader
from langchain.docstore.document import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter

from langchain.chains import RetrievalQA
from langchain.chains.question_answering import load_qa_chain
from langchain.chains import ConversationalRetrievalChain
from langchain.prompts import PromptTemplate
from langchain_community.vectorstores import FAISS
from langchain_community.document_loaders import PyPDFLoader
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_openai import AzureOpenAIEmbeddings

from pydantic import BaseModel
from psycopg2.extras import RealDictCursor
from openai import AzureOpenAI
import json
import logging
import uvicorn
from starlette.status import HTTP_500_INTERNAL_SERVER_ERROR, HTTP_200_OK, HTTP_400_BAD_REQUEST
from pathlib import Path
import hashlib
from fastapi import APIRouter
 
 



# Load env variables
load_dotenv()

# FastAPI app init
app = FastAPI()

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Database config
DB_PARAMS = {
    'dbname': os.getenv("DB_NAME", "ExcelschoolAI"),
    'user': os.getenv("DB_USER", "ailevate"),
    'password': os.getenv("DB_PASS", "ail3v@teu$er"),
    'host': os.getenv("DB_HOST", "10.1.0.6"),
    'port': int(os.getenv("DB_PORT", 5432))
}

# CORS setup
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Azure Configuration
AZURE_OPENAI_KEY = "BeAtRq9WxQQoV7a3Ul3t5AxZKNb0vB5VlsyS6cOiWiHW2ZQbrXavJQQJ99BEACHYHv6XJ3w3AAAAACOGPVX2"
AZURE_ENDPOINT = "https://sridh-maclmc4d-eastus2.openai.azure.com/"
DEPLOYMENT_NAME = "gpt-4.1"
API_VERSION = "2025-01-01-preview"


# Initialize the Azure OpenAI client
# client = AzureOpenAI(
    # api_key=AZURE_OPENAI_KEY,
    # api_version=API_VERSION,
    # azure_endpoint=AZURE_ENDPOINT
# )

client = AzureOpenAI(
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    api_version=os.getenv("AZURE_OPENAI_API_VERSION")
)

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

 
DB_HOST = "10.1.0.6"
DB_PORT = 5432
DB_NAME = "ExcelschoolAI"
LPDB_NAME = "Lessonplan"
DB_USER = "ailevate"
DB_PASS = "ail3v@teu$er"
def get_db_connection():
    conn = psycopg2.connect(
        host=DB_HOST,
        port=DB_PORT,
        database=DB_NAME,
        user=DB_USER,
        password=DB_PASS
    )
    return conn
    
def get_LPdb_connection():
    LPconn = psycopg2.connect(
        host=DB_HOST,
        port=DB_PORT,
        database=LPDB_NAME,
        user=DB_USER,
        password=DB_PASS
    )
    return LPconn

def get_exceschoolai_db_connection():
    connection = psycopg2.connect(
        dbname="ExcelschoolAI",
        user="postgres",
        password="AI@POC",
        host="13.232.72.78",
        port=5432
    )
    return connection

# Detect question type
def detect_question_type(text: str) -> str:
    text = text.lower()
    if "assertion" in text and "reason" in text:
        return "Assertion-Reason"
    elif any(opt in text for opt in ["(a)", "(b)", "(c)", "(d)"]):
        return "MCQ"
    elif "fill in the blank" in text or "___" in text:
        return "Fill in the Blanks"
    elif len(text) < 100:
        return "Very Short Answer"
    elif len(text) < 200:
        return "Short Answer"
    else:
        return "Long Answer"


# Extract questions from PDF
def extract_questions_from_pdf(pdf_path: str) -> List[dict]:
    import re
    questions = []

    with pdfplumber.open(pdf_path) as pdf:
        full_text = ""
        for page in pdf.pages:
            page_text = page.extract_text()
            if page_text:
                full_text += "\n" + page_text

    # Normalize
    full_text = re.sub(r'\s+', ' ', full_text)  # Collapse all whitespace
    full_text = re.sub(r'(?<=\d)\s+(?=[a-d]\))', '\n', full_text)  # Start new lines before options
    full_text = re.sub(r'(?<=[a-d]\))\s+(?=[a-d]\))', '\n', full_text)  # Ensure options split

    # Split by question numbers (e.g., 1., 2., 3.)
    raw_questions = re.split(r'\s(?=\d{1,2}[.)]\s)', full_text)

    for raw_q in raw_questions:
        raw_q = raw_q.strip()
        if len(raw_q) < 20:
            continue

        q_type = detect_question_type(raw_q)
        marks = guess_marks_from_type(q_type)

        questions.append({
            "text": raw_q,
            "type": q_type,
            "marks": marks
        })

    return questions

def detect_question_type(text: str) -> str:
    t = text.lower()
    if "assertion" in t and "reason" in t:
        return "Assertion-Reason"
    elif all(opt in t for opt in ["a)", "b)", "c)", "d)"]):
        return "MCQ"
    elif "fill in the blank" in t or "___" in t:
        return "Fill in the Blanks"
    elif len(t) > 300:
        return "Long Answer"
    elif len(t) > 150:
        return "Short Answer"
    elif len(t) < 100:
        return "Very Short Answer"
    return "Short Answer"

def guess_marks_from_type(q_type: str) -> int:
    return {
        "MCQ": 1,
        "Assertion-Reason": 1,
        "Very Short Answer": 2,
        "Short Answer": 3,
        "Long Answer": 5,
        "Fill in the Blanks": 1
    }.get(q_type, 2)


# Extract tables
def extract_tables_from_pdf(pdf_path):
    tables = []
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            for table in page.extract_tables():
                df = pd.DataFrame(table[1:], columns=table[0])
                tables.append({
                    "text": f"\nTABLE:\n{df.to_markdown(index=False)}",
                    "type": "Table"
                })
    return tables

# Save to DB
def save_questions_to_db(questions: List[dict], class_id: int, subject: str, chapter: str, year: int, source: str):
    conn = psycopg2.connect(**DB_PARAMS)
    cur = conn.cursor()
    for q in questions:
        cur.execute("""
            INSERT INTO public.tblquestiondetails (classid, subjectid, chapterid, yearid, questiontext, questiontypeid)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (class_id, subject, chapter, year, q['text'], q['type']))
    conn.commit()
    cur.close()
    conn.close()



# Extract tables
def vector_extract_tables_from_pdf(pdf_path):
    tables = []
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            for table in page.extract_tables():
                df = pd.DataFrame(table[1:], columns=table[0])
                tables.append(f"\n\nTABLE:\n{df.to_markdown(index=False)}\n\n")
    return tables

# Extract image text
def vector_extract_images_from_pdf(pdf_path):
    reader = easyocr.Reader(['en'], gpu=False)
    doc = fitz.open(pdf_path)
    image_texts = []
    for page_index in range(len(doc)):
        page = doc[page_index]
        images = page.get_images(full=True)
        for img_index, img in enumerate(images):
            xref = images[img_index][0]
            base_image = doc.extract_image(xref)
            image_bytes = base_image["image"]
            image = Image.open(io.BytesIO(image_bytes)).convert("RGB")
            result = reader.readtext(np.array(image), detail=0)
            if result:
                image_texts.append(f"\n\nIMAGE TEXT:\n{' '.join(result)}\n\n")
    return image_texts

# Process single PDF
def vector_process_pdf(pdf_path):
    docs = []
    loader = PyMuPDFLoader(pdf_path)
    docs.extend(loader.load())

    for table in vector_extract_tables_from_pdf(pdf_path):
        docs.append(Document(page_content=table, metadata={"source": pdf_path, "page": 0}))

    for image_text in vector_extract_images_from_pdf(pdf_path):
        docs.append(Document(page_content=image_text, metadata={"source": pdf_path, "page": 0}))

    return docs


@app.post("/ExcelSchoolAI/ExamPrep/upload-pdf-rag")
async def upload_pdf_rag(
    file: UploadFile = File(...),
    class_id: str = Form(...),
    subject: str = Form(...),
    year: str = Form(...)
):
    try:
        temp_dir = "./temp_uploads"
        os.makedirs(temp_dir, exist_ok=True)
        all_docs = []

        # Read file once
        contents = await file.read()

        # Save paths
        db_dir = f"./dbs/{class_id}/{subject}/{year}"
        os.makedirs(db_dir, exist_ok=True)

        # Process ZIP
        if zipfile.is_zipfile(io.BytesIO(contents)):
            with zipfile.ZipFile(io.BytesIO(contents)) as zip_ref:
                for name in zip_ref.namelist():
                    if name.lower().endswith(".pdf"):
                        pdf_bytes = zip_ref.read(name)
                        path = os.path.join(temp_dir, os.path.basename(name))
                        with open(path, "wb") as f:
                            f.write(pdf_bytes)
                        all_docs.extend(vector_process_pdf(path))
        elif file.filename.lower().endswith(".pdf"):
            path = os.path.join(temp_dir, file.filename)
            with open(path, "wb") as f:
                f.write(contents)
            all_docs.extend(vector_process_pdf(path))
        else:
            raise HTTPException(400, "Unsupported file type. Please upload PDF or ZIP.")

        # Text splitter
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200,
            separators=["\n\n", "\n", " ", ""]
        )
        split_docs = text_splitter.split_documents(all_docs)

       
        embeddings = AzureOpenAIEmbeddings(
                    azure_deployment=os.getenv("AZURE_OPENAI_ADA_EMBEDDING_DEPLOYMENT_NAME"),
                    model=os.getenv("AZURE_OPENAI_ADA_EMBEDDING_MODEL_NAME"),
                    azure_endpoint=os.getenv("AZURE_OPENAI_DEPLOYMENT_ENDPOINT"),
                    openai_api_version=os.getenv("AZURE_OPENAI_DEPLOYMENT_VERSION"),
                    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
                    chunk_size=1000
                )


        vectorstore = FAISS.from_documents(split_docs, embeddings)
        vectorstore.save_local(db_dir)

        return {
            "status": "success",
            "message": f"{len(split_docs)} chunks processed and saved in {db_dir}"
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)

# Upload API
@app.post("/ExcelSchoolAI/ExamPrep/upload-previous-year-papers")
def upload_previous_papers(
    file: UploadFile = File(...),
    class_id: int = Form(...),
    subject: str = Form(...),
    chapter: str = Form(...),
    year: int = Form(...),
    source: str = Form(...)
):
    try:
        # Save file temporarily
        temp_dir = tempfile.gettempdir()
        temp_path = os.path.join(temp_dir, file.filename)
        with open(temp_path, "wb") as f:
            f.write(file.file.read())

        # Extract content
        questions = extract_questions_from_pdf(temp_path)
        questions += extract_tables_from_pdf(temp_path)

        # Save to DB
        save_questions_to_db(questions, class_id, subject, chapter, year, source)

        return JSONResponse(content={
            "message": f"{len(questions)} questions saved.",
            "sample_questions": questions[:3]
        }, status_code=200)

    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})




# Endpoint
@app.post("/ExcelSchoolAI/ExamPrep/generate-chapter-taxonomy")
async def generate_chapter_taxonomy(classid: int, subjectid: int, yearid: str, book_path: str):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        
         # Call the stored procedure with proper type casting
        cursor.execute("""CALL examprep.uspgetsquestiondata(
            %s::bigint,
            %s::bigint,
            %s::character varying,
            %s::refcursor
        )
        """, (classid, subjectid, yearid, 'questiondetails'))

        cursor.execute('FETCH ALL IN "questiondetails"')
        question_results = cursor.fetchall()
        question_column_names = [desc[0] for desc in cursor.description]
        question_rows = [dict(zip(question_column_names, row)) for row in question_results]
        
        
        # --- Get chapters ---
        cursor.execute("""CALL admin.uspgetchapter(
            %s::int,
            %s::int,
            %s::refcursor
        )
        """, (classid, subjectid, 'chapterdetails'))

        cursor.execute('FETCH ALL IN "chapterdetails"')
        chapter_results = cursor.fetchall()
        chapter_column_names = [desc[0] for desc in cursor.description]
        chapter_rows = [dict(zip(chapter_column_names, row)) for row in chapter_results]
       
        # --- Get taxonomy ---
       
        cursor.execute("CALL examprep.uspgettaxonomy(%s)", ('taxonomydetails',))
        cursor.execute('FETCH ALL IN "taxonomydetails"')
        taxonomy_results = cursor.fetchall()
        taxonomy_column_names = [desc[0] for desc in cursor.description]
        taxonomy_rows = [dict(zip(taxonomy_column_names, row)) for row in taxonomy_results]

        # --- Prepare vector store ---
        embeddings = AzureOpenAIEmbeddings(
            azure_deployment=os.getenv("AZURE_OPENAI_ADA_EMBEDDING_DEPLOYMENT_NAME"),
            model=os.getenv("AZURE_OPENAI_ADA_EMBEDDING_MODEL_NAME"),
            azure_endpoint=os.getenv("AZURE_OPENAI_DEPLOYMENT_ENDPOINT"),
            openai_api_version=os.getenv("AZURE_OPENAI_DEPLOYMENT_VERSION"),
            api_key=os.getenv("AZURE_OPENAI_API_KEY"),
            chunk_size=1000
        )
        

        vector_store = FAISS.load_local(
            f"./dbs/{book_path}",
            embeddings,
            allow_dangerous_deserialization=True
        )
        retriever = vector_store.as_retriever(search_type="mmr", search_kwargs={"k": 3})

        # --- Process each question ---
        for row in question_results:
            question_id, question_text, classid, subjectid = row[0], row[1], row[2], row[3]
            
            retrieved_docs = retriever.invoke(question_text)
            context_text = "\n".join([doc.page_content for doc in retrieved_docs])

            chapters_str = json.dumps(chapter_results)
            taxonomy_str = json.dumps(taxonomy_results)

            prompt = f"""
                    You are an expert academic assistant. Given a question and its type, map it to the most relevant chapter and taxonomy.

                    Context from textbook:
                    {context_text}

                    Question ID: {question_id}
                    Question: {question_text}

                    Available Chapters:
                    {chapters_str}

                    Available Taxonomy Levels:
                    {taxonomy_str}

                    Return output in the following JSON format:
                    [
                      {{
                        "Chapter": <chapter>,
                        "Taxonomy": <taxonomy>
                      }}
                    ]
                    """

            # --- Call LLM ---
            
            response = client.chat.completions.create(
                model=DEPLOYMENT_NAME,
                messages=[
                    {"role": "system", "content": "You are a curriculum expert mapping questions to chapters and taxonomy levels."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=500,
                temperature=0.5
            )

            try:
                llm_output = json.loads(response.choices[0].message.content)
                chapter = llm_output[0]["Chapter"]
                taxonomy = llm_output[0]["Taxonomy"]
            except Exception as e:
                raise HTTPException(status_code=500, detail=f"Invalid LLM response for question {question_id}: {str(e)}")
            
            update_status = 'S001'
            
            sql = """
                CALL examprep.uspupdatequestionmetadata(
                    %s::bigint,
                    %s::bigint,
                    %s::bigint,
                    %s::varchar,
                    %s::varchar,
                    %s::varchar
                )
            """
            cursor.execute(sql, (
                question_id,
                classid,
                subjectid,
                chapter,
                taxonomy,
                update_status
            ))


            conn.commit()

        cursor.close()
        conn.close()
        return {"status": "Success"}

    except Exception as e:
        logger.exception("Error during processing")
        raise HTTPException(status_code=500, detail=f"Error generating chapters: {str(e)}")


@app.get("/ExcelSchoolAI/ExamPrep/get_classes")
def get_classes( par_custcode: str, par_orgcode: str):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        ref_cursor_name = "class_cursor"
        cursor.execute(f"CALL admin.uspclass(%s, %s, '{ref_cursor_name}');", 
                      ( par_custcode, par_orgcode))
        
        fetch_cursor = conn.cursor(ref_cursor_name)
        classes = fetch_cursor.fetchall()
        
        colnames = [desc[0] for desc in fetch_cursor.description]
        result = [dict(zip(colnames, row)) for row in classes]
        fetch_cursor.close()
        cursor.close()
        conn.close()
    
        return result
    except psycopg2.Error as e:
        logger.error(f"Database error in get_classes: {e}")
        raise HTTPException(status_code=500, detail=f"Database error: {e}")
    except Exception as e:
        logger.error(f"Unexpected error in get_classes: {e}")
        raise HTTPException(status_code=500, detail=f"An unexpected error occurred: {e}")     
        
@app.get("/ExcelSchoolAI/ExamPrep/get_subject")
def get_subjects(classid: int,  par_custcode: str, par_orgcode: str):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        ref_cursor_name = "subject_cursor"
        cursor.execute(f"CALL admin.uspgetsubject(%s, %s, %s, '{ref_cursor_name}');", 
                      (classid,  par_custcode, par_orgcode))
        
        fetch_cursor = conn.cursor(ref_cursor_name)
        classes = fetch_cursor.fetchall()
        
        colnames = [desc[0] for desc in fetch_cursor.description]
        result = [dict(zip(colnames, row)) for row in classes]
        fetch_cursor.close()
        cursor.close()
        conn.close()
    
        return result
    except psycopg2.Error as e:
        logger.error(f"Database error in get_subjects: {e}")
        raise HTTPException(status_code=500, detail=f"Database error: {e}")
    except Exception as e:
        logger.error(f"Unexpected error in get_subjects: {e}")
        raise HTTPException(status_code=500, detail=f"An unexpected error occurred: {e}")
        
@app.get("/ExcelSchoolAI/ExamPrep/get_year")
def get_year( par_custcode: str, par_orgcode: str,):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        ref_cursor_name = "year_cursor"
        cursor.execute(f"CALL examprep.uspgetyear(%s, %s, '{ref_cursor_name}');", 
                      ( par_custcode, par_orgcode))
        
        fetch_cursor = conn.cursor(ref_cursor_name)
        classes = fetch_cursor.fetchall()
        
        colnames = [desc[0] for desc in fetch_cursor.description]
        result = [dict(zip(colnames, row)) for row in classes]
        fetch_cursor.close()
        cursor.close()
        conn.close()
    
        return result
    except psycopg2.Error as e:
        logger.error(f"Database error in get_year: {e}")
        raise HTTPException(status_code=500, detail=f"Database error: {e}")
    except Exception as e:
        logger.error(f"Unexpected error in get_year: {e}")
        raise HTTPException(status_code=500, detail=f"An unexpected error occurred: {e}")
  
@app.get("/ExcelSchoolAI/ExamPrep/get_chapters")
def get_chapters(classid: int, subjectid: int, par_custcode: str, par_orgcode: str):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        ref_cursor_name = "chapter_cursor"
        cursor.execute(f"CALL admin.uspgetchapter(%s, %s, %s, %s, '{ref_cursor_name}');", 
                      (classid, subjectid,  par_custcode, par_orgcode))
        
        fetch_cursor = conn.cursor(ref_cursor_name)
        classes = fetch_cursor.fetchall()
        
        colnames = [desc[0] for desc in fetch_cursor.description]
        result = [dict(zip(colnames, row)) for row in classes]
        fetch_cursor.close()
        cursor.close()
        conn.close()
    
        return result
    except psycopg2.Error as e:
        logger.error(f"Database error in get_chapters: {e}")
        raise HTTPException(status_code=500, detail=f"Database error: {e}")
    except Exception as e:
        logger.error(f"Unexpected error in get_chapters: {e}")
        raise HTTPException(status_code=500, detail=f"An unexpected error occurred: {e}")
        
        
@app.get("/ExcelSchoolAI/ExamPrep/get_taxonomy")
def get_taxonomy(par_custcode: str, par_orgcode: str):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        ref_cursor_name = "taxonomy_cursor"
        cursor.execute(f"CALL examprep.uspgettaxonomy(%s, %s, '{ref_cursor_name}');", 
                      ( par_custcode, par_orgcode))
        
        fetch_cursor = conn.cursor(ref_cursor_name)
        classes = fetch_cursor.fetchall()
        
        colnames = [desc[0] for desc in fetch_cursor.description]
        result = [dict(zip(colnames, row)) for row in classes]
        fetch_cursor.close()
        cursor.close()
        conn.close()
    
        return result
    except psycopg2.Error as e:
        logger.error(f"Database error in get_taxonomy: {e}")
        raise HTTPException(status_code=500, detail=f"Database error: {e}")
    except Exception as e:
        logger.error(f"Unexpected error in get_taxonomy: {e}")
        raise HTTPException(status_code=500, detail=f"An unexpected error occurred: {e}")
        
               


@app.get("/ExcelSchoolAI/ExamPrep/get_questiontype")
def get_questiontype( par_custcode: str, par_orgcode: str):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        ref_cursor_name = "questiontype_cursor"
        cursor.execute(f"CALL examprep.uspgetquestiontype(%s, %s, '{ref_cursor_name}');", 
                      ( par_custcode, par_orgcode))
        
        fetch_cursor = conn.cursor(ref_cursor_name)
        classes = fetch_cursor.fetchall()
        
        colnames = [desc[0] for desc in fetch_cursor.description]
        result = [dict(zip(colnames, row)) for row in classes]
        fetch_cursor.close()
        cursor.close()
        conn.close()
    
        return result
    except psycopg2.Error as e:
        logger.error(f"Database error in get_questiontype: {e}")
        raise HTTPException(status_code=500, detail=f"Database error: {e}")
    except Exception as e:
        logger.error(f"Unexpected error in get_questiontype: {e}")
        raise HTTPException(status_code=500, detail=f"An unexpected error occurred: {e}")


# =================== DELETE PAPER ===================

    

@app.get("/ExcelSchoolAI/ExamPrep/paperdelete/{paper_id}", status_code=HTTP_200_OK)
async def delete_paper(paper_id: int,  par_custcode: str, par_orgcode: str):
    conn = None
    try:
        conn = get_db_connection()
        with conn.cursor() as cur:
            cur.execute("BEGIN;")
            
            # Execute DO block to capture OUT parameter via RAISE NOTICE
            cur.execute("""
                DO $$
                DECLARE
                    status_text VARCHAR;
                BEGIN
                    CALL examprep.usppaperdelete(%s, %s, %s, status_text);
                    RAISE NOTICE 'STATUS_TEXT: %%', status_text;
                END $$;
            """, (paper_id,  par_custcode, par_orgcode))
            
            # Extract status_text from server notices
            status_text = None
            for notice in conn.notices:
                if 'STATUS_TEXT:' in notice:
                    status_text = notice.split('STATUS_TEXT:')[1].strip().replace('"', '').replace("'", "")
            conn.notices.clear()
            
            cur.execute("COMMIT;")
            
        return {
            "message": f"Paper with ID {paper_id} deletion status.",
            "status": status_text or "Unknown"
        }
    except psycopg2.Error as e:
        if conn:
            conn.rollback()
        raise HTTPException(
            status_code=HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Database error: {e.pgerror or str(e)}"
        )
    finally:
        if conn:
            conn.close()

# =================== UPDATE PAPER ===================
class PaperUpdateRequest(BaseModel):
    papername: str
    par_status: str
    par_custcode: str
    par_orgcode: str
   

@app.post("/ExcelSchoolAI/ExamPrep/paperedit/{paper_id}", status_code=HTTP_200_OK)
async def update_paper(paper_id: int, body: PaperUpdateRequest):
    conn = None
    try:
        conn = get_db_connection()
        with conn.cursor() as cur:
            cur.execute("""
                DO $$
                DECLARE
                    out_status varchar;
                BEGIN
                    CALL examprep.usppaperedit(%s, %s, %s, %s, %s, out_status);
                    RAISE NOTICE 'OUT_STATUS: %%', out_status;
                END $$;
            """,  (paper_id, body.papername, body.par_status, body.par_custcode, body.par_orgcode))
            # Fetch the OUT parameter from the server notices
            out_status = None
            for notice in conn.notices:
                if 'OUT_STATUS:' in notice:
                    out_status = notice.split('OUT_STATUS:')[1].strip().replace('"', '').replace("'", "")
            conn.notices.clear()
            cur.execute("COMMIT;")
        return {
            "message": f"Paper with ID {paper_id} updated successfully.",
            "updated_status": out_status
        }
    except psycopg2.Error as e:
        if conn:
            conn.rollback()
        raise HTTPException(status_code=HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Database error: {e.pgerror or str(e)}")
    finally:
        if conn:
            conn.close()

# =================== SAVE PAPER ===================
from typing import List, Dict

class SaveQuestionPaperRequest(BaseModel):
    custcode: str
    orgcode: str
    userid: str
    papername: str
    noofquestions: int
    questioninfo: List[Dict]
    
@app.post("/ExcelSchoolAI/ExamPrep/papersave", status_code=HTTP_200_OK)
async def save_question_paper(body: SaveQuestionPaperRequest):
    conn = None
    try:
        conn = get_db_connection()
        with conn.cursor() as cur:
            # Convert questioninfo to JSON string for jsonb type
            questioninfo_jsonb = json.dumps(body.questioninfo)
            conn.notices.clear()

            # Match the EXACT argument order as in your procedure!
            cur.execute(
                """
                DO $$
                DECLARE
                    par_status character varying := '';
                BEGIN
                    CALL examprep.uspsavequestionpaperdetails(
                        %s::varchar,      -- custcode
                        %s::varchar,      -- orgcode                        
                        %s::varchar,       -- userid
                        %s::varchar,      -- papername
                        %s::jsonb,        -- questioninfo
                        par_status,       -- INOUT status
                        %s::int           -- noofquestions
                    );
                    RAISE NOTICE 'PAR_STATUS: %%', par_status;
                END $$;
                """,
                (
                    body.custcode,
                    body.orgcode,         
                    body.userid,
                    body.papername,
                    questioninfo_jsonb,
                    body.noofquestions
                )
            )
            conn.commit()

            # Retrieve notices for par_status
            par_status = None
            for notice in conn.notices:
                if 'PAR_STATUS:' in notice:
                    par_status = notice.split('PAR_STATUS:')[1].strip().replace('"', '').replace("'", "")
            conn.notices.clear()

        return {
            "message": "Question paper saved successfully.",
            "status": par_status or "Unknown"
        }

    except psycopg2.Error as e:
        if conn:
            conn.rollback()
        raise HTTPException(
            status_code=HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Database error: {e.pgerror or str(e)}"
        )
    finally:
        if conn:
            conn.close()


# =================== GET PAPER DETAILS ===================
class USPGetPaperDetailsRequest(BaseModel):
    par_custcode: str
    par_orgcode: str
    par_userid: str

@app.post("/ExcelSchoolAI/ExamPrep/uspgetpaperdetails", status_code=HTTP_200_OK)
async def uspgetpaperdetails(req: USPGetPaperDetailsRequest):
    conn = None
    try:
        conn = get_db_connection()
        with conn.cursor() as cur:
            cur.execute("BEGIN;")
            cur.execute("CALL public.uspgetpaperdtails(%s, %s, %s, 'p_refcur', 'p_refcur1');", ( req.par_custcode, req.par_orgcode, req.par_userid))
            cur.execute("FETCH ALL FROM p_refcur;")
            p_refcur = cur.fetchall()
            cur.execute("FETCH ALL FROM p_refcur1;")
            p_refcur1 = cur.fetchall()
            cur.execute("COMMIT;")
        return {"p_refcur": p_refcur, "p_refcur1": p_refcur1}
    except Exception as e:
        if conn:
            conn.rollback()
        raise HTTPException(status_code=HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))
    finally:
        if conn:
            conn.close()
# -------------------------------------------------------------------------

def clean_newlines(value):
    """Remove escaped newlines, carriage returns, and tabs from strings."""
    if isinstance(value, str):
        # Replace \r, \n, \t whether they are escaped (\\n) or real (\n)
        return re.sub(r'(\\n)+', ' ', value)
    elif isinstance(value, list):
        return [clean_newlines(v) for v in value]
    elif isinstance(value, dict):
        return {k: clean_newlines(v) for k, v in value.items()}
    return value


class USPGetPaperQuestionDetailsRequest(BaseModel):
    par_paperid: int

@app.post("/ExcelSchoolAI/ExamPrep/uspgetpaperquestiondetails", status_code=HTTP_200_OK)
async def uspgetpaperquestiondetails(req: USPGetPaperQuestionDetailsRequest):
    conn = None
    try:
        conn = get_db_connection()
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("BEGIN;")

            # Call the stored procedure with a named refcursor
            cur.execute("CALL examprep.uspgetpaperquestiondetails(%s, 'p_refcur');", (req.par_paperid,))

            # Fetch all rows from the refcursor
            cur.execute("FETCH ALL FROM p_refcur;")
            rows = cur.fetchall()

            cur.execute("COMMIT;")
        
        cleaned_rows = clean_newlines(rows)

        return {"data": cleaned_rows}
    except Exception as e:
        if conn:
            conn.rollback()
        raise HTTPException(status_code=HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Error: {str(e)}")
    finally:
        if conn:
            conn.close()

class QuestionRequest(BaseModel):
    custcode: str
    orgcode: str
    userid: str
    classid: int
    subjectid: int
    yearid: Optional[str] = '0'
    chapterid: Optional[str] = '0'
    taxonomy: Optional[str] = '0'
    questiontype: Optional[str] = '0'
    pagesize: Optional[int] = 0
    pageno: Optional[int] = 0
    searchtext: Optional[str] = ''
    
@app.post("/ExcelSchoolAI/ExamPrep/get_questions_details")
def get_question_details(request: QuestionRequest = Body(...)):
    try:
        conn = get_db_connection()
        conn.autocommit = False
        cur = conn.cursor()

        refcursor_name = "question_cursor"

        cur.execute(f"""
            CALL examprep.uspgetquestiondetails(
                %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s
            );
        """, (
            request.custcode,
            request.orgcode,
            request.userid,
            request.classid,
            request.subjectid,
            request.yearid,
            request.chapterid,
            request.taxonomy,
            request.questiontype,
            request.pagesize,
            request.pageno,
            request.searchtext,
            refcursor_name
        ))

        cur.execute(f"FETCH ALL FROM {refcursor_name};")
        rows = cur.fetchall()
        colnames = [desc[0] for desc in cur.description]
        result = [dict(zip(colnames, row)) for row in rows]

        cur.close()
        conn.close()

        return {"questions": result}

    except Exception as e:
        return {"error": str(e)}

# @app.get("/ExcelSchoolAI/ExamPrep/get_questions_details")
# def get_question_details(
    # orgcode: str,
    # userid: int,
    # classid: int,
    # subjectid: int,
    # yearid: Optional[str] = '0',
    # chapterid: Optional[str] = '0',
    # taxonomy: Optional[str] = '0',
    # questiontype: Optional[str] = '0',
    # pagesize: Optional[int] = 0,
    # pageno: Optional[int] = 0,
    # searchtext: Optional[str] = ''
# ):
    # try:
        # conn = get_db_connection()
        # conn.autocommit = False
        # cur = conn.cursor()

        # # Define a cursor name
        # refcursor_name = "question_cursor"

        # # Call the stored procedure
        # cur.execute(f"""
            # CALL public.uspgetquestiondetails(
                # %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s
            # );
        # """, (
           # orgcode,
           # userid,
           # classid,
           # subjectid,
           # yearid,
           # chapterid,
           # taxonomy,
           # questiontype,
           # pagesize,
           # pageno,
           # searchtext,
           # refcursor_name
        # ))

        # # Fetch from the cursor
        # cur.execute(f"FETCH ALL FROM {refcursor_name};")
        # rows = cur.fetchall()
        # colnames = [desc[0] for desc in cur.description]
        # result = [dict(zip(colnames, row)) for row in rows]

        # cur.close()
        # conn.close()

        # return {"questions": result}

    # except Exception as e:
        # return {"error": str(e)}
        
        
class QuestionConversionRequest(BaseModel):
    question: str
    target_type: str
    taxonomy: str
    chapter: str
    count: int = 1
    context: Optional[str] = None
    book_path: str


class GenerateSimilarRequest(BaseModel):
    question: str
    question_type: str    
    taxonomy: str
    chapter: str
    count: int = 3
    context: Optional[str] = None
    book_path: str

def build_prompt(question: str, target_type: str, taxonomy: str, chapter: str, count: int, context: Optional[str] = None) -> str:
    base_prompt = f"""
You are an expert educational content creator, who is an expert in creating questions based on the Previous Year Papers questions and the CBSE Textbook content. Your task is to generate {count} new questions of type "{target_type}" 
based on the original question: "{question}", aligned with Bloom's Taxonomy level: "{taxonomy}", and the topic: "{chapter}".

Each question must:
- Be suitable for a CBSE Class 10 Science examination, mirroring the style and difficulty of the provided previous year's paper.
- Ensure that each question must be based on the provided question and taxonomy.
- Match the cognitive level of the taxonomy:
    - **"Remember"**: 
        Generate a **low creativity** CBSE-style question that:
        *   Focuses on **recalling textbook facts, definitions, or formulas**.
        *   Uses **predictable data or terminology**.
        *   Avoids interpretation, judgment, or complex scenarios.
        *   Typical question types: Identify, Define, List, State, Name.

    - **"Understand"**: 
        Generate a **low-to-medium creativity** CBSE-style question that:
        *   Focuses on **explaining or interpreting textbook content**.
        *   Uses **familiar examples or definitions**.
        *   Avoids complex reasoning or novel applications.
        *   Typical question types: Explain, Describe, Summarize, Compare (simple), Illustrate.

    - **"Apply"**: 
        Generate a **medium creativity** CBSE-style question that:
        *   Requires **applying textbook knowledge to solve problems or interpret data**.
        *   Uses **standard examples or numerical values**.
        *   Avoids open-ended or judgment-based reasoning.
        *   Typical question types: Calculate, Solve, Demonstrate, Apply, Use.

    - **"Analyze"**: 
        Generate a **medium-to-high creativity** CBSE-style question that:
        *   Requires **analyzing relationships, comparing elements, or identifying patterns**.
        *   Uses **textbook content or data**.
        *   Avoids subjective judgment or emerging topics.
        *   Typical question types: Analyze, Differentiate, Categorize, Examine, Infer.

    - **"Evaluate"**: 
        Generate a **high creativity** CBSE-style question that:
        *   Requires **evaluating judgments, justifications, or applications**.
        *   Uses **textbook content or data**.
        *   Avoids subjective judgment or emerging topics.
        *   Typical question types: Evaluate, Justify, Assess, Critique, Recommend.

    - **"Create"**: 
        Generate a **very high creativity** CBSE-style question that:
        *   Encourages **original thinking, synthesis, or design**.
        *   Uses **textbook content as foundation**.
        *   Avoids unrealistic or speculative prompts.
        *   Typical question types: Design, Formulate, Propose, Develop, Construct.

- Be similar in scope and difficulty to the original question.
- Test the same core concept using varied contexts or scenarios.
- Adhere to the word limits specified in the general instructions for VSA, SA, and LA questions if applicable (e.g., 30-50 words for VSA, 50-80 words for SA, 80-120 words for LA).

"""

    if target_type.lower() == "MCQ":
        base_prompt += """
        For **Multiple Choice Questions (MCQ)**:
        - Provide four options labeled (a), (b), (c), (d).
        - Include one correct answer and three plausible distractors.
        - Ensure options are concise and clearly distinct.
        - If Apply level Taxonomy, include a scenario based question with 2 to 3 sub-parts.
        """

    elif target_type.lower() == "Assertion-Reason":
        base_prompt += """
        For **Assertion-Reason based questions**:
        - Include one Assertion (A) statement and one Reason (R) statement.
        - The question should require evaluating the truth of both statements and whether (R) is the correct explanation of (A).
        - The options should follow the standard CBSE format:
            (a) Both (A) and (R) are true and (R) is the correct explanation of (A).
            (b) Both (A) and (R) are true, but (R) is not the correct explanation of (A).
            (c) (A) is true, but (R) is false.
            (d) (A) is false, but (R) is true.
        - If Apply level Taxonomy, include a scenario based question with 2 to 3 sub-parts.
        """

    elif target_type.lower() == "VSA":
        base_prompt += """
        For **Very Short Answer (VSA) type questions**:
        - The answer should typically be in the range of **30 to 50 words**.
        - Focus on direct recall or simple explanations.
        - Can have sub-parts if appropriate for a 2-mark question.
        - if apply level taxonomy is included include a scenario based question with 2 to 3 sub-parts.
        """

    elif target_type.lower() == "Short answer":
        base_prompt += """
        For **Short Answer (SA) type questions**:
        - The answer should typically be in the range of **50 to 80 words**.
        - Requires slightly more detailed explanation, comparison, or application.
        - Can have sub-parts if appropriate for a 3-mark question.
        - if apply level taxonomy, include a scenario based question.
        """

    elif target_type.lower() == "Long answer":
        base_prompt += """
        For **Long Answer (LA) type questions**:
        - The answer should typically be in the range of **80 to 120 words**.
        - Requires comprehensive explanation, derivation, detailed analysis, or multi-step problem-solving.
        - Can have multiple sub-parts (e.g., a, b, c) to cover different aspects of the concept.
        - if apply level taxonomy, include a scenario based question with long questions.
        """

    elif target_type.lower() == "Case-based":
        base_prompt += """
        For **Source-based/Case-based questions**:
        - Provide a brief scenario, passage, diagram, or data set as the "case".
        - Follow it with 2 to 3 short sub-parts (e.g., a, b, c) that require analysis, interpretation, or application based on the provided case.
        - Ensure the sub-parts collectively add up to 4 marks.
        - Include an internal choice for one of the sub-parts, similar to the provided paper.
        - if apply level taxonomy, include a scenario based question with long questions.
        """

    base_prompt += """
        Return the output in the following JSON format:
        [
            {
                "question": "Generated question text with options"
            },
            // ... for MCQ
            {
                "question": "Assertion: [Assertion statement]\\nReason: [Reason statement]",
                "word_limit": "e.g., 30-50 words" // Only for Assertion-Reason
            },
            // ... for Assertion-Reason
            {
                "question": "Generated question text (VSA/SA/LA)",
                "word_limit": "e.g., 30-50 words" // Only for VSA, SA
            },
            // ... for VSA, SA
            {
                "question": "Generated question text with options on next line.",
                
            }
            // ... for Case-Based
        ]
        """

    if context:
        base_prompt += f"\nAdditional Context (from previous year's paper):\n{context}\n"

    return base_prompt

async def generate_similar_questions(question: str, target_type: str, taxonomy: str, chapter: str, count: int, context: Optional[str] = None) -> List[Dict[str, Any]]:
    """
    Generate similar questions using OpenAI's API
    """
    if not client:
        raise HTTPException(status_code=500, detail="Azure OpenAI is not properly configured")

    prompt = build_prompt(question, target_type, taxonomy, chapter, count, context)

    try:
        response = client.chat.completions.create(
            model=os.getenv("AZURE_OPENAI_DEPLOYMENT"),
            messages=[
                {"role": "system", "content": "You are a helpful assistant that generates educational content based on the provided context and taxonomy."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=1000
        )
        
        # Parse the response
        content = response.choices[0].message.content
        # Clean up the response to ensure it's valid JSON
        if content:
            content = content.strip().strip('`')
            if content.startswith('json'):
                content = content[4:].strip()
            questions = json.loads(content)
        else:
            questions = []

        if not isinstance(questions, list):
            questions = [questions]
            
        return questions
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating questions: {str(e)}")
        
def _load_retriever(book_path: str):
    """Load the FAISS vector store and return a retriever"""
    try:

        # Configure Azure OpenAI embeddings
        embedding_config = {
            "api_key": os.getenv("EM_OPENAI_API_KEY"),
            "azure_deployment": os.getenv("EM_OPENAI_ADA_EMBEDDING_DEPLOYMENT_NAME"),
            "model": os.getenv("EM_OPENAI_ADA_EMBEDDING_MODEL_NAME"),
            "azure_endpoint": os.getenv("EM_OPENAI_DEPLOYMENT_ENDPOINT"),
            "openai_api_version": os.getenv("EM_OPENAI_DEPLOYMENT_VERSION"),
            "chunk_size": 1000
        }
        
        # Test the connection by creating embeddings
        embeddings = AzureOpenAIEmbeddings(**embedding_config)
        
        # Test the connection with a small embedding
        test_embedding = embeddings.embed_query("test connection")
        
        # Path to the vector store directory (parent of the index file)
        vector_store_path = Path(f"./dbs/{book_path}")
        
        if not vector_store_path.exists():
            raise FileNotFoundError(f"Vector store directory not found at: {vector_store_path}")
            
        # List files in the directory for debugging
        print(f"Files in vector store directory: {list(vector_store_path.glob('*'))}")
        
        # Load the vector store
        vector_store = FAISS.load_local(
            str(vector_store_path),
            embeddings,
            allow_dangerous_deserialization=True
        )
        
        return vector_store.as_retriever(search_type="mmr", search_kwargs={"k": 5})
        
    except Exception as e:
        print(f"Error in _load_retriever: {str(e)}")
        print(f"Error type: {type(e).__name__}")
        if hasattr(e, 'response'):
            print(f"Response status: {e.response.status_code if hasattr(e.response, 'status_code') else 'N/A'}")
            print(f"Response body: {e.response.text if hasattr(e.response, 'text') else 'N/A'}")
        raise
        
        
@app.post("/ExcelSchoolAI/ExamPrep/convert-question")
async def convert_question(request: QuestionConversionRequest):
    """
    Convert a question to a different type using LLM and return the generated questions
    with vector store retrieval for context
    """
    try:
        # Load the retriever
        retriever = _load_retriever(request.book_path)

        # Get relevant context from the vector store
        docs = await retriever.ainvoke(request.question)
        context = "\n".join([doc.page_content for doc in docs])

        # Generate similar questions with the retrieved context
        generated_questions = await generate_similar_questions(
            question=request.question,
            target_type=request.target_type,
            taxonomy=request.taxonomy,
            chapter=request.chapter,
            count=request.count,
            context=context  # Pass the retrieved context
        )

        return {
            "original_question": request.question,
            "target_type": request.target_type,
            "taxonomy": request.taxonomy,
            "chapter": request.chapter,
            "generated_questions": generated_questions,
            "context_used": context[:500] + "..." if context else "No context found"  # Return first 500 chars for reference
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))



# for generation of 3 similar questions

@app.post("/ExcelSchoolAI/ExamPrep/generate-similar-questions")
async def generate_similar_questions_endpoint(request: GenerateSimilarRequest):
    """
    Generate similar questions of the same type using LLM
    """
    try:
        # Load the retriever
        retriever = _load_retriever(request.book_path)

        # Get relevant context from the vector store
        docs = await retriever.ainvoke(request.question)
        context = "\n".join([doc.page_content for doc in docs])
        
        # Generate similar questions of the same type
        generated_questions = await generate_similar_questions(
            question=request.question,
            target_type=request.question_type,  # Using the same type for generation
            count=request.count,
            taxonomy=request.taxonomy,
            chapter=request.chapter,
            context=context
        )
        
        return {
            "original_question": request.question,            
            "taxonomy": request.taxonomy,
            "chapter": request.chapter,
            "question_type": request.question_type,
            "generated_questions": generated_questions
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
        

@app.get("/ExcelSchoolAI/ExamPrep/get-elo-details")
def get_elo_details(chapterid: int = 1):
    try:
        conn = get_exceschoolai_db_connection()
        cursor = conn.cursor()
        
        ref_cursor_name = "lo_cursor"
        cursor.execute(f"CALL lesson.uspgetelodetails('{chapterid}', '{ref_cursor_name}');")
        
        fetch_cursor = conn.cursor(ref_cursor_name)
        classes = fetch_cursor.fetchall()
        
        colnames = [desc[0] for desc in fetch_cursor.description]
        result = [dict(zip(colnames, row)) for row in classes]

        fetch_cursor.close()
        cursor.close()
        conn.close()
    
        return {"elo_details": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# @app.get("/ExcelSchoolAI/Service/ExamPrep/get-elo-details/")
# def get_elo_details(chapterid: int = 1):
    # try:
        # conn = get_LPdb_connection()
        # cursor = conn.cursor()

        # # Step 1: Start transaction
        # cursor.execute("BEGIN;")

        # # Step 2: Call the procedure with refcursor param 's'
        # cursor.execute("CALL public.uspgetelodetails(%s, %s);", (chapterid, "s"))

        # # Step 3: Fetch all from the cursor named 's'
        # cursor.execute('FETCH ALL FROM "s";')
        # rows = cursor.fetchall()

        # # Step 4: Close the cursor and commit
        # cursor.execute('CLOSE "s";')
        # cursor.execute("COMMIT;")

        # # Step 5: Get column names
        # colnames = [desc[0] for desc in cursor.description]

        # # Step 6: Format as list of dicts
        # results = [dict(zip(colnames, row)) for row in rows]

        # cursor.close()
        # conn.close()

        # return {"elo_details": results}

    # except Exception as e:
        # raise HTTPException(status_code=500, detail=str(e))

        
# Run the FastAPI app
if __name__ == "__main__":
    import uvicorn
    # uvicorn.run(app, host="0.0.0.0", port=8066)
    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("FLASK_RUN_PORT_EXAMPREP", 8066)))
