import os
import re
from fastapi import FastAPI, HTTPException, status, Request, Query
from dotenv import load_dotenv
from fastapi.middleware.cors import CORSMiddleware
from openai import AzureOpenAI
from pydantic import BaseModel
from typing import List, Optional, Dict
from datetime import datetime
from loguru import logger
import psycopg2
from fastapi import Body
from fastapi.responses import JSONResponse
from urllib.parse import urlparse
from better_profanity import profanity
from bs4 import BeautifulSoup
from fastapi import Query
from typing import List, Dict
from ddgs import DDGS
from duckduckgo_api_haystack import DuckduckgoApiWebSearch
from typing import Dict, Any
from fastapi import APIRouter, Query
from typing import List, Dict, Any
import logging, time
import json
from google_affairs_agent import fetch_validated_current_affairs
from google_resources_agent import fetch_validated_resources
from typing import Dict, Any, List  # Ensure these imports are present

BLACKLISTED_TERMS = [
    '18+', 'adult', 'porn', 'xxx', 'nude', 'sex', 'naked', 'erotic', 'nsfw',
    'violence', 'gore', 'hate', 'racis', 'nazi', 'hitler', 'terroris', 'bomb'
]

#os.environ["HAYSTACK_TELEMETRY_DISABLED"] = "true"


def is_content_safe(text: str) -> bool:
    """Check if content contains any profanity or blacklisted terms"""
    if not text:
        return True
        
    # Check for profanity
    if profanity.contains_profanity(text):
        return False
        
    # Check additional blacklisted terms (case-insensitive)
    text = text.lower()
    for term in BLACKLISTED_TERMS:
        if term in text:
            return False
    return True

# Decorator to filter out inappropriate content
def content_filter(endpoint):
    async def wrapper(*args, **kwargs):
        request = kwargs.get('request')
        if request:
            try:
                data = await request.json()
                # Check all string fields in the request
                for key, value in data.items():
                    if isinstance(value, str) and not is_content_safe(value):
                        logger.warning(f"Blocked request containing inappropriate content in field: {key}")
                        raise HTTPException(
                            status_code=400,
                            detail="Your request contains inappropriate content and cannot be processed."
                        )
            except json.JSONDecodeError:
                pass  # Not a JSON request, skip content checking
                
        return await endpoint(*args, **kwargs)
    return wrapper
    


def source_from_url(url: str) -> str:
    """Extract domain name from URL"""
    try:
        domain = urlparse(url).netloc
        if domain.startswith('www.'):
            domain = domain[4:]
        return domain
    except:
        return ""

load_dotenv()

# Database Configuration
IIC_DB_NAME="ExcelSchoolAI"


DB_HOST = "10.1.0.6"
DB_PORT = 5432
DB_NAME = "ExcelSchoolAI"
DB_NAME_TOKEN="questionsimilarity"
DB_USER = "ailevate"
DB_PASS = "ail3v@teu$er"
def get_iic_db():
    conn = psycopg2.connect(
        host=DB_HOST,
        port=DB_PORT,
        database=IIC_DB_NAME,
        user=DB_USER,
        password=DB_PASS
    )
    return conn
def get_exceschoolai_db_connection():
    connection = psycopg2.connect(
        dbname="ExcelschoolAI",
        user="ailevate",
        password="ail3v@teu$er",
        host="10.1.0.6",
        port=5432
    )
    return connection
    
app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

PROMPT_TYPES = [
    "lesson_plan",
    "concept_explainer"
]


def parse_grade(grade_input):
    """
    Parses a grade from various formats into an integer (1–12).
    Accepts: 'class 5', 'Grade VI', 'seven', 'IX', '10', etc.
    """
    if not isinstance(grade_input, (str, int)):
        raise ValueError("Grade must be a string or an integer")

    grade_str = str(grade_input).strip().lower()

    grade_map = {
        'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5, 'six': 6,
        'seven': 7, 'eight': 8, 'nine': 9, 'ten': 10, 'eleven': 11, 'twelve': 12,
        'i': 1, 'ii': 2, 'iii': 3, 'iv': 4, 'v': 5, 'vi': 6, 'vii': 7,
        'viii': 8, 'ix': 9, 'x': 10, 'xi': 11, 'xii': 12
    }

    # 1. Extract numeric digits — works for "Class 5", "Grade 6"
    match = re.search(r'\d+', grade_str)
    if match:
        grade = int(match.group())
        if 1 <= grade <= 12:
            return grade

    # 2. Check for word or Roman numeral match in string — like "class five" or "Grade IX"
    for word, number in grade_map.items():
        if re.search(rf'\b{word}\b', grade_str):
            return number

    # 3. Final fallback: is input directly a number string?
    try:
        grade = int(grade_str)
        if 1 <= grade <= 12:
            return grade
    except:
        pass

    # 4. Still no match
    raise ValueError(
        f"Invalid grade format: '{grade_input}'. Please use a number (1-12), word (one–twelve), or Roman numeral (I–XII)."
    )



class LessonPlanRequest(BaseModel):
    promptType: str
    lessonTitle: str
    subject: str
    grade: str  # Accept as string, parse later
    duration: int
    keyVocabulary: str
    supportingMaterials: str
    additionalQuery: Optional[str] = None
    sessionInstructions: Optional[str] = ""
    expectedLearningOutcomes: Optional[List[str]] = []

class LinkModel(BaseModel):
    url: str
    text: str
    isVideo: bool
    domain: str

class LessonPlanResponse(BaseModel):
    lessonPlan: str
    structuredData: dict
    links: List[str]
    supportingMaterialLinks: List[str]
    resourceLinks: List[str]

class EducationalDocument(BaseModel):
    filename: str
    content_type: str
    content: str  # Base64 encoded content
    size: int  # Size in bytes

class SaveLessonPlanRequest(BaseModel):
    appcode: str
    custcode: str
    orgcode: str
    usercode: str
    classname: str
    subjectname: str
    lessonplanname: str
    ailessonplan_json: str
    modifiedlessonplan_json: str
    inputtoken: int
    responsetoken: int
    educational_documents: List[Dict[str, Any]] = [] 
    unitplanid:int

client = AzureOpenAI(
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    azure_endpoint=os.getenv("ENDPOINT_URL"),
    api_version=os.getenv("API_VERSION", "2025-01-01-preview"),
)

@app.get("/")
async def root():
    return {"message": "Python FastAPI app is running!"}

@app.get("/ExcelSchoolAI/LessonPlan/health")
async def health():
    return {"status": "ok", "timestamp": datetime.utcnow().isoformat()}

@app.get("/ExcelSchoolAI/LessonPlan/prompt-types")
async def get_prompt_types():
    return {"promptTypes": PROMPT_TYPES}

@app.get("/ExcelSchoolAI/LessonPlan/classes/{org_code}")
def get_classes(org_code: str):
    try:
        conn = get_iic_db()
        cursor = conn.cursor()
        
        ref_cursor_name = "class_cursor"
        cursor.execute(f"CALL lesson.uspgetclass('{org_code}', '{ref_cursor_name}');")
        
        fetch_cursor = conn.cursor(ref_cursor_name)
        classes = fetch_cursor.fetchall()
        
        colnames = [desc[0] for desc in fetch_cursor.description]
        result = [dict(zip(colnames, row)) for row in classes]

        fetch_cursor.close()
        cursor.close()
        conn.close()
    
        return result
    except psycopg2.Error as e:
        logger.error(f"Database error in get_classes: {e}")
        raise HTTPException(status_code=500, detail=f"Database error: {e}")
    except Exception as e:
        logger.error(f"Unexpected error in get_classes: {e}")
        raise HTTPException(status_code=500, detail=f"An unexpected error occurred: {e}")

@app.get("/ExcelSchoolAI/LessonPlan/subjects/{org_code}/{class_id}")
def get_subjects(org_code: str, class_id: int):
    try:
        conn = get_iic_db()
        cursor = conn.cursor()
        
        ref_cursor_name = "subject_cursor"
        cursor.execute(f"CALL lesson.uspgetsubject('{org_code}', {class_id}, '{ref_cursor_name}');")
        
        fetch_cursor = conn.cursor(ref_cursor_name)
        subjects = fetch_cursor.fetchall()
        
        colnames = [desc[0] for desc in fetch_cursor.description]
        result = [dict(zip(colnames, row)) for row in subjects]

        fetch_cursor.close()
        cursor.close()
        conn.close()

        return result
    except psycopg2.Error as e:
        logger.error(f"Database error in get_subjects: {e}")
        raise HTTPException(status_code=500, detail=f"Database error: {e}")
    except Exception as e:
        logger.error(f"Unexpected error in get_subjects: {e}")
        raise HTTPException(status_code=500, detail=f"An unexpected error occurred: {e}")

@app.delete("/ExcelSchoolAI/LessonPlan/lesson-plan/{lesson_plan_id}")
def delete_lesson_plan(lesson_plan_id: int):
    try:
        conn = get_iic_db()
        cursor = conn.cursor()

        status_out = ''
        cursor.callproc('lesson.uspdeletelessonplandetails', [lesson_plan_id, status_out])
        
        result = cursor.fetchone()
        status_out = result[0]

        conn.commit()
        cursor.close()
        conn.close()

        if "success" in status_out.lower():
            return {"message": status_out}
        else:
            raise HTTPException(status_code=400, detail=status_out)

    except psycopg2.Error as e:
        logger.error(f"Database error in delete_lesson_plan: {e}")
        raise HTTPException(status_code=500, detail=f"Database error: {e}")
    except Exception as e:
        logger.error(f"Unexpected error in delete_lesson_plan: {e}")
        raise HTTPException(status_code=500, detail=f"An unexpected error occurred: {e}")

@app.post("/ExcelSchoolAI/LessonPlan/save_lesson_plan")
async def save_lesson_plan(data: SaveLessonPlanRequest):
    try:
        # Extract values from Pydantic model
        appcode = data.appcode
        custcode = data.custcode
        orgcode = data.orgcode
        usercode = data.usercode
        classname = data.classname
        subjectname = data.subjectname
        lessonplanname = data.lessonplanname
        ailessonplan_json = data.ailessonplan_json
        modifiedlessonplan_json = data.modifiedlessonplan_json
        inputtoken = data.inputtoken
        responsetoken = data.responsetoken
        status = ''
        educational_documents = data.educational_documents
        unitplanid = int(data.unitplanid)
       
    
        conn = get_exceschoolai_db_connection()
        cursor = conn.cursor()

        sql = """
            CALL lesson.uspsavelessonplandetails(
                %s, %s, %s, %s, %s, %s, %s, %s::jsonb, %s::jsonb, %s, %s, %s, %s
            )
        """

        cursor.execute(sql, (
            appcode,
            custcode,
            orgcode,
            usercode,
            classname,
            subjectname,
            lessonplanname,
            ailessonplan_json,
            modifiedlessonplan_json,
            inputtoken,
            responsetoken,
            status,
            unitplanid
            
        ))

        # Save educational documents
        # for document in educational_documents:
            # sql = """
                # CALL public.uspsaveeducationaldocument(
                    # %s, %s, %s, %s, %s
                # )
            # """
            # cursor.execute(sql, (
                # document.filename,
                # document.content_type,
                # document.content,
                # document.size,
                # lessonplanname
            # ))

        conn.commit()
        cursor.close()
        conn.close()

        return JSONResponse(content={"message": "Lesson plan saved successfully"}, status_code=200)

    except Exception as e:
        return JSONResponse(content={"error": str(e)}, status_code=500)

@app.post("/ExcelSchoolAI/LessonPlan/get_lesson_plans")
async def get_lesson_plans(request: Request):
    try:
        data = await request.json()

        # Extract params
        appcode = data.get("appcode")
        custcode = data.get("custcode")
        orgcode = data.get("orgcode")
        usercode = data.get("usercode")
        classid = int(data.get("classid", 1))
        subjectid = int(data.get("subjectid", 1))
        lessonplanname = data.get("lessonplanname", "")
        unitid = int(data.get("unitid", 0))
        conn = get_exceschoolai_db_connection()
        cursor = conn.cursor()
        cursor.execute("BEGIN")

        cursor.execute("""
            CALL lesson.uspgetlessonplandetails(
                %s, %s, %s, %s, %s, %s, %s, %s, 'S', %s
            )
        """, (
            appcode,
            custcode,
            orgcode,
            usercode,
            classid,
            subjectid,
            lessonplanname,
            0,
            unitid
        ))

        cursor.execute('FETCH ALL IN "S"')
        rows = cursor.fetchall()
        colnames = [desc[0] for desc in cursor.description]

        lesson_plans = []
        for row in rows:
            plan = {}
            for key, value in zip(colnames, row):
                if isinstance(value, datetime):
                    plan[key] = value.isoformat()
                else:
                    plan[key] = value

            # Parse JSON fields safely
            if 'ailessonplan_json' in plan and plan['ailessonplan_json']:
                try:
                    plan['ailessonplan_json'] = json.loads(plan['ailessonplan_json'])
                except Exception as e:
                    plan['ailessonplan_json'] = {}

            if 'modifiedlessonplan_json' in plan and plan['modifiedlessonplan_json']:
                try:
                    plan['modifiedlessonplan_json'] = json.loads(plan['modifiedlessonplan_json'])
                except Exception as e:
                    plan['modifiedlessonplan_json'] = {}

            lesson_plans.append(plan)

        cursor.execute("COMMIT")
        cursor.close()
        conn.close()

        return JSONResponse(content={"lesson_plans": lesson_plans}, status_code=200)

    except Exception as e:
        return JSONResponse(content={"error": str(e)}, status_code=500)

@app.post("/ExcelSchoolAI/LessonPlan/update_lesson_plan")
async def update_lesson_plan(request: Request):
    try:
        body = await request.json()
        lessonplanid = body.get("lessonplanid")
        modified_json = json.dumps(body.get("modifiedlessonplan_json"))
        status = ''
        conn = get_iic_db()
        cursor = conn.cursor()

        sql = """
            CALL lesson.uspupdatelessonplandetails(
            %s::jsonb, %s, %s
            )
        """

        cursor.execute(sql, (
            modified_json,
            lessonplanid,
            status
        ))

        conn.commit()
        cursor.close()
        conn.close()


        return JSONResponse(content={"message": "Lesson plan updated successfully"}, status_code=200)

    except Exception as e:
        return JSONResponse(content={"error": str(e)}, status_code=500)

@app.post("/ExcelSchoolAI/LessonPlan/delete_lesson_plan")
async def delete_lesson_plan(request: Request):
    try:
        body = await request.json()
        lessonplanid = body.get("lessonplanid")
        status = ''

        conn = get_iic_db()
        cursor = conn.cursor()

        sql = """
            CALL lesson.uspdeletelessonplandetails(
                %s::bigint,
                %s::character varying
            )
        """

        cursor.execute(sql, (
            lessonplanid,
            status
        ))

        conn.commit()
        cursor.close()
        conn.close()

        return JSONResponse(content={"message": "Lesson plan deleted successfully"}, status_code=200)

    except Exception as e:
        return JSONResponse(content={"error": str(e)}, status_code=500)

class GetClassRequest(BaseModel):
    custcode: str
    orgcode: str
 
@app.post("/ExcelSchoolAI/LessonPlan/get_classes")
async def get_classes(data: GetClassRequest):
    try:        
        custcode = data.custcode
        orgcode = data.orgcode  
        refcursor = 'S'

        conn = get_iic_db()
        cursor = conn.cursor()

        sql = """
            CALL lesson.uspgetclass(%s,%s,%s)
        """
        cursor.execute(sql, (custcode, orgcode, refcursor))
        cursor.execute('FETCH ALL IN "S"')

        results = cursor.fetchall()

        cursor.close()
        conn.close()

        return {"classes": results}

    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})

class GetSubjectRequest(BaseModel):
    custcode: str
    orgcode: str

@app.post("/ExcelSchoolAI/LessonPlan/get_subjects")
async def get_subjects(request: GetSubjectRequest):
    try:
        classid = 0  # You can add this to the model if needed
        refcursor = 'S'

        conn = get_iic_db()
        cursor = conn.cursor()

        sql = """
            CALL lesson.uspgetsubject(%s, %s, %s, %s)
        """
        cursor.execute(sql, (request.custcode, request.orgcode, classid, refcursor))
        cursor.execute('FETCH ALL IN "S"')

        results = cursor.fetchall()

        cursor.close()
        conn.close()

        return {"subjects": results}

    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})


    
@app.get("/ExcelSchoolAI/LessonPlan/search-images")
async def search_images_endpoint(
    topic: str = Query(..., description="Main topic to search for"),
    subject: str = Query(..., description="Subject area (e.g., 'science','General science', 'math','social studies', 'english', 'history', 'geography', 'biology', 'chemistry', 'physics', 'technology')"),
    grade: str = Query(None, description="Grade level for age-appropriate content"),
    max_results: int = Query(10, description="Maximum number of results to return (max 10)")
):
    """
    API endpoint to search for educational images using DuckDuckGo

    """
    try:
        max_results = min(max(1, max_results), 10)  # Limit to 1-10 results
        images = []
        
        # Build a more specific query including subject and grade if provided
        search_query = f"{topic} {subject} educational diagram illustration"
        if grade is not None:
            try:
                processed_grade = parse_grade(grade)
                search_query += f" for grade {processed_grade}"
            except ValueError:
                # Fallback to original grade if parsing fails
                logger.warning(f"Could not parse grade '{grade}', using original value for image search.")
                search_query += f" for grade {grade}"
            
        ddgs = DDGS()
        results = list(ddgs.images(
            search_query,
            max_results=max_results,
            size="Medium",
            type_image="photo"
        ))
        for r in results:
            url = None
            if "image" in r:
                url = r["image"]
            elif "thumbnail" in r:
                url = r["thumbnail"]

            if not url:
                continue

            # Ensure HTTPS
            if url.startswith("http://"):
                url = url.replace("http://", "https://", 1)

            images.append({
                "url": url,
                "title": r.get("title", f"{topic} {subject} educational image"),
                "source": r.get("source", "DuckDuckGo"),
                "width": r.get("width", 300),
                "height": r.get("height", 200)
            })
        
        return {
            "status": "success",
            "results": images,
            "count": len(images),
            "query": search_query
        }
        
    except Exception as e:
        err_msg = str(e)
        logger.error(f"Error searching images: {err_msg}")
        # Gracefully handle DuckDuckGo rate limit errors
        if "202 Ratelimit" in err_msg or "rate limit" in err_msg.lower():
            return JSONResponse(
                status_code=429,
                content={
                    "status": "error",
                    "results": [],
                    "count": 0,
                    "message": "DuckDuckGo rate limit reached. Please wait and try again."
                }
            )
        raise HTTPException(
            status_code=500,
            detail={
                "status": "error",
                "message": f"Failed to search images: {str(e)}"
            }
        )

@app.post("/ExcelSchoolAI/LessonPlan/generate-lesson-plan")
async def generate_lesson_plan_endpoint(request: LessonPlanRequest):
    logger.info(f"Received request: {request}")
    
    # --- Content Safety Check BEFORE model call ---
    fields_to_check = [
        request.lessonTitle,
        request.promptType,
        getattr(request, "additionalQuery", None),
        getattr(request, "keyVocabulary", None),
        getattr(request, "supportingMaterials", None),
        getattr(request, "topic", None),
        getattr(request, "subject", None),
        getattr(request, "grade", None),
    ]
    for field in fields_to_check:
        if isinstance(field, str) and not is_content_safe(field):
            #logger.warning(f"Blocked model call due to inappropriate content in: {field}")
            raise HTTPException(
                status_code=400,
                detail="Your request contains inappropriate content and cannot be processed."
            )

    # --- Parse grade robustly ---
    try:    
        parsed_grade = parse_grade(request.grade)
        #logger.info(f"Parsed grade: '{request.grade}' -> {parsed_grade}")
    except Exception as e:
        #logger.error(f"Error parsing grade '{request.grade}': {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid grade format: '{request.grade}'. Please use a number (1–12), word (one–twelve), or Roman numeral (I–XII)."
        )     

    # Initialize response data structure and structured_lesson
    # Get educational resources
    resources_data = []
    try:
        resources_data = fetch_validated_resources(
            grade=request.grade,
            subject=request.subject,
            topic=request.lessonTitle,
            max_results=5
        )
        #logger.info(f"Fetched {len(resources_data)} educational resources")
    except Exception as e:
        logger.error(f"Error fetching educational resources: {str(e)}")
        # Continue with empty resources if there's an error
        resources_data = []
        
    structured_lesson = {
        'additionalSections': {
            'currentAffairs': [],
            'educationalVideos': [],
            'resources': resources_data
        }
    }
    response_data = {
        "lessonPlan": "",
        "structuredData": structured_lesson,  # Include the structured_lesson which contains educationalResources
        "links": [],
        "supportingMaterialLinks": [],
        "resourceLinks": [r['url'] for r in resources_data]  # Add resource links to resourceLinks
    }
    
    async def validate_topic_subject(title: str, subject: str):
        """
        Validates if a topic is relevant to the given subject.
        Returns (is_valid: bool, error_message: Optional[str])
        """
        if not title or not subject:
            return False, "Topic and subject cannot be empty"
            
        # Normalize inputs for comparison
        title = title.lower().strip()
        subject = subject.lower().strip()
        
        # Map of subjects to their related keywords
        subject_keywords = {
            'mathematics': ['math', 'algebra', 'geometry', 'calculus', 'trigonometry', 'equation', 'fraction', 'decimal', 'number', 'angle', 'triangle', 'circle', 'graph', 'statistics', 'probability'],
            'science': ['science', 'physics', 'chemistry', 'biology', 'experiment', 'molecule', 'atom', 'cell', 'plant', 'animal', 'energy', 'force', 'motion', 'electricity', 'magnetism', 'photosynthesis', 'respiration', 'digestion', 'ecosystem'],
            'history': ['history', 'war', 'revolution', 'ancient', 'civilization', 'empire', 'kingdom', 'dynasty', 'medieval', 'modern', 'independence', 'freedom', 'movement', 'battle', 'treaty'],
            'geography': ['geography', 'map', 'mountain', 'river', 'continent', 'country', 'climate', 'weather', 'population', 'resources', 'environment', 'ocean', 'desert', 'forest', 'atmosphere'],
            'english': ['english', 'grammar', 'essay', 'poem', 'novel', 'story', 'writing', 'literature', 'comprehension', 'vocabulary', 'letter', 'article', 'speech', 'debate'],
            'sanskrit': ['sanskrit', 'samskritam', 'devanagari', 'shloka', 'sutra', 'vyakarana', 'sandhi', 'samas', 'dhatu', 'pratyaya'],
            'hindi': ['hindi', 'kavita', 'kahani', 'nibandh', 'vyakaran', 'samas', 'sandhi', 'patra', 'aupcharik', 'anaupcharik', 'samasamayik', 'bhasha'],
            'accountancy': ['accountancy', 'accounting', 'ledger', 'balance sheet', 'debit', 'credit', 'assets', 'liabilities', 'trial balance', 'final accounts', 'journal', 'voucher', 'depreciation', 'ratio']
        }
        
        # Check if the subject is in our known subjects
        for sub, keywords in subject_keywords.items():
            if sub in subject:
                # If any keyword from the subject is in the title, it's valid
                if any(keyword in title for keyword in keywords):
                    return True, None
                
                # If no keywords found, check for common words that might be in multiple subjects
                common_words = ['introduction', 'basic', 'advanced', 'fundamental', 'overview', 'concept', 'principles']
                if any(word in title for word in common_words):
                    return True, None
                    
                # If we get here, the topic doesn't match the subject
                return False, f"The topic '{title}' doesn't appear to be related to {subject}."
        
        # If subject not found in our mapping, be permissive but log it
        #logger.warning(f"Subject '{subject}' not found in validation rules. Allowing topic: '{title}'")
        return True, None

    # Skip strict topic-subject validation to allow more flexibility
    # Only check for profanity or inappropriate content
    if not is_content_safe(request.lessonTitle) or not is_content_safe(request.subject):
        error_msg = "Content contains inappropriate language or terms. Please revise your input."
        #logger.warning(f"Content validation failed: {error_msg}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "error": "Content validation failed",
                "message": error_msg,
                "suggestion": "Please remove any inappropriate language and try again."
            }
        )
    
    # Prepare system and user prompts based on promptType
    system_message = ""
    # Format grade for display (e.g., 'Class 10' or 'Grade 6')
    grade_display = f"Class {parsed_grade}" if 'class' in str(request.grade).lower() else f"Grade {parsed_grade}"
    
    user_prompt = f"""Create educational content for a {request.duration}-minute session 
    on '{request.lessonTitle}' for {grade_display} {request.subject}."""
    
    # Add prompt type specific instructions
    if request.promptType == "lesson_plan":
        system_message = """You are a master teacher and expert lesson designer. Your job is to generate a highly engaging, age-appropriate, and well-structured lesson plan in JSON format.
        
        IMPORTANT: 
        - The currentAffairs and educationalVideos sections will be automatically populated with real data from APIs
        - You should include placeholders for these sections in your response
        - Do not generate any markdown formatting or additional text outside the JSON
        - The final response will replace the placeholders with actual data

        Your response MUST be a valid JSON object with the following structure:
        {
            "title": "Lesson Title",
            "metadata": {
                "grade": "Grade Level",
                "subject": "Subject",
                "duration": "Total duration in minutes"
            },
            "learningObjectives": [
                "Clear, measurable objective 1",
                "Clear, measurable objective 2"
            ],
            "materials": [
                {
                    "name": "Material 1",
                    "quantity": "As needed",
                    "notes": "How this will be used"
                }
            ],
            "keyVocabulary": [
                {
                    "term": "Term 1",
                    "definition": "Simple definition",
                    "example": "Example usage in context"
                }
            ],
            "lessonFlow": {
                "introduction": {
                    "duration": "5-10 minutes",
                    "hookActivity": "Engaging activity to introduce the topic",
                    "priorKnowledgeConnection": "How this connects to what students already know"
                },
                "activities": [
                    {
                        "title": "Activity 1",
                        "objective": "What students will learn/do",
                        "duration": "X minutes",
                        "materials": ["Material 1", "Material 2"],
                        "steps": [
                            "Step 1: Clear instruction",
                            "Step 2: Next action"
                        ],
                        "grouping": "Individual/Pairs/Group",
                        "teacherNotes": "Any special instructions or tips"
                    }
                ]
            },
            "assessment": {
                "type": "Formative/Summative",
                "description": "How learning will be assessed",
                "successCriteria": [
                    "Specific criterion 1",
                    "Specific criterion 2"
                ]
            },
            "differentiation": {
                "extensions": "Activities for advanced students",
                "support": "Support for struggling students"
            },
            "realWorldExamples": [
                {
                    "example": "Example 1",
                    "explanation": "Explanation 1"
                }
            ],
            "discussionQuestions": [
                {
                    "question": "Thought-provoking question",
                    "purpose": "Why this question is valuable"
                }
            ],
            "currentAffairs": [
                    {
                        "title": "[CURRENT_AFFAIRS_PLACEHOLDER - Will be replaced with 4 current affairs items]"
                    }
                ],
            "educationalVideos": [
                    {
                        "title": "[EDUCATIONAL_VIDEOS_PLACEHOLDER - Will be replaced with 7 educational videos]"
                    }
                ]
            }
        }

        IMPORTANT:
        - Only include the JSON object in your response
        - Do not include any markdown formatting or additional text
        - Ensure all strings are properly escaped
        - Keep the structure flat and simple
        - Only include fields that have content
        - Make sure the JSON is valid before returning
        """
        
        user_prompt = f"""Generate a detailed, visually aligned {request.duration}-minute lesson plan for {request.grade}th grade {request.subject} on '{request.lessonTitle}', using the Teachy.com style and the structure above.
        
        - Incorporate all user-provided supporting materials and key vocabulary, using each in context.
        - For each supporting material, suggest a concrete way it will be used.
        - For each vocabulary word, define it and use it in a sentence.

        - DO NOT include any links in the following sections:
          * Materials & Current affairs and Information
          * Lesson Flow
          * Extension & Differentiation
          * Key Vocabulary
          * Supporting Materials

        - All output must be clean, presentable Markdown as described.
        - DO NOT include any multimedia resources or YouTube videos in the lesson plan content.
        - Be concise, clear, and engaging throughout.

        """ 
       



     

    elif request.promptType == "concept_explainer":
        system_message = """You are a subject matter expert. Break down complex concepts into:
        - Simple, clear definitions
        - Relevant analogies and examples
        - Common misconceptions
        - Visual representation ideas
        - Real-world applications"""
        user_prompt = f"""Explain the concept of '{request.lessonTitle}' in {request.grade}th grade {request.subject}.
        Use age-appropriate language and provide multiple examples."""
        
    else:
        raise HTTPException(status_code=400, detail=f"Invalid prompt type. Must be one of: {PROMPT_TYPES}")

    # Add supporting materials
    # Properly handle comma-separated key vocabulary and supporting materials
    vocab_list = [v.strip() for v in request.keyVocabulary.split(',')] if request.keyVocabulary else []
    if vocab_list:
        user_prompt += f" Key vocabulary to include and explain: {', '.join(vocab_list)}. For each term, provide a simple definition and use it in a sentence."
    materials_list = [m.strip() for m in request.supportingMaterials.split(',')] if request.supportingMaterials else []
    if materials_list:
        user_prompt += f" Incorporate these supporting materials: {', '.join(materials_list)}. Suggest specific ways to use each material in the lesson."
    if request.promptType == "lesson_plan":
        user_prompt += """
IMPORTANT: DO NOT include any links, URLs, or references of any kind in the Discussion Questions section. DO NOT generate or suggest any links in that section. The backend will insert links using DuckDuckGo after your response. Only provide the questions and their purposes.
"""
    # -- Inject user-provided objectives into prompt if available --
    if request.promptType == "lesson_plan":
        if request.expectedLearningOutcomes:
            user_prompt += (
                "\nIMPORTANT:\n"
                "Design the entire lesson content (objectives, activities, materials, assessments) to align with the following **Expected Learning Outcomes**.\n"
                "If there's a difference in scope between the topic and these outcomes, prioritize covering all the learning expectations in a coherent and connected way.\n"
            f"Expected Learning Outcomes:\n{request.expectedLearningOutcomes}\n"
        )
    if request.sessionInstructions:
        user_prompt += f"\nUse this session instruction given by teacher to while generating lesson plan:\n{request.sessionInstructions}"


    user_prompt += """
IMPORTANT INSTRUCTION:
Use the Expected Learning Outcomes to shape ALL sections of the lesson plan.


Make sure the following sections directly reflect and align with the provided LOs, vocabulary, and materials:

- `lessonFlow.introduction` and `activities`: must help students achieve the Learning Objectives using the provided materials and key vocabulary.
- `assessment`: must evaluate mastery of Learning Objectives through appropriate methods.
- `differentiation`: must support learners based on how well they meet the Learning Objectives.
- `discussionQuestions`: should be thought-provoking and mapped back to the learning outcomes and core concepts.

ADDITIONAL:
- Use the provided `keyVocabulary` and `materials` in context throughout the lesson activities and flow.
- DO NOT show Core Objectives, Learning Objectives, or Expected Learning Outcomes directly in the final JSON unless asked.
- DO NOT include any links or references in these sections: Materials, Key Vocabulary, Lesson Flow, Differentiation, or Discussion Questions.
"""
    messages = [
        {"role": "system", "content": system_message},
        {"role": "user", "content": user_prompt}
    ]
    
    try:
        
        # Initialize Azure OpenAI client with correct configuration
        endpoint = os.getenv("ENDPOINT_URL")
        deployment_name = os.getenv("DEPLOYMENT_NAME")
        api_key = os.getenv("AZURE_OPENAI_API_KEY")
        api_version = os.getenv("API_VERSION")
        
        if not all([endpoint, deployment_name, api_key, api_version]):
            raise HTTPException(
                status_code=500,
                detail="Missing required Azure OpenAI configuration. Please check your .env file."
            )
            
        client = AzureOpenAI(
            api_key=api_key,
            api_version=api_version,
            azure_endpoint=endpoint
        )
        
        # Generate the lesson plan with the model
        response = client.chat.completions.create(
            model=deployment_name,
            messages=messages,
            temperature=0.7,
            max_tokens=4000
        )
        
        
        # Extract token counts
        inputtoken = response.usage.prompt_tokens
        responsetoken = response.usage.completion_tokens

        # Get the lesson plan content
        lesson_plan = response.choices[0].message.content

        


           
        # Initialize structured_lesson if it doesn't exist
        if 'structured_lesson' not in locals():
            structured_lesson = {}
            
      
        
        #  Build final current affairs query string (NO extra filters or suffixes)
        #current_affairs_query = f"'{request.lessonTitle}' current events for {grade_display} {request.subject} students"

        current_affairs_data = fetch_validated_current_affairs(
            grade=request.grade,
            subject=request.subject,
            topic=request.lessonTitle,
            max_results=5
        )
        
        if not current_affairs_data:
            #logger.warning("No NewsAPI results found, using fallback current event.")
            current_affairs_data = [{
        'title': 'Current events related to the topic',
        'snippet': 'No current events available at this time',
        'date': '',
        'source': '',
        'isFallback': True
        }]
    
       # Get educational videos
        video_data = []
        try:
            with DDGS() as ddgs:
                video_query = f"'{request.lessonTitle}' basics for {grade_display} {request.subject} -exercise -solution -quiz"
                results = ddgs.videos(video_query, max_results=5)
                
                for r in results:
                    video_id = None
                    content = r.get("content", "")
                    if "youtube.com" in content or "youtu.be" in content:
                        match = re.search(r"(?:v=|youtu\.be/)([a-zA-Z0-9_-]{11})", content)
                        if match:
                            video_id = match.group(1)
                    
                    video_data.append({
                        "title": r.get("title", "Educational Video"),
                        "url": content,
                        "source": r.get("publisher", "Unknown source"),
                        "video_id": video_id,
                        "thumbnail": f"https://img.youtube.com/vi/{video_id}/hqdefault.jpg" if video_id else ""
                    })
                
        except Exception as e:
            logger.error(f"Error getting educational videos: {str(e)}")

        # Update the structured lesson with our API data
        if 'additionalSections' not in structured_lesson:
            structured_lesson['additionalSections'] = {}
            
        structured_lesson['additionalSections'].update({
            'currentAffairs': current_affairs_data,
            'educationalVideos': video_data,
            'resources': resources_data
        })
        
        # Update the lessonPlan JSON with the API data
        lesson_plan_dict = json.loads(lesson_plan)
        if 'resources' not in lesson_plan_dict:
            lesson_plan_dict['resources'] = []
        if 'additionalSections' not in lesson_plan_dict:
            lesson_plan_dict['additionalSections'] = {}
        lesson_plan_dict['additionalSections'].update({
            'currentAffairs': current_affairs_data,
            'educationalVideos': video_data,
            'resources': resources_data 
        })

             


        # --- Ensure realWorldExamples is always present and populated ---
        def fetch_real_world_examples(topic, grade, subject):
            real_world_prompt = (
                f"Generate 6 real-world examples (with explanations) for a lesson on '{topic}' for {grade}th grade {subject}. "
                "Return as a JSON array of objects: [{\"example\": \"...\", \"explanation\": \"...\"}]"
            )
            messages = [
                {"role": "system", "content": "You are an expert educator. Only output valid JSON as requested."},
                {"role": "user", "content": real_world_prompt}
            ]
            real_world_response = client.chat.completions.create(
                model=deployment_name,
                messages=messages,
                temperature=0.5,
                max_tokens=512
            )
            try:
                return json.loads(real_world_response.choices[0].message.content)
            except Exception as e:
                #logger.error(f"Failed to parse real world examples: {e}")
                return []

        if 'realWorldExamples' not in lesson_plan_dict or not isinstance(lesson_plan_dict['realWorldExamples'], list) or len(lesson_plan_dict['realWorldExamples']) == 0:
            #logger.info("realWorldExamples missing or empty, generating with Azure model...")
            lesson_plan_dict['realWorldExamples'] = fetch_real_world_examples(
                request.lessonTitle, request.grade, request.subject
            )

        lesson_plan = json.dumps(lesson_plan_dict, indent=2)

        # Initialize resource_links list
        resource_links = []
        
        # Return the initial response
        return JSONResponse(content={
            "lessonPlan": lesson_plan,
            "inputtoken": inputtoken,
            "responsetoken": responsetoken,
            "links": [],
            "supportingMaterialLinks": [],
            "resourceLinks": []
        })

    except json.JSONDecodeError as e:
        #logger.error(f"Failed to parse lesson plan JSON: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail="Failed to process lesson plan data"
        )


if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("FLASK_RUN_PORT_LESSONPLAN", 8063)))