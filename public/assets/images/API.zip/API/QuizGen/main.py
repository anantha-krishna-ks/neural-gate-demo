from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Literal, Optional, Any, Dict
import os
import openai
import json
import uuid
from fastapi.middleware.cors import CORSMiddleware
import psycopg2
from psycopg2 import sql


API_KEY = "420cf7e1e6434bc7bf60e8c180b4055f"
DEPLOY_NAME = "esgpt4rag"

DB_HOST = "10.1.0.6"
DB_PORT = 5432
DB_NAME = "ExcelschoolAI"
DB_USER = "ailevate"
DB_PASS = "ail3v@teu$er"

# Function to connect to the database
def get_db_connection():
    conn = psycopg2.connect(
        host=DB_HOST,
        port=DB_PORT,
        database=DB_NAME,
        user=DB_USER,
        password=DB_PASS
    )
    return conn

client = openai.AzureOpenAI(
    api_key=API_KEY,
    api_version="2023-07-01-preview",
    base_url=f"https://excelsoftgpt4poc.openai.azure.com/openai/deployments/{DEPLOY_NAME}"
)

QuestionType = Literal["multiple-choice", "true-false", "fill-in-the-blanks"]
Difficulty = Literal["easy", "medium", "hard"]

class RequestBody(BaseModel):
    grade: str
    subject: str
    chapter: str
    questionCount: int
    selectedELOs: Optional[List[str]] = None

class Question(BaseModel):
    id: str
    text: str
    type: QuestionType
    options: Optional[List[str]] = None
    correctAnswer: str
    explanation: str
    difficulty: Difficulty
    elo: str
    taxonomy: Literal["knowledge", "understanding", "application"]

class ResponseBody(BaseModel):
    questions: List[Question]

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # or ["http://localhost:3000"] for specific origin
    allow_credentials=True,
    allow_methods=["*"],  # or ["POST", "GET", "OPTIONS"]
    allow_headers=["*"],
)
DATA_DIR = "data"

def read_chapter_text(grade: str, subject: str, chapter: str) -> str:
    chapter = chapter.lower().replace("?", "").replace("/", "").replace("\\", "").replace(":", "").replace(".", "")
    path = os.path.join(DATA_DIR, grade, subject, chapter, f"{chapter}.txt")
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="Chapter text not found")
    return open(path, "r", encoding="utf-8").read()

def call_openai_with_retry(prompt: str, max_retries: int = 5):
    for attempt in range(max_retries):
        try:
            response = client.chat.completions.create(
                model=DEPLOY_NAME,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7
            )
            content = response.choices[0].message.content.strip()
            return json.loads(content)
        except json.JSONDecodeError:
            if attempt == max_retries - 1:
                # return fallback empty list if JSON is broken after retries
                return []
        except Exception as e:
            if attempt == max_retries - 1:
                # log and continue with empty set
                print(f"OpenAI failed after {max_retries} retries: {e}")
                return []
    return []


def transform_questions(raw, qtype, target_elo):
    """Transform raw questions and preserve the target ELO that was used for generation"""
    questions = []
    for q in raw:
        try:
            # Normalize case for Pydantic validation
            difficulty = q.get("difficulty", "easy").lower()
            taxonomy = q.get("taxonomy", "knowledge").lower()
            qtype_norm = qtype.lower()

            # For True/False questions, ensure options
            options = q.get("options")
            if qtype_norm == "true-false":
                options = ["True", "False"]

            # Use the target_elo that was actually used for generation
            # instead of whatever might be in the response
            elo_to_use = target_elo if target_elo else q.get("elo", "General")

            questions.append(Question(
                id=str(uuid.uuid4()),
                text=q["question"],
                type=qtype_norm,   # keep lowercase for validation
                options=options,
                correctAnswer=q["correctAnswer"],
                explanation=q["explanation"],
                difficulty=difficulty,
                elo=elo_to_use,  # Use the ELO that was actually used for generation
                taxonomy=taxonomy
            ))
        except Exception as e:
            print("Skipping invalid question:", q, e)
    return questions



def generate_questions(question_type: str, text: str, count: int, elos: List[str]):
    """Generate questions for specific ELOs and preserve which ELO was used"""
    elos = elos or ["General"]
    
    # If multiple ELOs are provided, we'll generate questions for each ELO separately
    # to ensure proper ELO tracking
    if len(elos) > 1:
        all_questions = []
        questions_per_elo = max(1, count // len(elos))
        remaining_questions = count % len(elos)
        
        for i, elo in enumerate(elos):
            elo_count = questions_per_elo + (1 if i < remaining_questions else 0)
            if elo_count > 0:
                elo_questions = generate_questions_for_single_elo(question_type, text, elo_count, elo)
                all_questions.extend(elo_questions)
        
        return all_questions[:count]  # Ensure we don't exceed the requested count
    else:
        # Single ELO case
        return generate_questions_for_single_elo(question_type, text, count, elos[0])


def generate_questions_for_single_elo(question_type: str, text: str, count: int, elo: str):
    """Generate questions for a single ELO and ensure the ELO is preserved"""
    qtype_map = {
        "mcq": "multiple-choice questions (MCQs)",
        "tf": "True/False questions",
        "sa": "fill-in-the-blanks questions"
    }

    fields_map = {
        "mcq": "- question\n- options\n- correctAnswer\n- explanation\n- difficulty\n- elo\n- taxonomy",
        "tf": "- question\n- correctAnswer\n- explanation\n- difficulty\n- elo\n- taxonomy",
        "sa": "- question\n- correctAnswer\n- explanation\n- difficulty\n- elo\n- taxonomy"
    }

    example_map = {
        "mcq": f"""[
  {{
    "question": "What is the capital of France?",
    "options": ["Paris", "London", "Rome", "Madrid"],
    "correctAnswer": "Paris",
    "explanation": "Paris is the capital of France.",
    "difficulty": "easy",
    "elo": "{elo}",
    "taxonomy": "knowledge"
  }}
]""",
        "tf": f"""[
  {{
    "question": "The Earth orbits the Sun.",
    "correctAnswer": "True",
    "explanation": "Earth orbits the Sun every year.",
    "difficulty": "easy",
    "elo": "{elo}",
    "taxonomy": "understanding"
  }}
]""",
        "sa": f"""[
  {{
    "question": "The chemical symbol for water is _____.",
    "correctAnswer": "H2O",
    "explanation": "H2O represents two hydrogen atoms and one oxygen atom.",
    "difficulty": "easy",
    "elo": "{elo}",
    "taxonomy": "application"
  }}
]"""
    }

    prompt = f"""
You are an AI tutor. Generate {count} {qtype_map[question_type]} in valid JSON array format ONLY.

IMPORTANT: All questions must be generated specifically for the ELO (Expected Learning Outcome): "{elo}"
Make sure each question's "elo" field is exactly: "{elo}"

Each question must include:
{fields_map[question_type]}

The "taxonomy" field must be one of:
- "knowledge" (recall facts, definitions, basic concepts)
- "understanding" (interpret, explain, summarize)
- "application" (apply knowledge to solve problems)

The "elo" field must be exactly: "{elo}"

Respond ONLY with a pure JSON array. No markdown, comments, or text.

Example:
{example_map[question_type]}

Content to base questions on:
{text}

Remember: All questions should be aligned with the ELO "{elo}" and the "elo" field in each question must be exactly "{elo}".
"""

    raw = call_openai_with_retry(prompt)
    return transform_questions(raw, {
        "mcq": "multiple-choice",
        "tf": "true-false",
        "sa": "fill-in-the-blanks"
    }[question_type], elo)  # Pass the target ELO to ensure it's preserved


question_set_counter = {5: 0, 10: 0, 12: 0, 'per-elo': 0}

@app.post("/ExcelSchoolAI/QuizGen/generate-questions", response_model=ResponseBody)
def create_quiz(req: RequestBody):
    text = read_chapter_text(req.grade, req.subject, req.chapter)
    elos = req.selectedELOs or ["General"]

    key = req.questionCount if req.questionCount in [5, 10, 12] else 'per-elo'
    question_set_counter[key] += 1
    use_set_2 = (question_set_counter[key] % 2 == 0)

    if key == 5:
        mcq_count = 3 if use_set_2 else 5
        sa_count = 1 if use_set_2 else 0
        tf_count = 1 if use_set_2 else 0

    elif key == 10:
        if use_set_2:
            mcq_count, sa_count, tf_count = 5, 3, 2
        else:
            mcq_count, sa_count, tf_count = 10, 0, 0

    elif key == 12:
        if use_set_2:
            mcq_count, sa_count, tf_count = 4, 4, 4
        else:
            mcq_count, sa_count, tf_count = 12, 0, 0

    elif key == 'per-elo' and req.selectedELOs and len(req.selectedELOs) > 0:
        all_questions = []
        for elo in req.selectedELOs:
            if use_set_2:
                # Generate questions for each specific ELO
                all_questions.extend(generate_questions_for_single_elo("mcq", text, 2, elo))
                all_questions.extend(generate_questions_for_single_elo("tf", text, 1, elo))
            else:
                all_questions.extend(generate_questions_for_single_elo("mcq", text, 3, elo))
        return ResponseBody(questions=all_questions)

    else:
        mcq_count = req.questionCount
        sa_count = 0
        tf_count = 0

    all_questions = []
    # Generate questions with proper ELO preservation
    if mcq_count > 0:
        all_questions.extend(generate_questions("mcq", text, mcq_count, elos))
    if tf_count > 0:
        all_questions.extend(generate_questions("tf", text, tf_count, elos))
    if sa_count > 0:
        all_questions.extend(generate_questions("sa", text, sa_count, elos))

    while len(all_questions) > req.questionCount:
        all_questions.pop()

    return ResponseBody(questions=all_questions)
    
@app.post("/ExcelSchoolAI/QuizGen/generate_questions_demo", response_model=ResponseBody)
def create_quizdemo(req: RequestBody):
    text = read_chapter_text(req.grade, req.subject, req.chapter)
    elos = req.selectedELOs or ["General"]

    key = req.questionCount if req.questionCount in [5, 10, 12] else 'per-elo'
    question_set_counter[key] += 1
    use_set_2 = (question_set_counter[key] % 2 == 0)

    if key == 5:
        mcq_count = 3 if use_set_2 else 5
        sa_count = 1 if use_set_2 else 0
        tf_count = 1 if use_set_2 else 0

    elif key == 10:
        if use_set_2:
            mcq_count, sa_count, tf_count = 10, 3, 2
        else:
            mcq_count, sa_count, tf_count = 10, 0, 0

    elif key == 12:
        if use_set_2:
            mcq_count, sa_count, tf_count = 4, 4, 4
        else:
            mcq_count, sa_count, tf_count = 12, 0, 0

    elif key == 'per-elo' and req.selectedELOs and len(req.selectedELOs) > 0:
        all_questions = []
        for elo in req.selectedELOs:
            if use_set_2:
                # Generate questions for each specific ELO and preserve the ELO
                all_questions.extend(generate_questions_for_single_elo("mcq", text, key, elo))
            else:
                all_questions.extend(generate_questions_for_single_elo("mcq", text, key, elo))
        return ResponseBody(questions=all_questions)

    else:
        mcq_count = req.questionCount
        sa_count = 0
        tf_count = 0

    all_questions = []
    # Generate questions with proper ELO preservation
    if mcq_count > 0:
        all_questions.extend(generate_questions("mcq", text, key, elos))

    while len(all_questions) > req.questionCount:
        all_questions.pop()

    return ResponseBody(questions=all_questions)

class QuizRequest(BaseModel):
    custcode: str
    orgcode: str
    usercode: str
    classid: int
    subjectid: int
    chapterid: int
    questioncount: int
    eloids: str
    quizname: str
    questioninfo: List[Dict[str, Any]]

@app.post("/ExcelSchoolAI/QuizGen/save-quiz")
def save_quiz(request: QuizRequest):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Build the CALL statement manually
        call_stmt = """
        CALL quiz.uspcreatequiz(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """

        # Initialize INOUT status value
        status = 'INIT'

        # Execute CALL
        cursor.execute(call_stmt, [
            request.custcode,
            request.orgcode,
            request.usercode,
            request.classid,
            request.subjectid,
            request.chapterid,
            request.questioncount,
            request.eloids,
            request.quizname,
            json.dumps(request.questioninfo),
            status
        ])

        conn.commit()
        cursor.close()
        conn.close()

        return {"status": "Success"}  # Or return status if you get it back another way

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    
    
class QuizDetailsRequest(BaseModel):
    custcode: str
    orgcode: str
    usercode: str
    searchtext: str

@app.post("/ExcelSchoolAI/QuizGen/get-quiz-details")
def get_quiz_details(request: QuizDetailsRequest):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Define a named cursor
        ref_cursor_name = "quiz_ref"

        # Call the procedure using raw SQL and pass the refcursor name
        cursor.execute(
            "CALL quiz.uspgetquizdetails(%s, %s, %s, %s, %s);",
            (
                request.custcode,
                request.orgcode,
                request.usercode,
                request.searchtext,
                ref_cursor_name,
            ),
        )

        # Fetch from the named cursor
        cursor.execute(f"FETCH ALL FROM {ref_cursor_name};")
        rows = cursor.fetchall()

        # Column names
        colnames = [desc[0] for desc in cursor.description]

        # Build result
        result = [dict(zip(colnames, row)) for row in rows]

        # Clean up
        cursor.execute(f"CLOSE {ref_cursor_name};")
        conn.commit()
        cursor.close()
        conn.close()

        return {"status": "Success", "data": result}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    
@app.post("/ExcelSchoolAI/QuizGen/get-json-details/{quizid}")
def get_quiz_info(quizid: int):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Define a named refcursor
        cursor_name = "quiz_cursor"

        # Call the procedure using raw SQL
        cursor.execute("BEGIN;")
        cursor.execute(
            "CALL quiz.uspgetquizinfo(%s, %s);",
            (quizid, cursor_name)
        )
        cursor.execute(f"FETCH ALL FROM {cursor_name};")

        # Fetch all rows
        rows = cursor.fetchall()

        # Get column names
        colnames = [desc[0] for desc in cursor.description]

        # Format as list of dicts
        result = [dict(zip(colnames, row)) for row in rows]

        # Clean up
        cursor.execute(f"CLOSE {cursor_name};")
        cursor.execute("COMMIT;")

        cursor.close()
        conn.close()

        return {"status": "Success", "data": result}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/ExcelSchoolAI/QuizGen/delete-quiz/{quizid}")
def delete_quiz(quizid: int):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Call the stored procedure (assuming it returns a status in the OUT parameter)
        cursor.execute("CALL quiz.uspdeletequiz(%s, %s)", (quizid, ""))

        # Fetch the result (INOUT parameter returned as a result set)
        status_value = cursor.fetchone()[0]

        conn.commit()
        cursor.close()
        conn.close()

        return {"status": "Success", "message": status_value}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    # uvicorn.run(app, host="0.0.0.0", port=8060)
    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("FLASK_RUN_PORT_quizgen", 8070)))
    