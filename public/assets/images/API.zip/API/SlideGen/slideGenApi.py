import os
import tempfile
from io import BytesIO
from fastapi import FastAPI, File, UploadFile, HTTPException, Body, Request
from fastapi.responses import JSONResponse, FileResponse, Response
from pydantic import BaseModel, ValidationError
import json
from fastapi.middleware.cors import CORSMiddleware
from bs4 import BeautifulSoup
import fitz  # PyMuPDF
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from fastapi import Query
from pptx import Presentation
from pptx.util import Pt
from pptx.dml.color import RGBColor
import requests
import json as pyjson
from dotenv import load_dotenv
from ddgs import DDGS
from PIL import Image, UnidentifiedImageError
from io import BytesIO
from openai import AzureOpenAI
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
import urllib3
import certifi
from fastapi import Form
import psycopg2
from psycopg2.extras import RealDictCursor
import datetime
from docx import Document
from pptx.oxml.xmlchemy import OxmlElement
from pptx.oxml.ns import qn

# Initialize FastAPI app
app = FastAPI()

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # For development only
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# # Disable SSL warnings
# urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

load_dotenv()

# PostgreSQL connection
def get_db_connection():
    return psycopg2.connect(
        dbname="ExcelschoolAI",
        user="ailevateailevate",
        password="ail3v@teu$er",
        host="10.1.0.6",
        port="5432"
    )

def getdb_connection():
    return psycopg2.connect(
        dbname="ExcelschoolAI",
        user="ailevate",
        password="ail3v@teu$er",
        host="10.1.0.6",
        port="5432"
    )

class GetLessonSessionInput(BaseModel):
    custcode: str
    orgcode: str
    usercode: str
    unitid: int = 0
    sessionids: str = ""


@app.post("/ExcelSchoolAI/SlideGen/get-lesson-session-details")
async def get_lesson_session_details(input: GetLessonSessionInput):
    try:
        with getdb_connection() as conn:
            with conn.cursor(cursor_factory=RealDictCursor) as cursor:
                cursor.execute("BEGIN;")
                
                cursor.execute("""
                    CALL lesson.uspgetlessonsessiondetails(
                        %s::varchar, %s::varchar, %s::varchar,
                        %s::bigint, %s::varchar,
                        %s::refcursor, %s::refcursor
                    );
                """, [
                    input.custcode,
                    input.orgcode,
                    input.usercode,
                    input.unitid,
                    input.sessionids,
                    'result_cursor1',
                    'result_cursor2'
                ])
                
                cursor.execute("FETCH ALL FROM result_cursor1;")
                result1 = cursor.fetchall()
                cursor.execute("FETCH ALL FROM result_cursor2;")
                result2 = cursor.fetchall()
                cursor.execute("CLOSE result_cursor1;")
                cursor.execute("CLOSE result_cursor2;")
                conn.commit()
                
                return {
                    "db_status_code": 1,
                    "result1": result1,
                    "result2": result2
                }
    except Exception as e:
        return {
            "db_status_code": -999,
            "error": str(e),
            "result1": [],
            "result2": []
        }


class SessionDetailsInput(BaseModel):
    custcode: str
    orgcode: str
    usercode: str
    classid: int
    subjectid: int
    searchtext: str = ""

class PPTRequest(BaseModel):
    txt_filename: str = ""
    additional_instructions: str = ""
    session_plans: List[Dict[str, Any]] = Field(default_factory=list)
    unitPlan: Optional[Dict[str, Any]] = None  
    Class: str = ""
    Subject: str = ""
    SchoolCode: str = ""
    Branch: str = ""
    
    class Config:
        json_encoders = {
            'UnitPlan': lambda v: v.dict() if v else None
        }

@app.post("/ExcelSchoolAI/SlideGen/generate_ppt")
async def generate_ppt(request_data: dict):
    #print('Received PPT generation request data:', request_data)
    
    try:
        # Validate the request data
        request = PPTRequest(**request_data)
    except Exception as e:
        #print(f'Validation error: {str(e)}')
        raise HTTPException(status_code=422, detail=f"Invalid request data: {str(e)}")
        
    
    # Extract all LLM context fields from the request, defaulting to empty if missing
    txt_filename = getattr(request, 'txt_filename', '') or ''
    txt_filename = txt_filename.lower().replace("?", "").replace("/", "").replace("\\", "").replace(":", "").replace(".", "")
    additional_instructions = getattr(request, 'additional_instructions', '') or ''
    session_plans = getattr(request, 'session_plans', []) or []
    unit_plan = getattr(request, 'unitPlan', None) or None

    # Print all context for debugging
    #print(f"txt_filename: {txt_filename}")
    #print(f"additional_instructions: {additional_instructions}")
    #print(f"session_plans: {session_plans}")

    # These four fields are now always available for LLM prompt construction or downstream use.
    
    # Start with content from the text file if it exists
    full_content = ""
    import glob
    # Search for the txt file recursively under Books folder
    books_dir = os.path.join(os.getcwd(), "Books")
    txt_path = None
    for root, dirs, files in os.walk(books_dir):
        if txt_filename in files:
            txt_path = os.path.join(root, txt_filename)
            break

    if txt_path and os.path.exists(txt_path):
        #print("yes content found")  # File found
        with open(txt_path, "r", encoding="utf-8") as f:
            full_content += f"# Content from {txt_filename}\n\n{f.read()}\n\n"
            
    if unit_plan:
        full_content += "# Unit Plan\n\n"
        full_content += json.dumps(unit_plan, indent=2, ensure_ascii=False) + "\n\n"

    # Add any additional instructions
    if additional_instructions:
        full_content += f"# Additional Instructions\n\n{additional_instructions}\n\n"
    
   
    if session_plans:
        full_content += "# Session Plans\n\n"
        for i, session in enumerate(session_plans, 1):
            full_content += f"## Session {i}: {session}\n\n"
    # LLM call (OpenAI/Azure)
    api_key = os.getenv("OPENAI_API_KEY")
    endpoint = os.getenv("OPENAI_DEPLOYMENT_ENDPOINT")
    deployment = os.getenv("OPENAI_DEPLOYMENT_NAME")
    api_version = os.getenv("OPENAI_DEPLOYMENT_VERSION")
    if not all([api_key, endpoint, deployment, api_version]):
        raise HTTPException(status_code=500, detail="Missing Azure OpenAI credentials in environment.")
    # Base instructions
    base_instructions = """
    You are an expert educational content organizer. Given the following content (delimited by triple backticks), create a clear, accurate PowerPoint presentation. You may be provided with:
    - Unit Plan (overall structure and objectives)
    - Session Plans (detailed lesson breakdowns)
    - Textbook Content (from the uploaded file)
    - Additional Instructions (from the user)
    
    Rules:
    - Do NOT invent chapters. If the content represents a single chapter/topic, generate slides only for that chapter/topic and its sections.
    - Avoid using the prefix "Chapter N:" in slide titles unless it appears verbatim in the source content. Prefer concise topic-based titles.
    - Aim for 8–12 total slides (including the title slide) for a single-chapter input, unless the user instructs otherwise.
    - Preserve all formulas, equations, symbols as-is.
    - Keep points concise but informative (≈15–25 words per subpoint).
    - Use headers and subpoints to structure content logically and highlight learning objectives and examples.
    
    For each non-title slide:
    1) Provide a clear, descriptive title (topic-based, no fabricated chapter numbering)
    2) Include at least 4 headers (use "## " prefix for each header)
    3) Under each header include 3–5 subpoints (use "• " prefix for each subpoint)
    """
    
    # --- Detect style preference from additional instructions ---
    style_mode = "bullets"  # default

    if additional_instructions:
        lower_ai = additional_instructions.lower()
        if "paragraph" in lower_ai or "no bullet" in lower_ai:
            style_mode = "paragraph"
        elif "number" in lower_ai or "numbered" in lower_ai:
            style_mode = "numbered"

    # --- Modify base instructions dynamically ---
    if style_mode == "paragraph":
        style_instructions = """
        Format slides so that instead of bullet points, each slide has 6 paragraphs
        of text (60-80 words each). No bullet characters.
        """
    elif style_mode == "numbered":
        style_instructions = """
        Format slides with numbered lists (1., 2., 3.) instead of bullet points.
        Each header should have 3 numbered subpoints.
        """
    else:  # default bullets
        style_instructions = """
        Format slides with headers (##) and bullet points (•) under them.
        """

    instructions = f"""{base_instructions}
    {style_instructions}

    Additional Instructions from User:
    {additional_instructions}
"""

        
    prompt = f"""
    {instructions}
    
    Format your response as a JSON array where each object represents one slide. The first slide should be a title slide with 'title' and 'subtitle'. All other slides should have 'title' and 'bullets'.
    
    Example format (no fabricated chapter numbering):
    [
      {{
        "title": "Main Title",
        "subtitle": "Subtitle"
      }},
      {{
        "title": "Heredity: Key Concepts",
        "bullets": [
          "## Header 1",
          "• Subpoint 1.1: Key information...(if in addition instruction g)",
          "• Subpoint 1.2: Important details...",
          "• Subpoint 1.3: Additional information...",
          "",
          "## Header 2",
          "• Subpoint 2.1: Key information...",
          "• Subpoint 2.2: Important details...",
          "• Subpoint 2.3: Additional information...",
          "",
          "## Header 3",
          "• Subpoint 3.1: Key information...",
          "• Subpoint 3.2: Important details...",
          "• Subpoint 3.3: Additional information..."
        ]
      }}
    ]
    
    Important notes:
    - Use ## to denote headers in the bullet points
    - Keep formulas and equations exactly as they appear in the original text
    - Each slide should be information-dense but not overcrowded
    - Make sure to cover all key concepts from the content
    
    Content to analyze:
    ```{full_content}```
    """
    url = f"{endpoint}/openai/deployments/{deployment}/chat/completions?api-version={api_version}"
    headers = {"api-key": api_key, "Content-Type": "application/json"}
    payload = {
        "messages": [
            {"role": "system", "content": "You are a helpful assistant that generates PowerPoint slides as JSON."},
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.5,
        "top_p": 1,
        "frequency_penalty": 0,
        "presence_penalty": 0,
    }
    response = requests.post(url, headers=headers, json=payload)
    if response.status_code != 200:
        raise HTTPException(status_code=500, detail=f"Azure OpenAI error: {response.status_code} - {response.text}")
    
    try:
        # Parse the response
        response_data = response.json()
        
        # Extract the content from the response
        if 'choices' in response_data and len(response_data['choices']) > 0:
            content = response_data['choices'][0].get('message', {}).get('content', '')
        else:
            # If the response doesn't have the expected structure, try to use it as is
            content = json.dumps(response_data)
            
        # Extract JSON from markdown code blocks if present
        if '```json' in content:
            # Handle ```json ... ``` format
            json_str = content.split('```json')[1].split('```')[0].strip()
        elif '```' in content:
            # Handle ``` ... ``` format
            json_str = content.split('```')[1].split('```')[0].strip()
        else:
            # If no code blocks, try to parse the whole content as JSON
            json_str = content.strip()
        
        # Clean up any remaining markdown or extra text
        json_str = json_str.strip().lstrip('```').rstrip('```').strip()
        
        # Parse the JSON
        try:
            slides = json.loads(json_str)
        except json.JSONDecodeError as e:
            # If parsing fails, try to handle the content as a direct JSON string
            try:
                slides = json.loads(content)
            except json.JSONDecodeError:
                # If still failing, wrap the content in a list
                slides = [{"title": "Presentation", "content": content}]
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error parsing LLM response: {e}\nRaw: {content}")
    # Load template
    template_path = os.path.join("templates", "1.pptx")
    if not os.path.exists(template_path):
        raise HTTPException(status_code=500, detail="PPT template not found in templates/1.pptx")
    prs = Presentation(template_path)
    # Title slide (already present in template)
    if slides and isinstance(slides, list) and len(slides) > 0:
        title_slide_data = slides[0]
        first_slide = prs.slides[0]
        if first_slide.shapes.title and "title" in title_slide_data:
            first_slide.shapes.title.text = title_slide_data["title"]
        subtitle_text = title_slide_data.get("subtitle", "Presentation")
        subtitle_set = False
        try:
            if len(first_slide.placeholders) > 1:
                first_slide.placeholders[1].text = subtitle_text
                subtitle_set = True
        except Exception:
            pass
        if not subtitle_set:
            for placeholder in first_slide.placeholders:
                if (getattr(placeholder, 'placeholder_format', None) and getattr(placeholder.placeholder_format, 'idx', None) == 1):
                    placeholder.text = subtitle_text
                    subtitle_set = True
                    break
    # Table of Contents slide (2nd slide)
    toc_slide_layout = prs.slide_layouts[1]  # Use content layout
    toc_slide = prs.slides.add_slide(toc_slide_layout)
    toc_slide.shapes.title.text = "Table of Contents"
    toc_content = toc_slide.placeholders[1]
    toc_content.text = ""
    
    # Track seen chapters to prevent duplicates
    seen_chapters = set()
    valid_slides = []
    
    # First pass: Filter out duplicate chapters
    for slide in slides[1:]:  # Skip title slide
        if not isinstance(slide, dict):
            continue
            
        slide_title = slide.get("title", "")
        if 'Chapter ' in slide_title:
            # Extract chapter number to check for duplicates
            chapter_num = slide_title.split(':')[0].strip()
            if chapter_num in seen_chapters:
                #print(f"Skipping duplicate chapter: {slide_title}")
                continue
            seen_chapters.add(chapter_num)
        valid_slides.append(slide)
    
    # Add TOC entries
    for idx, slide in enumerate(valid_slides, start=2):  # Start from 2 (after title and TOC)
        slide_title = slide.get("title", f"Slide {idx}")
        para = toc_content.text_frame.add_paragraph()
        para.text = f"{slide_title}"  # Adjust index for 1-based TOC
        para.level = 0
        para.font.bold = False
        para.font.size = Pt(20)
    
    # Process each content slide
    for slide_data in valid_slides:
        slide_title = slide_data.get("title", "")
        bullets = slide_data.get("bullets", [])
        
        # Create content slide
        content_slide_layout = prs.slide_layouts[1]
        slide = prs.slides.add_slide(content_slide_layout)
        slide.shapes.title.text = slide_title
        
        # Add content with headers and subpoints
        if len(slide.placeholders) > 1 and bullets and isinstance(bullets, list):
            content = slide.placeholders[1]
            text_frame = content.text_frame
            # When using paragraph style, reserve right side for image and prevent overlap
            if style_mode == "paragraph":
                try:
                    # Left margin ~0.5 in (36pt), reserve ~300pt on right for image + gutter
                    content.left = Pt(36)
                    content.width = prs.slide_width - Pt(36) - Pt(300) - Pt(18)
                    # Position content just below the title to avoid overlap
                    title_shape = slide.shapes.title
                    top_margin = Pt(8)
                    content.top = title_shape.top + title_shape.height + top_margin
                    bottom_margin = Pt(36)
                    content.height = prs.slide_height - content.top - bottom_margin
                except Exception:
                    pass
                try:
                    text_frame.word_wrap = True
                except Exception:
                    pass
            text_frame.text = ""
            
            current_paragraph = None
            
            # Enforce a strict 250-word cap per slide in paragraph mode
            cumulative_words = 0 if style_mode == "paragraph" else None
            for bullet in bullets:
                if not bullet.strip():
                    continue

                if style_mode == "paragraph":
                    # Render headers (##) as bold without the prefix; others as normal paragraphs
                    para = text_frame.add_paragraph()
                    txt = bullet.strip()
                    if txt.startswith("## "):
                        # Respect word cap including headers (usually small)
                        header_txt = txt[3:].strip()
                        if cumulative_words is not None:
                            cumulative_words += len(header_txt.split())
                        para.text = txt[3:].strip()
                        para.level = 0
                        para.font.size = Pt(20)
                        para.font.bold = True
                        para.space_after = Pt(10)
                        # Ensure no bullets are shown
                        try:
                            p = para._p
                            pPr = p.get_or_add_pPr()
                            pPr.append(OxmlElement('a:buNone'))
                        except Exception:
                            pass
                    else:
                        # Remove leading bullet dot if present
                        if txt.startswith("• "):
                            txt = txt[1:]
                        # Enforce 250-word limit by truncating at the slide level
                        if cumulative_words is not None:
                            remaining = max(0, 250 - cumulative_words)
                            if remaining <= 0:
                                break
                            words = txt.split()
                            if len(words) > remaining:
                                txt = " ".join(words[:remaining])
                            cumulative_words += min(len(words), remaining)
                        para.text = txt
                        para.level = 0
                        para.font.size = Pt(18)
                        para.space_after = Pt(12)
                        # Ensure no bullets are shown
                        try:
                            p = para._p
                            pPr = p.get_or_add_pPr()
                            pPr.append(OxmlElement('a:buNone'))
                        except Exception:
                            pass

                elif style_mode == "numbered":
                    if bullet.startswith("## "):
                        # Keep headers
                        para = text_frame.add_paragraph()
                        para.text = bullet[3:].strip()
                        para.level = 0
                        para.font.size = Pt(20)
                        para.font.bold = True
                    else:
                        # Force numbering
                        para = text_frame.add_paragraph()
                        para.text = bullet.strip().lstrip("•").strip()
                        para.level = 1
                        para.font.size = Pt(18)
                        para.space_after = Pt(8)

                else:  # default bullets
                    if bullet.startswith("## "):
                        para = text_frame.add_paragraph()
                        para.text = bullet[3:].strip()
                        para.level = 0
                        para.font.size = Pt(20)
                        para.font.bold = True
                    elif bullet.startswith("• "):
                        para = text_frame.add_paragraph()
                        para.text = bullet[2:].strip()
                        para.level = 1
                        para.font.size = Pt(18)
                        para.space_after = Pt(8)

        
        # Try to add an image related to the slide content
        try:
            # Create a session with retry and timeout
            session = requests.Session()
            # Use certifi CA bundle to avoid InsecureRequestWarning
            session.verify = certifi.where()
            session.mount('http://', requests.adapters.HTTPAdapter(max_retries=3))
            session.mount('https://', requests.adapters.HTTPAdapter(max_retries=3))
            
            # Search for images using updated DDGS pattern
            ddgs = DDGS()  # no context manager per working example
            search_query = f"{slide_title} NCERT CBSE educational diagram"
            results = []
            try:
                results = list(ddgs.images(
                    search_query,
                    max_results=10,
                    size="Medium",
                    type_image="photo"
                ))
            except Exception as se:
                #print(f"Image search failed for '{slide_title}': {se}")
                results = []

            for img in results:
                img_url = img.get("image") or img.get("thumbnail")
                if not img_url:
                    continue
                    
                try:
                    # Download the image with timeout and retry
                    response = session.get(img_url, timeout=10, stream=True)
                    response.raise_for_status()
                    
                    # Create BytesIO object from response content
                    img_data = BytesIO(response.content)
                    
                    # Verify it's a valid image
                    try:
                        img = Image.open(img_data)
                        img.verify()  # Verify it's a valid image
                        img_data.seek(0)  # Reset the buffer position
                        
                        # Add image to slide
                        left = prs.slide_width - Pt(300)  # Position on right side
                        top = Pt(100)
                        slide.shapes.add_picture(img_data, left, top, width=Pt(250))
                        #print(f"Successfully added image for: {slide_title}")
                        break  # Success, exit the loop
                        
                    except (IOError, OSError, UnidentifiedImageError) as img_err:
                        #print(f"Invalid image format for {slide_title}: {img_err}")
                        continue
                            
                except requests.RequestException as req_err:
                    print(f"Error downloading image for {slide_title}: {req_err}")
                    continue
                        
        except Exception as e:
            #print(f"Image search/add failed for slide '{slide_title}': {str(e)}")
            continue  # Skip to the next slide if there's an error
    # Advanced styling for all slides
    for slide_idx, slide in enumerate(prs.slides):
        for shape in slide.shapes:
            if shape.has_text_frame:
                for para in shape.text_frame.paragraphs:
                    if shape == slide.shapes.title:
                        para.font.name = "Arial White"
                        para.font.size = Pt(40 if slide_idx == 0 else 32)
                        para.font.bold = True
                        para.font.color.rgb = RGBColor(255, 192, 4)  
                    else:
                        para.font.name = "Calibri"
                        para.font.size = Pt(24 if slide_idx == 0 else 14)
                        para.font.bold = False
                        para.font.color.rgb = RGBColor(0, 0, 0)  # Black
    # Generate a filename based on the input
    output_filename = f"{os.path.splitext(txt_filename)[0]}.pptx"
    ppt_dir = os.path.join(
        os.getcwd(),
        request.SchoolCode,
        request.Branch,
        request.Class,
        request.Subject,
        "Slides"
    )
    if not os.path.exists(ppt_dir):
        os.makedirs(ppt_dir)
    now_str = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    output_filename = f"{os.path.splitext(txt_filename)[0]}_{now_str}.pptx"
    output_path = os.path.join(ppt_dir, output_filename)

    prs.save(output_path)
    #print(f"Presentation saved to: {output_path}")
    if not os.path.exists(ppt_dir):
        os.makedirs(ppt_dir)
    output_path = os.path.join(ppt_dir, output_filename)
    # Save the presentation to a file
    prs.save(output_path)
    #print(f"Presentation saved to: {output_path}")
    
    # Extract slide data for the frontend
    slides_data = []
    for i, slide in enumerate(prs.slides, 1):
        slide_data = {
            "id": str(i),
            "title": f"Slide {i}",
            "content": "",
            "type": "content",
            "thumbnail": f"bg-gradient-to-br from-blue-{400 + (i*100) % 600} to-purple-{400 + (i*100) % 600}"
        }
        
        # Try to get title and content from the slide
        if slide.shapes.title:
            slide_data["title"] = slide.shapes.title.text
            
        # Get content from text boxes
        content = []
        for shape in slide.shapes:
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    content.append(paragraph.text)
        
        if content:
            slide_data["content"] = "\n".join(content)
            
        slides_data.append(slide_data)
    
    # Save to memory for the file response
    output = BytesIO()
    prs.save(output)
    output.seek(0)
    
    # Return both the file and slides data
    response = {
        "success": True,
        "filename": output_filename,
        "SchoolCode": request.SchoolCode,
        "Branch": request.Branch,
        "Class": request.Class,
        "Subject": request.Subject,
        "slides": slides_data,
        # Use repository download endpoint for repo-generated PPTs
        "download_url": f"/ExcelSchoolAI/Service/SlideGen/download_repository?school={request.SchoolCode}&branch={request.Branch}&class={request.Class}&subject={request.Subject}&filename={output_filename}",
    }
    
    return JSONResponse(content=response)



class SaveSlidesInput(BaseModel):
    custcode: str
    orgcode: str
    usercode: str
    classid: int
    subjectid: int
    chapterid: int
    unitid: int
    sessionids: str
    slidename: str
    slidedatapath: str
    slidescount: int
    # Mapping: 0 = Repository, 1 = Uploaded (passed through directly to DB)
    geneartetype: int = 0

# Download endpoint for uploaded-doc PPTs (flat)
@app.get("/ExcelSchoolAI/SlideGen/download_uploaded")
async def download_uploaded(filename: str):
    base_dir = os.getcwd()
    ppt_path = os.path.join(base_dir,"EPS", "Generated", "Slides", filename)
    if not os.path.exists(ppt_path):
        raise HTTPException(status_code=404, detail="File not found")
    return FileResponse(
        ppt_path,
        media_type="application/vnd.openxmlformats-officedocument.presentationml.presentation",
        filename=filename,
    )

# Download endpoint for repository-generated PPTs (hierarchical path)
@app.get("/ExcelSchoolAI/SlideGen/download_repository")
async def download_repository(
    school: str = Query(...),
    branch: str = Query(...),
    class_: str = Query(..., alias="class"),
    subject: str = Query(...),
    filename: str = Query(...),
):
    base_dir = os.getcwd()
    ppt_path = os.path.join(base_dir, school, branch, class_, subject, "Slides", filename)
    if not os.path.exists(ppt_path):
        raise HTTPException(status_code=404, detail="File not found")
    return FileResponse(
        ppt_path,
        media_type="application/vnd.openxmlformats-officedocument.presentationml.presentation",
        filename=filename,
    )


@app.post("/ExcelSchoolAI/SlideGen/generate_ppt_from_upload")
async def generate_ppt_from_upload(
    request: Request,
    file: Optional[UploadFile] = File(None),
    url: str = Form(""),
    additional_instructions: str = Form(""),
    # Optional metadata for saving to DB (uploaded flow)
    custcode: str = Form(""),
    orgcode: str = Form(""),
    usercode: str = Form(""),
    classid: int = Form(0),
    subjectid: int = Form(0),
    chapterid: int = Form(0),
    unitid: int = Form(0),
    sessionids: str = Form("")
    ):
    
    #print("requuest:", request, file, url, additional_instructions, custcode, orgcode, usercode, classid, subjectid, chapterid, unitid, sessionids)

    parts: list[str] = []
    base_name = None

    # If URL provided, fetch and extract text
    if url and url.strip():
        try:
            print(f"[DEBUG] [URL] Starting fetch: {url.strip()}")
            resp = requests.get(url.strip(), timeout=20, headers={
                "User-Agent": "Mozilla/5.0 (compatible; SlideGenBot/1.0)"
            })
            print(f"[DEBUG] [URL] HTTP status: {resp.status_code}")
            if resp.status_code >= 400:
                raise HTTPException(status_code=400, detail=f"Failed to fetch URL: {resp.status_code}")
            html = resp.text
            print(f"[DEBUG] [URL] HTML length: {len(html)} chars")
            soup = BeautifulSoup(html, 'html.parser')
            for tag in soup(["script", "style", "noscript"]):
                tag.decompose()
            text = soup.get_text(separator="\n")
            cleaned = "\n".join(line.strip() for line in text.splitlines() if line.strip())
            print(f"[DEBUG] [URL] Extracted text length (cleaned): {len(cleaned)} chars")
            preview = cleaned[:400].replace('\n', ' ') + ('...' if len(cleaned) > 400 else '')
            print(f"[DEBUG] [URL] Preview: {preview}")
            parts.append(f"# Web Source: {url}\n\n{cleaned}")
            try:
                from urllib.parse import urlparse
                base_name = urlparse(url).netloc.replace(':', '_')
            except Exception:
                base_name = "web-source"
        except requests.RequestException as e:
            raise HTTPException(status_code=400, detail=f"Unable to fetch URL: {e}")

    # If file provided, read and extract text
    if file is not None:
        filename = file.filename or "uploaded.txt"
        base_name = base_name or os.path.splitext(os.path.basename(filename))[0]
        lower = filename.lower()
        if not (lower.endswith(".pdf") or lower.endswith(".docx") or lower.endswith(".txt")):
            raise HTTPException(status_code=400, detail="Unsupported file type. Use PDF, DOCX, or TXT.")
        contents = await file.read()
        if len(contents) > 5 * 1024 * 1024:
            raise HTTPException(status_code=400, detail="File too large. Max 5MB.")
        print(f"[DEBUG] [FILE] Received file: {filename} ({len(contents)} bytes)")
        try:
            content_text = ""
            if lower.endswith(".pdf"):
                with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
                    tmp.write(contents)
                    tmp_path = tmp.name
                try:
                    doc = fitz.open(tmp_path)
                    for page in doc:
                        content_text += page.get_text()
                finally:
                    try:
                        os.remove(tmp_path)
                    except Exception:
                        pass
            elif lower.endswith(".docx"):
                data = contents
                with tempfile.NamedTemporaryFile(delete=False, suffix=".docx") as tmp:
                    tmp.write(data)
                    tmp_path = tmp.name
                try:
                    doc = Document(tmp_path)
                    content_text = "\n".join(p.text for p in doc.paragraphs)
                finally:
                    try:
                        os.remove(tmp_path)
                    except Exception:
                        pass
            else:  # .txt
                data = contents
                try:
                    content_text = data.decode("utf-8")
                except Exception:
                    content_text = data.decode("latin-1", errors="ignore")
        finally:
            await file.close()
        print(f"[DEBUG] [FILE] Extracted text length: {len(content_text)} chars")
        fpreview = content_text[:400].replace('\n', ' ') + ('...' if len(content_text) > 400 else '')
        print(f"[DEBUG] [FILE] Preview: {fpreview}")
        parts.append(f"# Uploaded Document: {filename}\n\n{content_text}")

    if not parts and not (additional_instructions and additional_instructions.strip()):
        raise HTTPException(status_code=400, detail="Provide a URL and/or upload a file, or add instructions.")

    full_content = "\n\n".join(parts) + "\n\n"
    if additional_instructions and additional_instructions.strip():
        full_content += f"# Additional Instructions\n\n{additional_instructions}\n\n"
    print(f"[DEBUG] [COMBINE] Sources -> URL: {bool(url and url.strip())}, File: {file is not None}, Instructions: {bool(additional_instructions and additional_instructions.strip())}")
    print(f"[DEBUG] [COMBINE] Combined content length: {len(full_content)} chars")

    # Reuse the same LLM prompt/template logic
    api_key = os.getenv("OPENAI_API_KEY")
    endpoint = os.getenv("OPENAI_DEPLOYMENT_ENDPOINT")
    deployment = os.getenv("OPENAI_DEPLOYMENT_NAME")
    api_version = os.getenv("OPENAI_DEPLOYMENT_VERSION")
    if not all([api_key, endpoint, deployment, api_version]):
        raise HTTPException(status_code=500, detail="Missing Azure OpenAI credentials in environment.")

    base_instructions = """
    You are an expert educational content organizer. Given the following content (delimited by triple backticks), create a comprehensive PowerPoint presentation. You will be provided with:
    - Unit Plan (provides the overall structure and objectives for the unit)
    - Session Plans (detailed breakdown of lessons and activities)
    - Textbook Content (from the .txt file)
    - Additional Instructions (from the user)
    
    Combine and utilize ALL these sources to generate the most effective and comprehensive slides. Prioritize the structure and objectives from the unit plan, enrich with details from session plans, and use textbook content and instructions as supporting material.
    
    For each slide (except title slide):
    1. Each slide should have a clear, descriptive title
    2. Include minimum 3 main headers per slide
    3. Under each header, include minimum 3-5 key subpoints
    4. Preserve all formulas, equations, and special characters exactly as they appear
    5. Keep content concise but informative - aim for 15-25 words per subpoint
    6. Structure the content logically based on the provided unit plans and session plans
    7. Ensure learning objectives are clearly highlighted
    8. Include practical examples and applications where relevant
    """

    # --- Detect style preference from additional instructions ---
    style_mode = "bullets"  # default

    if additional_instructions:
        lower_ai = additional_instructions.lower()
        if "paragraph" in lower_ai or "no bullet" in lower_ai:
            style_mode = "paragraph"
        elif "number" in lower_ai or "numbered" in lower_ai:
            style_mode = "numbered"

    # --- Modify base instructions dynamically ---
    if style_mode == "paragraph":
        style_instructions = """
        Format slides so that instead of bullet points, each slide has 6 paragraphs
        of text (60-80 words each). No bullet characters.
        """
    elif style_mode == "numbered":
        style_instructions = """
        Format slides with numbered lists (1., 2., 3.) instead of bullet points.
        Each header should have 3 numbered subpoints.
        """
    else:  # default bullets
        style_instructions = """
        Format slides with headers (##) and bullet points (•) under them.
        """

    instructions = f"""{base_instructions}
    {style_instructions}

    Additional Instructions from User:
    {additional_instructions}
"""

    prompt = f"""
    {instructions}
    
    Format your response as a JSON array where each object represents one slide. The first slide should be a title slide with 'title' and 'subtitle'. All other slides should have 'title' and 'bullets'.
    
    Example format (no fabricated chapter numbering):
    [
      {{
        "title": "Main Title",
        "subtitle": "Subtitle"
      }},
      {{
        "title": "Heredity: Key Concepts",
        "bullets": [
          "## Header 1",
          "• Subpoint 1.1: Key information...",
          "• Subpoint 1.2: Important details...",
          "• Subpoint 1.3: Additional information...",
          "",
          "## Header 2",
          "• Subpoint 2.1: Key information...",
          "• Subpoint 2.2: Important details...",
          "• Subpoint 2.3: Additional information...",
          "",
          "## Header 3",
          "• Subpoint 3.1: Key information...",
          "• Subpoint 3.2: Important details...",
          "• Subpoint 3.3: Additional information..."
        ]
      }}
    ]
    
    Important notes:
    - Use ## to denote headers in the bullet points
    - Keep formulas and equations exactly as they appear in the original text
    - Each slide should be information-dense but not overcrowded
    - Make sure to cover all key concepts from the content
    
    Content to analyze:
    ```{full_content}```
    """

    url = f"{endpoint}/openai/deployments/{deployment}/chat/completions?api-version={api_version}"
    headers = {"api-key": api_key, "Content-Type": "application/json"}
    payload = {
        "messages": [
            {"role": "system", "content": "You are a helpful assistant that generates PowerPoint slides as JSON."},
            {"role": "user", "content": prompt},
        ],
        "temperature": 0.5,
        "top_p": 1,
        "frequency_penalty": 0,
        "presence_penalty": 0,
    }

    response = requests.post(url, headers=headers, json=payload)
    if response.status_code != 200:
        raise HTTPException(status_code=500, detail=f"Azure OpenAI error: {response.status_code} - {response.text}")

    # Parse LLM response similar to /generate_ppt
    try:
        response_data = response.json()
        if "choices" in response_data and len(response_data["choices"]) > 0:
            content = response_data["choices"][0].get("message", {}).get("content", "")
        else:
            content = json.dumps(response_data)

        if "```json" in content:
            json_str = content.split("```json")[1].split("```")[0].strip()
        elif "```" in content:
            json_str = content.split("```")[1].split("```")[0].strip()
        else:
            json_str = content.strip()

        json_str = json_str.strip().lstrip("```").rstrip("```").strip()
        try:
            slides = json.loads(json_str)
        except json.JSONDecodeError:
            try:
                slides = json.loads(content)
            except json.JSONDecodeError:
                slides = [{"title": "Presentation", "content": content}]
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error parsing LLM response: {e}\nRaw: {content}")

    # Build PPT using same template
    template_path = os.path.join("templates", "1.pptx")
    if not os.path.exists(template_path):
        raise HTTPException(status_code=500, detail="PPT template not found in templates/1.pptx")
    prs = Presentation(template_path)

    if slides and isinstance(slides, list) and len(slides) > 0:
        title_slide_data = slides[0]
        first_slide = prs.slides[0]
        if first_slide.shapes.title and "title" in title_slide_data:
            first_slide.shapes.title.text = title_slide_data["title"]
        subtitle_text = title_slide_data.get("subtitle", "Presentation")
        try:
            if len(first_slide.placeholders) > 1:
                first_slide.placeholders[1].text = subtitle_text
        except Exception:
            pass

    toc_slide_layout = prs.slide_layouts[1]
    toc_slide = prs.slides.add_slide(toc_slide_layout)
    toc_slide.shapes.title.text = "Table of Contents"
    toc_content = toc_slide.placeholders[1]
    toc_content.text = ""

    seen_chapters = set()
    valid_slides = []
    for slide in slides[1:]:
        if not isinstance(slide, dict):
            continue
        slide_title = slide.get("title", "")
        if "Chapter " in slide_title:
            chapter_num = slide_title.split(":")[0].strip()
            if chapter_num in seen_chapters:
                continue
            seen_chapters.add(chapter_num)
        valid_slides.append(slide)

    for idx, s in enumerate(valid_slides, start=2):
        slide_title = s.get("title", f"Slide {idx}")
        para = toc_content.text_frame.add_paragraph()
        para.text = f"{slide_title}"
        para.level = 0
        para.font.bold = False
        para.font.size = Pt(20)

    # Process each content slide
    for slide_data in valid_slides:
        slide_title = slide_data.get("title", "")
        bullets = slide_data.get("bullets", [])
        
        # Create content slide
        content_slide_layout = prs.slide_layouts[1]
        slide = prs.slides.add_slide(content_slide_layout)
        slide.shapes.title.text = slide_title
        if len(slide.placeholders) > 1 and bullets and isinstance(bullets, list):
            content = slide.placeholders[1]
            text_frame = content.text_frame
            if style_mode == "paragraph":
                try:
                    content.left = Pt(36)
                    content.width = prs.slide_width - Pt(36) - Pt(300) - Pt(18)
                    title_shape = slide.shapes.title
                    top_margin = Pt(8)
                    content.top = title_shape.top + title_shape.height + top_margin
                    bottom_margin = Pt(36)
                    content.height = prs.slide_height - content.top - bottom_margin
                except Exception:
                    pass
                try:
                    text_frame.word_wrap = True
                except Exception:
                    pass
            text_frame.text = ""
            
            current_paragraph = None
            cumulative_words = 0 if style_mode == "paragraph" else None
            for bullet in bullets:
                if not bullet.strip():
                    continue

                if style_mode == "paragraph":
                    # Render headers (##) as bold without the prefix; others as normal paragraphs
                    para = text_frame.add_paragraph()
                    txt = bullet.strip()
                    if txt.startswith("## "):
                        header_txt = txt[3:].strip()
                        if cumulative_words is not None:
                            cumulative_words += len(header_txt.split())
                        para.text = header_txt
                        para.level = 0
                        para.font.size = Pt(20)
                        para.font.bold = True
                        para.space_after = Pt(10)
                        # Ensure no bullets are shown
                        try:
                            p = para._p
                            pPr = p.get_or_add_pPr()
                            pPr.append(OxmlElement('a:buNone'))
                        except Exception:
                            pass
                    else:
                        if txt.startswith("• "):
                            txt = txt[2:].strip()
                        if cumulative_words is not None:
                            remaining = max(0, 250 - cumulative_words)
                            if remaining <= 0:
                                break
                            words = txt.split()
                            if len(words) > remaining:
                                txt = " ".join(words[:remaining])
                            cumulative_words += min(len(words), remaining)
                        para.text = txt
                        para.level = 0
                        para.font.size = Pt(18)
                        para.space_after = Pt(12)
                        # Ensure no bullets are shown
                        try:
                            p = para._p
                            pPr = p.get_or_add_pPr()
                            pPr.append(OxmlElement('a:buNone'))
                        except Exception:
                            pass

                elif style_mode == "numbered":
                    if bullet.startswith("## "):
                        # Keep headers
                        para = text_frame.add_paragraph()
                        para.text = bullet[3:].strip()
                        para.level = 0
                        para.font.size = Pt(20)
                        para.font.bold = True
                    else:
                        # Force numbering
                        para = text_frame.add_paragraph()
                        para.text = bullet.strip().lstrip("•").strip()
                        para.level = 1
                        para.font.size = Pt(18)
                        para.space_after = Pt(8)

                else:  # default bullets
                    if bullet.startswith("## "):
                        para = text_frame.add_paragraph()
                        para.text = bullet[3:].strip()
                        para.level = 0
                        para.font.size = Pt(20)
                        para.font.bold = True
                    elif bullet.startswith("• "):
                        para = text_frame.add_paragraph()
                        para.text = bullet[2:].strip()
                        para.level = 1
                        para.font.size = Pt(18)
                        para.space_after = Pt(8)

        

        # Try to add an image related to the slide content (mirror logic from /generate_ppt)
        try:
            session = requests.Session()
            session.verify = certifi.where()
            session.mount('http://', requests.adapters.HTTPAdapter(max_retries=3))
            session.mount('https://', requests.adapters.HTTPAdapter(max_retries=3))

            ddgs = DDGS()
            search_query = f"{slide_title} NCERT CBSE"
            results = []
            try:
                results = list(ddgs.images(
                    search_query,
                    max_results=10,
                    size="Medium",
                    type_image="photo"
                ))
            except Exception:
                results = []

            for img in results:
                img_url = img.get("image") or img.get("thumbnail")
                if not img_url:
                    continue
                try:
                    resp = session.get(img_url, timeout=10, stream=True)
                    resp.raise_for_status()
                    img_data = BytesIO(resp.content)
                    # Validate it's an image
                    try:
                        _img = Image.open(img_data)
                        _img.verify()
                        img_data.seek(0)
                    except Exception:
                        continue
                    # Add to slide
                    left = prs.slide_width - Pt(300)
                    top = Pt(100)
                    slide.shapes.add_picture(img_data, left, top, width=Pt(250))
                    break
                except requests.RequestException:
                    continue
        except Exception:
            pass

    for slide_idx, slide in enumerate(prs.slides):
        for shape in slide.shapes:
            if shape.has_text_frame:
                for para in shape.text_frame.paragraphs:
                    if shape == slide.shapes.title:
                        para.font.name = "Arial White"
                        para.font.size = Pt(40 if slide_idx == 0 else 32)
                        para.font.bold = True
                        para.font.color.rgb = RGBColor(255, 192, 4)  # HEX #ffc404
                    else:
                        para.font.name = "Calibri"
                        para.font.size = Pt(24 if slide_idx == 0 else 14)
                        para.font.bold = False
                        para.font.color.rgb = RGBColor(0, 0, 0)

    # Determine a safe base name for the output file
    if not base_name or not str(base_name).strip():
        base_name = "presentation"
    now_str = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    output_filename = f"{base_name}_{now_str}.pptx"
    print(f"[DEBUG] [SAVE] Output filename: {output_filename}")    
    # Save under a generic folder for uploaded-doc PPTs
    ppt_dir = os.path.join(os.getcwd(), "EPS", "Generated","Slides")
    if not os.path.exists(ppt_dir):
        os.makedirs(ppt_dir)
    output_path = os.path.join(ppt_dir, output_filename)
    prs.save(output_path)

    slides_data = []
    for i, slide in enumerate(prs.slides, 1):
        slide_data = {
            "id": str(i),
            "title": slide.shapes.title.text if slide.shapes.title else f"Slide {i}",
            "content": "",
            "type": "content",
            "thumbnail": f"bg-gradient-to-br from-blue-{400 + (i*100) % 600} to-purple-{400 + (i*100) % 600}",
        }
        content_lines = []
        for shape in slide.shapes:
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    content_lines.append(paragraph.text)
        if content_lines:
            slide_data["content"] = "\n".join(content_lines)
        slides_data.append(slide_data)
    base_url = str(request.base_url).rstrip("/")
    download_url = f"/ExcelSchoolAI/Service/SlideGen/download_uploaded?filename={output_filename}"
    absolute_download_url = f"{base_url}{download_url}"

    # Save into DB using existing save_slides endpoint logic (uploaded flow -> geneartetype=1)
    save_payload = SaveSlidesInput(
        custcode=custcode or "",
        orgcode=orgcode or "",
        usercode=usercode or "",
        classid=int(classid) if classid is not None else 0,
        subjectid=int(subjectid) if subjectid is not None else 0,
        chapterid=int(chapterid) if chapterid is not None else 0,
        unitid=int(unitid) if unitid is not None else 0,
        sessionids=sessionids or "",
        slidename=output_filename,
        slidedatapath=absolute_download_url,
        slidescount=len(prs.slides) if 'prs' in locals() else 0,
        geneartetype=1,
    )
    db_result = None
    try:
        db_result = await save_slides(save_payload)
    except Exception as e:
        db_result = {"db_status_code": -1, "error": str(e)}

    return JSONResponse(
        content={
            "success": True,
            "filename": output_filename,
            "slides": slides_data,
            "download_url": download_url,
            "db_save": db_result,
        }
    )

class GetSlidesInput(BaseModel):
    custcode: str
    orgcode: str
    usercode: str
    classid: int
    subjectid: int
    chapterid: int
    searchtext: str = ""
    # Mapping: 0 = Repository, 1 = Uploaded (passed through directly to DB)
    geneartetype: int = 0

class DeleteSlideInput(BaseModel):
    slideid: int



# Save Slides Endpoint
@app.post("/ExcelSchoolAI/SlideGen/save-slides")
async def save_slides(input: SaveSlidesInput):
    
    conn = None
    try:
        conn = getdb_connection()
        status=''
        with conn.cursor() as cursor:
            cursor.execute("""
                CALL slidegenerator.uspsaveslides(
                %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s
            )
            """, (
                input.custcode, input.orgcode, input.usercode,
                input.classid, input.subjectid, input.chapterid,
                input.unitid, input.sessionids, input.slidename,
                input.slidedatapath, input.slidescount,status, input.geneartetype
            ))

            par_status = cursor.fetchone()[0]  # Get OUT value
            conn.commit()

        print(f"PAR_STATUS: {par_status}")
        db_status_code = 1 if par_status and par_status.lower() == "success" else 0
        return {"db_status_code": db_status_code, "status": par_status or "Unknown"}

    except Exception as e:
        return {"db_status_code": 500, "error": str(e)}
    finally:
        if conn:
            conn.close()


# Get Slide Data
@app.post("/ExcelSchoolAI/SlideGen/get-slide-data")
async def get_slide_data(input: GetSlidesInput):
    try:
        with getdb_connection() as conn:
            with conn.cursor(cursor_factory=RealDictCursor) as cursor:
                cursor.execute("BEGIN;")
                
                # Use CALL instead of callproc for full control
                cursor.execute("""
                    CALL slidegenerator.uspgetslidedata(
                        %s, %s, %s, %s, %s, %s, %s, %s, %s
                    );
                """, [
                    input.custcode,
                    input.orgcode,
                    input.usercode,
                    input.classid,
                    input.subjectid,
                    input.chapterid,
                    input.searchtext,
                    'slide_cursor',
                    input.geneartetype
                ])
                
                # Fetch from the refcursor
                cursor.execute("FETCH ALL FROM slide_cursor;")
                result_rows = cursor.fetchall()
                
                # Close the cursor
                cursor.execute("CLOSE slide_cursor;")
                conn.commit()
                
                return {"db_status_code": 1, "slides": result_rows}
    except Exception as e:
        return {"db_status_code": -999, "error": str(e), "slides": []}

#  Delete Slide
@app.post("/ExcelSchoolAI/Service/SlideGen/delete-slide")
async def delete_slide(input: DeleteSlideInput):
    conn = None
    try:
        conn = getdb_connection()
        with conn.cursor() as cursor:
            cursor.execute("BEGIN;")
            cursor.execute("""
                DO $$
                DECLARE
                    status_text VARCHAR;
                BEGIN
                    CALL slidegenerator.uspdeleteslid(%s, status_text);
                    RAISE NOTICE 'STATUS_TEXT: %%', status_text;
                END $$;
            """, (input.slideid,))
            # Extract status_text from server notices
            status_text = None
            for notice in conn.notices:
                if 'STATUS_TEXT:' in notice:
                    status_text = notice.split('STATUS_TEXT:')[1].strip().replace('"', '').replace("'", "")
            conn.notices.clear()
            cursor.execute("COMMIT;")
        db_status_code = 1 if status_text and status_text.lower() == 'success' else 0
        return {"db_status_code": db_status_code, "status": status_text or "Unknown"}
    except Exception as e:
        db_status_code = 500
        return {"db_status_code": db_status_code, "error": str(e), "status": "Error"}
    finally:
        if conn:
            conn.close()

# Download endpoint for uploaded-doc PPTs (flat)
@app.get("/ExcelSchoolAI/SlideGen/download_uploaded")
async def download_uploaded(filename: str):
    base_dir = os.getcwd()
    ppt_path = os.path.join(base_dir,"EPS", "Generated", "Slides", filename)
    if not os.path.exists(ppt_path):
        raise HTTPException(status_code=404, detail="File not found")
    return FileResponse(
        ppt_path,
        media_type="application/vnd.openxmlformats-officedocument.presentationml.presentation",
        filename=filename,
    )
   

# Add this at the end of the file to run the FastAPI app
if __name__ == "__main__":
    import uvicorn
    #uvicorn.run("tdr:app", host="0.0.0.0", port=8000, reload=True)
    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("FLASK_RUN_PORT_Slide", 8069)))