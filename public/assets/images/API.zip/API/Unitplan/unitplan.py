from fastapi import FastAPI, HTTPException,Request, File, UploadFile
from fastapi.responses import StreamingResponse
from playwright.async_api import async_playwright
import io
import pickle
import PyPDF2
import aiofiles
import shutil
import numpy as np
import faiss
from sentence_transformers import SentenceTransformer
from pydantic import BaseModel
from dotenv import load_dotenv
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from typing import List, Tuple, Union, Optional, Dict, Any
from crewai import Agent, Task, Crew, Process, LLM
import os
import json
from enum import Enum
import logging
import openai
from openai import AzureOpenAI
import re
import psycopg2.extras
import psycopg2
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
import os
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np


# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI()

# ---------- Textbook Retrieval (from .txt files) ----------
EPS_BASE_DIR = r"F:\SarasApplicationDeployment\ExcelSchoolAI\Service\UnitPlan\BookContent\EPS\Koorgalli"

def get_chapter_text_from_eps(grade: str, subject: str, chapter: str) -> str | None:
    """
    Dynamically finds and reads a chapter's .txt file from the EPS directory structure.
    """
    chapter = chapter.replace("?", "")
    logger.info(f"Attempting to find chapter '{chapter}' for grade '{grade}', subject '{subject}' in {EPS_BASE_DIR}")
    
    # Grade mapping
    grade_map = {"10": "X", "9": "IX", "8": "VIII", "7": "VII", "6": "VI", "5": "V", "4": "IV", "3": "III", "11": "XI"}
    grade_dir = grade_map.get(str(grade).lower(), str(grade))

    def normalize(name: str) -> str:
        return ''.join(e for e in name if e.isalnum()).lower()

    try:
        grade_path = os.path.join(EPS_BASE_DIR, grade_dir)
        if not os.path.exists(grade_path):
            logger.warning(f"Grade directory not found: {grade_path}")
            return None

        # Find subject directory, handling "Science" and "General Science" as synonyms
        subject_path = None
        norm_subject = normalize(subject)
        science_synonyms = {"science", "generalscience"}
        
        for s_dir in os.listdir(grade_path):
            norm_s_dir = normalize(s_dir)
            # Direct match
            if norm_s_dir == norm_subject:
                subject_path = os.path.join(grade_path, s_dir)
                break
            # Synonym match for Science/General Science
            if norm_subject in science_synonyms and norm_s_dir in science_synonyms:
                subject_path = os.path.join(grade_path, s_dir)
                break
        
        if not subject_path:
            logger.warning(f"Subject directory '{subject}' not found in {grade_path}")
            return None

        # Find chapter directory
        chapter_path = None
        norm_chapter = normalize(chapter)
        for c_dir in os.listdir(subject_path):
            if normalize(c_dir) == norm_chapter:
                chapter_path = os.path.join(subject_path, c_dir)
                break

        if not chapter_path:
            logger.warning(f"Chapter directory '{chapter}' not found in {subject_path}")
            return None

        # Find and read the .txt file
        for file in os.listdir(chapter_path):
            if file.endswith(".txt"):
                txt_file_path = os.path.join(chapter_path, file)
                with open(txt_file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                logger.info(f"Successfully loaded content from {txt_file_path}")
                return content
        
        logger.warning(f"No .txt file found in {chapter_path}")
        return None

    except Exception as e:
        logger.error(f"Error in get_chapter_text_from_eps: {e}")
        return None

def read_pdf(file_path: str) -> str:
    """Extracts text from a PDF file."""
    try:
        with open(file_path, "rb") as f:
            reader = PyPDF2.PdfReader(f)
            text = ""
            for page in reader.pages:
                text += page.extract_text() or ""
        return text
    except Exception as e:
        logger.error(f"Error reading PDF {file_path}: {e}")
        return ""

def read_txt(file_path: str) -> str:
    """Reads text from a TXT file."""
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            return f.read()
    except Exception as e:
        logger.error(f"Error reading TXT {file_path}: {e}")
        return ""

@app.post("/ExcelSchoolAI/UnitPlan/upload-file")
async def upload_file(file: UploadFile = File(...)):
    temp_dir = "temp_uploads"
    os.makedirs(temp_dir, exist_ok=True)
    file_path = os.path.join(temp_dir, file.filename)
    
    try:
        async with aiofiles.open(file_path, 'wb') as out_file:
            content = await file.read()
            await out_file.write(content)
        
        return {"file_path": file_path}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"File upload failed: {str(e)}")

load_dotenv()

os.environ["OPENAI_API_KEY"] = os.getenv("OPENAI_API_KEY")
os.environ["AZURE_API_KEY"] = os.getenv("OPENAI_API_KEY")
os.environ["AZURE_API_BASE"] = os.getenv("OPENAI_DEPLOYMENT_ENDPOINT")
os.environ["AZURE_API_VERSION"] = "2025-01-01-preview"



openai.api_type = os.getenv("OPENAI_API_TYPE", "azure")
openai.api_base = os.getenv("OPENAI_DEPLOYMENT_ENDPOINT")
openai.api_version = os.getenv("OPENAI_DEPLOYMENT_VERSION", "2023-07-01-preview")
openai.api_key = os.getenv("OPENAI_API_KEY")
AZURE_DEPLOYMENT_NAME = os.getenv("OPENAI_DEPLOYMENT_NAME")
AZURE_OPENAI_VERSION = os.getenv("OPENAI_API_VERSION", "2023-05-15")

# AzureOpenAI client
client = AzureOpenAI(
    api_key=openai.api_key,
    api_version=AZURE_OPENAI_VERSION,
    azure_endpoint=openai.api_base
)




# Configuration
class Config:
    MODEL_NAME = "azure/iic-gpt-4.1"
    AZURE_API_KEY="BeAtRq9WxQQoV7a3Ul3t5AxZKNb0vB5VlsyS6cOiWiHW2ZQbrXavJQQJ99BEACHYHv6XJ3w3AAAAACOGPVX2"
    AZURE_API_BASE="https://sridh-maclmc4d-eastus2.openai.azure.com/"
    AZURE_API_VERSION="2025-01-01-preview"


# DB configuration
DB_HOST = "10.1.0.6"
DB_PORT = 5432
DB_USER = "ailevate"
DB_PASS = "ail3v@teu$er"
DB_NAME = "ExcelschoolAI"

def get_db_connection():
    return psycopg2.connect(
        host=DB_HOST,
        port=DB_PORT,
        database=DB_NAME,
        user=DB_USER,
        password=DB_PASS
    )


def get_exceschoolai_db_connection():
    connection = psycopg2.connect(
        dbname="ExcelschoolAI",
        user="ailevate",
        password="ail3v@teu$er",
        host="10.1.0.6",
        port=5432
    )
    return connection

# Request schema
class UnitPlanRequest(BaseModel):
    board: str
    grade: str
    subject: str
    chapter: str
    core_objectives: List[str]
    skills: List[str]
    attitudes: List[str]
    learning_outcomes: List[str]
    taxonomy_levels: str



# ---------- Models ----------
class CourseOutcome(BaseModel):
    co_id: str
    co_title: str
    co_description: str
    factor: str
    skills: List[str] = []
    competencies: List[str] = []

class CO(BaseModel):
    co_id: str
    co_title: str
    co_description: str
    factor: str
    skills: List[str]

class CourseOutcomeWithSkills(CourseOutcome):
    skills: List[str]

class CourseOutcomeWithAll(CourseOutcomeWithSkills):
    attitudes: str
    elos: List[str]

class CourseOutcomesRequest(BaseModel):
    board: str
    grade: str
    subject: str
    chapter: str
    file_path: Optional[str] = None

class CourseOutcomesResponse(BaseModel):
    board: str
    grade: str
    subject: str
    chapter: str
    total_outcomes: int
    course_outcomes: List[CourseOutcome]

class RegenerateCourseOutcomeRequest(BaseModel):
    board: str
    grade: str
    subject: str
    chapter: str
    file_path: Optional[str] = None
    co_to_regenerate: CourseOutcome
    other_cos: List[CourseOutcome]

class COResponse(BaseModel):
    board: str
    grade: str
    subject: str
    chapter: str
    total_outcomes: int
    course_outcomes: List[CO]

class CourseOutcomesInput(CourseOutcomesResponse):
    file_path: Optional[str] = None

class COInput(COResponse):
    file_path: Optional[str] = None

class CourseOutcomeWithCompetencies(CourseOutcome):
    skills: List[str]
    competencies: List[str]

class ELORequestData(BaseModel):
    board: str
    grade: str
    subject: str
    chapter: str
    course_outcomes: List[dict]
    blooms_elo_counts: dict[str, int]
    skills: List[str]
    competencies: List[str]
    attitudes: List[str]
    file_path: Optional[str] = None

class InputData(BaseModel):
    board: str
    grade: str
    subject: str
    chapter: str
    total_outcomes: int
    course_outcomes: List[CourseOutcomeWithCompetencies]


class AssessmentItem(BaseModel):
    question: str
    itemType: str
    answer: str
    bloomsLevel: str
    options: Optional[List[str]] = None
    context: Optional[str] = None

class AssessmentDetail(BaseModel):
    itemType: str
    noOfItems: int
    includeLOTS: bool
    bloomsLevel: Optional[str] = None

class AssessmentRequest(BaseModel):
    grade: str
    subject: str
    topic: str
    elo: str
    course_outcome: Optional[str] = None
    core_objectives: Optional[List[str]] = None
    assessment_details: List[AssessmentDetail]
    file_path: Optional[str] = None
    Bloom_level: Optional[str] = None


class HTMLContent(BaseModel):
    html: str


# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

class UnitPlanGenerator:
    def __init__(self):
        self.llm = self._configure_llm()
        self.agent = self._create_agent()

    def _configure_llm(self):
        llm = LLM(
            model=Config.MODEL_NAME,
            api_key=Config.AZURE_API_KEY,
            api_base=Config.AZURE_API_BASE,
            api_version=Config.AZURE_API_VERSION,
            temperature=0.6,
            max_tokens=8000
        )
        return llm

    def _create_agent(self):
        return Agent(
            role="Senior Curriculum Designer",
            backstory=(
                "An expert educator with 35+ years experience in curriculum design, "
                "specializing in creating detailed, engaging, and pedagogically sound unit plans "
                "that connect concepts to real-world applications and values."
            ),
            goal="Generate comprehensive chemistry unit plans with detailed explanations, real-world connections, and clear pedagogical structure",
            llm=self.llm,
            verbose=True
        )

    def generate(self, request: UnitPlanRequest):
        try:
            task = Task(
                description=self._create_prompt(request),
                expected_output= "A comprehensive unit plan with detailed explanations in the exact required format, "
                    "including core objectives with values/skills labels, learning outcomes, progression, "
                    "assessment items, assignments, and experiential learning activities.",
                agent=self.agent
            )
            
            crew = Crew(
                agents=[self.agent],
                tasks=[task],
                process=Process.sequential
            )
            
            result = crew.kickoff()
            answer = result.raw
            return {"unit_plan": answer}
            
        except Exception as e:
            logger.error(f"Generation error: {str(e)}")
            raise
    # 🔁 Global function to build ELO prompt


    def _create_prompt(self, request: UnitPlanRequest) -> str:
        return f"""
        Input Parameters:
        - Board: {request.board}
        - Grade: {request.grade}
        - Subject: {request.subject}
        - Chapter/Unit: {request.chapter}
        - Core Objectives: {"; ".join(request.core_objectives)}
        - Skills to Develop: {"; ".join(request.skills)}
        - Attitudes to Foster: {"; ".join(request.attitudes)}
        - Learning Outcomes: {"; ".join(request.learning_outcomes)}
        - Taxonomy Levels: {"; ".join(request.taxonomy_levels)}

        Additional Prompts:
        - Planning of teaching which includes content analysis, identification and writing of objectives.
        - The only true teacher is he who can immediately come down to the level of the student, and transfer his soul to the student's soul.
        - Lesson plan need to be dynamic to accommodate the changes that may occur during the transaction. The scope of the lesson plan to be such that all the stakeholders’ students, parents get the clarity of the transaction that could have happened in the class.

        IMPORTANT: Write "core objectives" for the specific chapter/unit, NOT broad course outcomes.

        Definition:
        - Core objectives are specific, actionable, and focused learning goals for this chapter/unit. They should be directly tied to the board, grade, subject, and chapter/unit, and describe what students should be able to do or understand by the end of this chapter/unit.
        - Core objectives are NOT general course outcomes. Do NOT write broad, year-long, or subject-wide outcomes.

        Examples:
        | Type             | Example                                                                                   |
        |------------------|-------------------------------------------------------------------------------------------|
                    "step": "Step description",
                    "rationale": "Why this step matters",
                    "example": "Concrete example",
                    "connection": "How it builds on previous steps"
                }},
                // More steps...
            ],
            "assessment": {{
                "stimulus": "Real-world scenario",
                "stem": "Thought-provoking question",
                "questions": [
                    {{
                        "type": "Application/Analysis/Reflection/Group Activity",
                        "text": "Question text"
                    }},
                    // More questions...
                ]
            }},
            "assignments": [
                {{
                    "title": "Assignment name",
                    "purpose": "Detailed purpose statement"
                }},
                // More assignments...
            ],
            "learningExperiences": [
                {{
                    "phase": "Engage/Explore/Explain/Elaborate/Evaluate",
                    "activities": [
                        "Activity description",
                        "Materials/process if needed",
                        // More activities...
                    ]
                }},
                // More phases...
            ]
        }}
        """


@app.post("/ExcelSchoolAI/UnitPlan/generate-unit-plan")
async def generate_unit_plan(request: UnitPlanRequest):
    try:
        generator = UnitPlanGenerator()
        result = generator.generate(request)
        return {
            "status": "success",
            "unit_plan": result["unit_plan"]
        }
    except Exception as e:
        logger.error(f"API error: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail={
                "status": "error",
                "message": str(e)
            }
        )


def build_elo_prompt(count: int, bloom_level: str, data: ELORequestData, co_summary: str, reference_context: str | None = None) -> str:
    base_prompt = f"""
        You are an expert in outcomes-based education, tasked with creating Expected Learning Outcomes (ELOs) for a lesson plan.

        **Educational Context:**
        - Board: {data.board}
        - Grade: {data.grade}
        - Subject: {data.subject}
        - Chapter: '{data.chapter}'

        **Definition of Learning Outcomes:**
        Learning outcomes are statements that describe significant and essential learning that learners have achieved and can reliably demonstrate at the end of a course or program. 
        They focus on results of the learning experience (the "exit behaviors") rather than the process, answering the question:
        *"What should the student be able to DO by the end of this lesson?"*

        **Philosophy and Characteristics of High-Quality Learning Outcomes:**
        - Reflect essential knowledge, skills, and attitudes (Knowledge, Skills, Attitudes).
        - Focus on broad conceptual knowledge and transferable skills, not on specific teaching methods.
        - Represent observable, measurable, and verifiable performances (minimum acceptable level of achievement).
        - Be student-centric and action-oriented, preferably stating only one performance per outcome.
        - Align with Bloom’s taxonomy (Cognitive, Affective, Psychomotor domains).
        - Promote equity, fairness, and accessibility, ensuring diverse learners can achieve them.

        **Anatomy of a Learning Outcome Statement:**
        1. **Action Verb** – identifies the performance to be demonstrated, aligned to the '{bloom_level}' level of Bloom’s Taxonomy.
        2. **Learning Statement** – specifies what knowledge/skill/attitude will be demonstrated.
        3. **Criterion/Standard** – broad statement that defines acceptable performance.

        **Guidelines for Writing Course Learning Outcomes:**
        - State clear expectations so learners know what to demonstrate.
        - Describe significant and transferable performances that represent culminating achievements.
        - Avoid multiple performances in one outcome.
        - Ensure outcomes are derived from the chapter’s core objectives and context.
        - Represent essential learning that has value beyond the immediate lesson.
        - ELOs to be unique and distinctive.
        - Avoid mulitiple actions in ELo's.Each Elo should have only one action.
        - Use varied formats such as observation, discussion, creative expression, critical thinking, and problem-solving. Each ELO should feel distinct in both purpose and activity.
        - Learning outcomes statements may be considered to be exit behaviors

        **Core Task:**
        Generate exactly **{count}** distinct Expected Learning Outcomes (ELOs) at the **'{bloom_level}' level** of Bloom's Taxonomy.Each ELO should be unique and explore a different cognitive level from Bloom’s Taxonomy. Avoid rephrasing the same idea—each ELO must target a different skill or learning behavior (e.g., describing, analyzing, evaluating, creating). Ensure that the ELOs collectively reflect the full depth of the objective, with no overlap in intent or expression.

        **Context for this Chapter:**
        - Core Objectives Summary: {co_summary}
        - Key Skills: {', '.join(data.skills)}
        - Key Competencies: {', '.join(data.competencies)}
        - Attitudes to Foster: {', '.join(data.attitudes)}

        **Final Output Instructions:**
        - Produce a valid JSON array containing exactly **{count}** strings.
        - Each string must be a complete ELO statement of the form:
          "[action verb] [learning statement] [criterion/standard]."

        **Example Output Format:**
        ```json
        [
          "Analyze the causes of the French Revolution using primary source documents to justify their conclusions.",
          "Construct a timeline of the Napoleonic era events, demonstrating accurate sequencing and historical understanding."
        ]
        ```
    """
    if reference_context:
        return base_prompt + "\n\n**Reference Context (Textbook):**\n" + reference_context
    return base_prompt

# ---------- Endpoint 1: Generate Course Outcomes ----------
def create_co_prompt(request: CourseOutcomesRequest, reference_context: str | None = None) -> str:
    base = f"""
        You are an expert curriculum designer tasked with creating 'Core Objectives' (COs) for a lesson plan.

        **Educational Context:**
        - Board: {request.board}
        - Grade: {request.grade}
        - Subject: {request.subject}
        - Chapter: "{request.chapter}"

        **Understanding Core Objectives:**
        When surveying a chapter, knowledge can be classified into three categories:
        1. **Good to Know** – Familiar data such as dates, events, and places.
        2. **Important to Know** – Essential concepts, principles, and facts.
        3. **Core Objective (Enduring Understanding)** – Lasting values, relevance to daily life, and skill enhancement that transcend classroom learning.

        **Defining Core Objectives:**
        Core Objectives represent the *bigger picture* and are meant to transform learning into enduring understanding and behavioral growth. 
        They must integrate:
        - **Lasting Value (Timelessness):** Knowledge and values that remain significant across time and contexts. (e.g., teamwork, perseverance, integrity)
        - **Relevance to Daily Life:** Practical connections to real-life situations and societal functioning. 
        - **Skill Enhancement:** Development of practical, transferable skills (e.g., problem-solving, creativity, scientific thinking).

        **Illustrative Example:**
        Teaching about honey bees can highlight:
        - *Lasting Value:* Teamwork and organizational efficiency.
        - *Relevance to Daily Life:* Roles in community life, healthy habits through honey.
        - *Skill Enhancement:* Honeycomb design principles applied in agriculture and engineering.

        **Task:**
        Generate exactly 3 Core Objectives (COs) based ONLY on the 'Reference Context (Textbook)' provided.

        **Instructions for Each CO:**
        - **co_id:** Unique identifier (CO1, CO2, CO3).
        - **co_title:** Short and engaging.
        - **co_description:** 1–2 sentences synthesizing lasting value, relevance to life, and skill enhancement.
        - **factor:** Select ONE most relevant emphasis:
            * Life Skill
            * Timeless Values
            * Relevance to Life
            * Social Awareness
            * Environmental Consciousness

        **Output Format:**
        Provide ONLY a valid JSON array with 3 Core Objectives.

        **Example JSON:**
        [
          {{
            "co_id": "CO1",
            "co_title": "Organizational Principles in Nature",
            "co_description": "Examine the honey bee colony as a model for teamwork and role distribution, connecting its structure to community building and engineering design applications.",
            "factor": "Timeless Values"
          }},
          {{
            "co_id": "CO2",
            "co_title": "Healthy Habits from Nature",
            "co_description": "Connect the production of honey with nutrition and well-being, emphasizing its role in daily life and sustainable agricultural practices.",
            "factor": "Relevance to Life"
          }},
          {{
            "co_id": "CO3",
            "co_title": "Design Thinking through Honeycombs",
            "co_description": "Explore the geometric design of honeycombs as a foundation for creativity and innovation in real-world problem-solving.",
            "factor": "Skill Enhancement"
          }}
        ]
    """
    if reference_context:
        ctx = "\n\n**Reference Context (Textbook):**\n" + reference_context
        return base + ctx
    return base


def create_co_regeneration_prompt(request: RegenerateCourseOutcomeRequest, reference_context: str | None = None) -> str:
    other_cos_formatted = "\n".join(
        [f"- {co.co_title}: {co.co_description}" for co in request.other_cos]
    )

    base = f"""
        You are an expert curriculum designer, rewriting a 'Core Objective' (CO) for a lesson plan.

        **Educational Context:**
        - Board: {request.board}
        - Grade: {request.grade}
        - Subject: {request.subject}
        - Chapter: "{request.chapter}"

        **Original Core Objective to Regenerate:**
        - **Title:** "{request.co_to_regenerate.co_title}"
        - **Description:** "{request.co_to_regenerate.co_description}"
        - **Factor:** "{request.co_to_regenerate.factor}"

        **Other Existing Core Objectives (Do NOT repeat these):**
        {other_cos_formatted}

        **Task:**
        Regenerate the original Core Objective. The new version must:
        1.  **Be concise.** The description should be a single, powerful sentence that integrates the objective with its reasoning and relevance, similar to the initial generation process.
        2.  **Maintain the original's core idea, essence, and educational goal.** It should feel like a thoughtful revision, not a completely new objective.
        3.  **Be substantially different in wording** from the original description.
        4.  **Be completely distinct** from the "Other Existing Core Objectives" listed above.
        5.  Be grounded in the 'Reference Context (Textbook)' provided.
        6.  Follow the same structure: a short title, a concise 1-sentence description, and the original factor.

        **Instructions for the Regenerated CO:**
        - **co_id:** Use the original ID: "{request.co_to_regenerate.co_id}".
        - **co_title:** Create a new, short, and engaging title.
        - **co_description:** Write a new, concise 1-sentence description that synthesizes lasting value, relevance to life, and skill enhancement.
        - **factor:** Use the original factor: "{request.co_to_regenerate.factor}".

        **Output Format:**
        Provide ONLY a single, valid JSON object for the regenerated Core Objective.

        **Example JSON:**
        {{
          "co_id": "{request.co_to_regenerate.co_id}",
          "co_title": "New Engaging Title",
          "co_description": "A newly worded, insightful, and concise description that captures the essence of the original objective while being unique.",
          "factor": "{request.co_to_regenerate.factor}"
        }}
    """
    if reference_context:
        ctx = "\n\n**Reference Context (Textbook):**\n" + reference_context
        return base + ctx
    return base


@app.post("/ExcelSchoolAI/UnitPlan/generate-course-outcomes", response_model=CourseOutcomesResponse)
async def generate_course_outcomes(request: CourseOutcomesRequest):
    try:
        # Inject textbook grounding for Class 10 General Science
        reference_context = ""
        if request.file_path and os.path.exists(request.file_path):
            if request.file_path.lower().endswith(".pdf"):
                reference_context += read_pdf(request.file_path)
            elif request.file_path.lower().endswith(".txt"):
                reference_context += read_txt(request.file_path)

        # Always try to get context from EPS directory structure
        logger.info(f"Attempting to load chapter text from EPS for Grade: {request.grade}, Subject: {request.subject}, Chapter: {request.chapter}")
        eps_text = get_chapter_text_from_eps(request.grade, request.subject, request.chapter)
        if eps_text:
            reference_context += "\n\n" + eps_text
            logger.info(f"Successfully loaded chapter text from EPS (length: {len(eps_text)} chars)")
        else:
            logger.warning(f"Could not load chapter content from EPS for '{request.chapter}'.")

        prompt = create_co_prompt(request, reference_context.strip())

        response = client.chat.completions.create(
            model=AZURE_DEPLOYMENT_NAME,
            messages=[
                {
                    "role": "system",
                    "content": f"""Act as a Class {request.grade} {request.subject} teacher. Generate impactful, age-appropriate core objectives with strong educational value.
                        the core objectives should integrate values relevant to students' lives and essential life skills. Each core objective must be concise, combining the objective statement with its underlying reasoning and explaining its relevance to daily life and values. Ensure there is no repetitive phrasing, and that the reasoning is integrated directly into the objective statement, rather than presented separately. The objectives should thoughtfully integrate relevant concepts from the chapter.
						Ensure your output follows this style. Return JSON only in the format requested.
						"""
                },
                {"role": "user", "content": prompt}
            ],
            max_tokens=9000,
            temperature=0.7
        )

        content = response.choices[0].message.content
        try:
            course_data = json.loads(content)
        except json.JSONDecodeError:
            start = content.find('[')
            end = content.rfind(']') + 1
            course_data = json.loads(content[start:end])

        # Add empty skills and competencies arrays if they don't exist
        for co in course_data:
            if 'skills' not in co:
                co['skills'] = []
            if 'competencies' not in co:
                co['competencies'] = []

        validated_outcomes = [CourseOutcome(**co) for co in course_data]

        return CourseOutcomesResponse(
            board=request.board,
            grade=request.grade,
            subject=request.subject,
            chapter=request.chapter,
            total_outcomes=len(validated_outcomes),
            course_outcomes=validated_outcomes
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating Course Outcomes: {str(e)}")


@app.post("/ExcelSchoolAI/UnitPlan/regenerate-course-outcome", response_model=CourseOutcome)
async def regenerate_course_outcome(request: RegenerateCourseOutcomeRequest):
    try:
        reference_context = ""
        if request.file_path and os.path.exists(request.file_path):
            if request.file_path.lower().endswith(".pdf"):
                reference_context += read_pdf(request.file_path)
            elif request.file_path.lower().endswith(".txt"):
                reference_context += read_txt(request.file_path)

        eps_text = get_chapter_text_from_eps(request.grade, request.subject, request.chapter)
        if eps_text:
            reference_context += "\n\n" + eps_text

        prompt = create_co_regeneration_prompt(request, reference_context.strip())

        response = client.chat.completions.create(
            model=AZURE_DEPLOYMENT_NAME,
            messages=[
                {
                    "role": "system",
                    "content": f"Act as a Class {request.grade} {request.subject} teacher. You are refining a core objective to be more impactful, concise, and unique. Ensure your output is a single, valid JSON object."
                },
                {"role": "user", "content": prompt}
            ],
            max_tokens=200,
            temperature=0.75
        )

        content = response.choices[0].message.content
        try:
            new_co_data = json.loads(content)
        except json.JSONDecodeError:
            start = content.find('{')
            end = content.rfind('}') + 1
            new_co_data = json.loads(content[start:end])

        # Ensure skills and competencies are initialized
        if 'skills' not in new_co_data:
            new_co_data['skills'] = []
        if 'competencies' not in new_co_data:
            new_co_data['competencies'] = []

        return CourseOutcome(**new_co_data)

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error regenerating Course Outcome: {str(e)}")


# ---------- Endpoint 2: Generate Skills for Each CO ----------
def create_skills_prompt(co: CourseOutcome, reference_context: str | None = None) -> str:
    base_prompt = f"""
        You are an expert academic assistant. Your task is to generate a list of **2 specific skill keywords** that students will acquire based on the provided Course Outcome and reference textbook context.

        Instructions:
        - Carefully read and use ONLY the content provided below under 'Reference Context (Textbook)'.
        - Generate exactly 2 skill keywords.
        - Each skill should be a concise phrase (3 to 6 words).
        - The skills must be directly derivable from the textbook context and relevant to the course outcome.
        - Output as bullet points only. Do not include explanations.

        Course Outcome:
        Title: {co.co_title}
        Id: {co.co_id}
        Description: {co.co_description}
        Factor: {co.factor}
    """
    if reference_context:
        return base_prompt + "\n\nReference Context (Textbook):\n" + reference_context
    return base_prompt

@app.post("/ExcelSchoolAI/UnitPlan/generate-skills-per-co")
async def generate_skills_per_co(data: CourseOutcomesInput):
    try:
        # Fetch reference context once for the chapter
        reference_context = ""
        if data.file_path and os.path.exists(data.file_path):
            if data.file_path.lower().endswith(".pdf"):
                reference_context += read_pdf(data.file_path)
            elif data.file_path.lower().endswith(".txt"):
                reference_context += read_txt(data.file_path)

        # Always try to get context from EPS directory structure
        logger.info(f"Attempting to load chapter text from EPS for Grade: {data.grade}, Subject: {data.subject}, Chapter: {data.chapter}")
        eps_text = get_chapter_text_from_eps(data.grade, data.subject, data.chapter)
        if eps_text:
            reference_context += "\n\n" + eps_text
            logger.info(f"Successfully loaded chapter text from EPS (length: {len(eps_text)} chars)")
        else:
            logger.warning(f"Could not load chapter content from EPS for '{data.chapter}'.")

        updated_outcomes = []
        for co in data.course_outcomes:
            # Create the prompt with or without context
            prompt = create_skills_prompt(co, reference_context)

            response = client.chat.completions.create(
                model=AZURE_DEPLOYMENT_NAME,
                messages=[
                    {"role": "system", "content": "You are an expert educator skilled in mapping course outcomes to actionable skills based on provided textbook content."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=500,
                temperature=0.9
            )

            content = response.choices[0].message.content
            skills = [re.sub(r"^[-•]\s*", "", line).strip() for line in content.strip().split("\n") if line.strip().startswith(("-", "•"))]

            # Create a dictionary that matches the structure of CourseOutcomeWithSkills for appending
            outcome_with_skills = {
                "co_id": co.co_id,
                "co_title": co.co_title,
                "co_description": co.co_description,
                "factor": co.factor,
                "skills": skills,
                "competencies": co.competencies if hasattr(co, 'competencies') else [] # Ensure competencies is carried over
            }
            updated_outcomes.append(outcome_with_skills)

        return {
            "board": data.board,
            "grade": data.grade,
            "subject": data.subject,
            "chapter": data.chapter,
            "total_outcomes": data.total_outcomes,
            "course_outcomes": updated_outcomes
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating skills: {str(e)}")


# ---------- Endpoint 2b: Generate Competencies for Each CO ----------
def create_competencies_prompt(co: CO, reference_context: str | None = None) -> str:
    base_prompt = f"""
        You are an expert academic assistant. Your task is to generate a list of **2 key competencies** students will develop, based on the provided Course Outcome and reference textbook context.

        Instructions:
        - Carefully read and use ONLY the content provided below under 'Reference Context (Textbook)'.
        - Generate exactly 2 key competencies.
        - Each competency should be a concise phrase (3 to 8 words).
        - The competencies must be directly derivable from the textbook context and relevant to the course outcome and associated skills.
        - Output as bullet points only. Do not include explanations.

        Course Outcome:
        Title: {co.co_title}
        Description: {co.co_description}
        Factor: {co.factor}
        Skills: {', '.join(co.skills)}
    """
    if reference_context:
        return base_prompt + "\n\nReference Context (Textbook):\n" + reference_context
    return base_prompt

@app.post("/ExcelSchoolAI/UnitPlan/generate-competencies-per-co")
async def generate_competencies_per_co(data: COInput):
    try:
        # Fetch reference context once for the chapter
        reference_context = ""
        if data.file_path and os.path.exists(data.file_path):
            if data.file_path.lower().endswith(".pdf"):
                reference_context += read_pdf(data.file_path)
            elif data.file_path.lower().endswith(".txt"):
                reference_context += read_txt(data.file_path)

        # Always try to get context from EPS directory structure
        logger.info(f"Attempting to load chapter text from EPS for Grade: {data.grade}, Subject: {data.subject}, Chapter: {data.chapter}")
        eps_text = get_chapter_text_from_eps(data.grade, data.subject, data.chapter)
        if eps_text:
            reference_context += "\n\n" + eps_text
            logger.info(f"Successfully loaded chapter text from EPS (length: {len(eps_text)} chars)")
        else:
            logger.warning(f"Could not load chapter content from EPS for '{data.chapter}'.")

        updated_outcomes = []
        for co in data.course_outcomes:
            # Create the prompt with or without context
            prompt = create_competencies_prompt(co, reference_context)

            response = client.chat.completions.create(
                model=AZURE_DEPLOYMENT_NAME,
                messages=[
                    {"role": "system", "content": "You are an expert educator skilled in mapping course outcomes to key competencies based on provided textbook content."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=500,
                temperature=0.9
            )

            content = response.choices[0].message.content
            competencies = [re.sub(r"^[-•]\s*", "", line).strip() for line in content.strip().split("\n") if line.strip().startswith(("-", "•"))]

            updated_outcomes.append({
                "co_id": co.co_id,
                "co_title": co.co_title,
                "co_description": co.co_description,
                "factor": co.factor,
                "skills": co.skills,
                "competencies": competencies
            })

        return {
            "board": data.board,
            "grade": data.grade,
            "subject": data.subject,
            "chapter": data.chapter,
            "total_outcomes": data.total_outcomes,
            "course_outcomes": updated_outcomes
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating competencies: {str(e)}")

# ---------- Endpoint: Generate Pedagogical Approaches for ELOs ----------
from pydantic import BaseModel

class PedagogicalApproachesRequest(BaseModel):
    elos: list[str]
    subject: str = ""
    grade: str = ""
    board: str = ""
    chapter: str = ""

# ---------- Endpoint: Generate Learning Experience (5E Model) ----------
class LearningExperienceRequest(BaseModel):
    elos: list[str]
    pedagogical_approaches: list[str]
    intelligence_types: list[str]
    course_outcomes: list[dict]  # Each CO with skills, factor, competencies, etc.
    grade: str
    subject: str
    chapter: str
    file_path: Optional[str] = None

@app.post("/ExcelSchoolAI/UnitPlan/generate-learning-experience")
async def generate_learning_experience(request: LearningExperienceRequest):
    """
    Generate a beautiful 5E Model JSON for teachers/educators, focusing on pedagogical approaches and intelligence types.
    """
    # Fetch reference context for the chapter
    reference_context = ""
    if request.file_path and os.path.exists(request.file_path):
        if request.file_path.lower().endswith(".pdf"):
            reference_context += read_pdf(request.file_path)
        elif request.file_path.lower().endswith(".txt"):
            reference_context += read_txt(request.file_path)

    # Always try to get context from EPS directory structure
    logger.info(f"Attempting to load chapter text from EPS for Grade: {request.grade}, Subject: {request.subject}, Chapter: {request.chapter}")
    eps_text = get_chapter_text_from_eps(request.grade, request.subject, request.chapter)
    if eps_text:
        reference_context += "\n\n" + eps_text
        logger.info(f"Successfully loaded chapter text from EPS (length: {len(eps_text)} chars)")
    else:
        logger.warning(f"Could not load chapter content from EPS for '{request.chapter}'.")

    prompt = f"""
You are an expert lesson designer. Create a detailed, creative, and practical 5E Model Learning Experience for teachers, using the following context.
**Crucially, all activities must be derived directly from the 'Reference Context (Textbook)' provided below.**

- Subject: {request.subject}
- Grade: {request.grade}
- Chapter: {request.chapter}

Course Outcomes (with skills, factors, competencies):
{json.dumps(request.course_outcomes, indent=2)}

Expected Learning Outcomes (ELOs):
{json.dumps(request.elos, indent=2)}

Pedagogical Approaches (focus on these!):
{', '.join(request.pedagogical_approaches)}

Selected Intelligence Types (focus on these!):
{', '.join(request.intelligence_types)}

Instructions:
- For each phase of the 5E Model (Engage, Explore, Explain, Elaborate, Evaluate), design 1-2 activities.
- Each activity must be based on the provided textbook content.
- Each activity should clearly integrate at least one pedagogical approach and one intelligence type from the lists above.
- Activities should be practical, creative, and actionable for teachers in the classroom.
- Use the ELOs and course outcomes as the learning goals for the activities.
- For each activity, specify:
    - "title": Short, descriptive name
    - "description": 1-2 sentences describing what students will do
    - "pedagogical_approach": The main approach used (from the list)
    - "intelligence_types": List of intelligence types targeted (from the list)
    - "elos": List of relevant ELOs (from the list)
    - "course_outcomes": List of relevant course outcome titles (from the list)
    - "materials": (optional) List of materials/resources needed
    - "Duration" : duration for each actvity

Output JSON format:
{{
  "5E_Model": [
    {{
      "phase": "Engage",
      "activities": [
        {{
          "title": "...",
          "description": "...",
          "pedagogical_approach": "...",
          "intelligence_types": ["...", ...],
          "elos": ["...", ...],
          "course_outcomes": ["...", ...],
          "materials": ["...", ...],
          "duration":"..."
        }},
        ...
      ]
    }},
    {{
      "phase": "Explore",
      "activities": [ ... ]
    }},
    {{
      "phase": "Explain",
      "activities": [ ... ]
    }},
    {{
      "phase": "Elaborate",
      "activities": [ ... ]
    }},
    {{
      "phase": "Evaluate",
      "activities": [ ... ]
    }}
  ]
}}

{'Reference Context (Textbook):' + reference_context if reference_context else ''}

Respond ONLY with a valid JSON object as above. Make it beautiful, creative, and practical for teachers. Focus on integrating the pedagogical approaches and intelligence types in every activity.
"""
    response = client.chat.completions.create(
        model=AZURE_DEPLOYMENT_NAME,
        messages=[
            {"role": "system", "content": "You are an expert in lesson planning and creative curriculum design for K-12 teachers."},
            {"role": "user", "content": prompt}
        ],
        max_tokens=4000,
        temperature=0.9
    )
    content = response.choices[0].message.content
    # Always try to extract and return a parsed JSON object
    try:
        json_start = content.find('{')
        json_end = content.rfind('}') + 1
        if json_start != -1 and json_end != -1:
            learning_experience = json.loads(content[json_start:json_end])
        else:
            raise ValueError("No JSON object found in response")
        return {"learning_experience": learning_experience}
    except Exception as e:
        # Return a clear error and the raw string for debugging
        return JSONResponse(
            status_code=500,
            content={"error": f"Failed to parse learning experience JSON. Raw response: {content}"}
        )

@app.post("/ExcelSchoolAI/UnitPlan/generate-pedagogical-approaches")
async def generate_pedagogical_approaches(request: PedagogicalApproachesRequest):
    try:
        all_approaches = []
        for elo in request.elos:
            prompt = f"""
You are an expert curriculum designer. For the following Expected Learning Outcome (ELO), generate exactly 2 distinct, research-based pedagogical approaches as short keywords or phrases (not sentences), similar to "skills" or "competencies".

- Each approach should be a concise phrase (2–5 words), not a sentence.
- Use a variety of methods (e.g., Inquiry-based, Project-based, Collaborative, Experiential, Art Integrated, etc.)
- Do not repeat the ELO text in the approach.
- Output as a JSON array of exactly 2 strings (keywords/phrases only). Do not return more or less than 2.

ELO: "{elo}"
"""
            response = client.chat.completions.create(
                model=AZURE_DEPLOYMENT_NAME,
                messages=[
                    {"role": "system", "content": "You are an expert in pedagogical strategies for Indian K-12 curriculum."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=100,
                temperature=0.8
            )
            content = response.choices[0].message.content
            try:
                start = content.find('[')
                end = content.rfind(']') + 1
                approaches = json.loads(content[start:end])
            except Exception:
                approaches = [content.strip()]
            all_approaches.extend([a.strip() for a in approaches if a.strip()])
        # Return all approaches without removing duplicates
        return {"approaches": all_approaches}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating pedagogical approaches: {str(e)}")

@app.post("/ExcelSchoolAI/UnitPlan/generate-elos", tags=["ELO Generator"])
async def generate_elos_v2(data: ELORequestData):
    co_summary = ". ".join([co.get('co_description', '') for co in data.course_outcomes])

    # Fetch reference context once for the chapter
    reference_context = ""
    if data.file_path and os.path.exists(data.file_path):
        if data.file_path.lower().endswith(".pdf"):
            reference_context += read_pdf(data.file_path)
        elif data.file_path.lower().endswith(".txt"):
            reference_context += read_txt(data.file_path)
            
    # Always try to get context from EPS directory structure
    logger.info(f"Attempting to load chapter text from EPS for Grade: {data.grade}, Subject: {data.subject}, Chapter: {data.chapter}")
    eps_text = get_chapter_text_from_eps(data.grade, data.subject, data.chapter)
    if eps_text:
        reference_context += "\n\n" + eps_text
        logger.info(f"Successfully loaded chapter text from EPS (length: {len(eps_text)} chars)")
    else:
        logger.warning(f"Could not load chapter content from EPS for '{data.chapter}'.")

    # Initialize CO output map
    co_output_map = {co["co_id"]: {**co, "elos": []} for co in data.course_outcomes}
    co_ids = list(co_output_map.keys())

    all_elo_entries = []

    # Step 1: Generate ELOs grouped by Bloom level
    for bloom_level, count in data.blooms_elo_counts.items():
        if count > 0:
            prompt = build_elo_prompt(count, bloom_level, data, co_summary, reference_context)

            try:
                response = client.chat.completions.create(
                    model=AZURE_DEPLOYMENT_NAME,
                    messages=[
                        {"role": "system", "content": f"You are an expert in designing learning outcomes for CBSE curriculum."},
                        {"role": "user", "content": prompt}
                    ],
                    temperature=0.9,
                    max_tokens=count * 70
                )

                result_text = response.choices[0].message.content.strip()
                json_start = result_text.find('[')
                json_end = result_text.rfind(']') + 1
                elos = json.loads(result_text[json_start:json_end])

                for elo_text in elos:
                    all_elo_entries.append({
                        "elo": elo_text,
                        "bloom_level": bloom_level
                    })

            except Exception as e:
                continue

    # Step 2: Distribute ELOs to COs in round-robin (mix Bloom levels)
    
    for i, elo_entry in enumerate(all_elo_entries):
        co_id = co_ids[i % len(co_ids)]
        co = co_output_map[co_id]
        skills = co.get("skills", [])[:2]
        competencies = co.get("competencies", [])[:2]

        co_output_map[co_id]["elos"].append({
            "elo": elo_entry["elo"],
            "bloom_level": elo_entry["bloom_level"],
            "co_id": co_id,
            "Elo_id": "Elo-" + str(i+1),
            "skills": skills,
            "competencies": competencies
        })
        

    return list(co_output_map.values())

taxonomy_levels = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]

def get_cognitive_levels(selected_level, includeLOTS):
    """
    Returns a list of cognitive levels based on the selected taxonomy level
    and whether Lower-Order Thinking Skills (LOTS) should be included.
    """
    index = taxonomy_levels.index(selected_level)
    if includeLOTS:
        # Include all levels up to and including the selected level
        return taxonomy_levels[:index + 1]
    else:
        # Only use the selected level
        return [selected_level]

def format_cognitive_level_string(levels, includeLOTS):
    """
    Formats the cognitive levels into a readable string for display.
    """
    if includeLOTS:
        return f"one of the Lower-Order Thinking Skills ({', '.join(levels)})"
    else:
        return f"{levels[0]}"


class ELO(BaseModel):
    elo: str
    blooms_taxonomy: str
    skills: List[str]
    competencies: List[str]
    Elo_id: str

class RegenerateEloRequest(BaseModel):
    board: str
    grade: str
    subject: str
    chapter: str
    elo_to_regenerate: ELO
    other_elos: List[ELO]
    course_outcomes: List[dict]
    file_path: Optional[str] = None

def create_elo_regeneration_prompt(request: RegenerateEloRequest, reference_context: str | None = None) -> str:
    other_elos_formatted = "\n".join(
        [f"- {elo.elo}" for elo in request.other_elos]
    )
    co_summary = ". ".join([co.get('co_description', '') for co in request.course_outcomes])

    base = f"""
        You are an expert in outcomes-based education, tasked with regenerating an Expected Learning Outcome (ELO) to be unique and fresh.

        **Educational Context:**
        - Board: {request.board}
        - Grade: {request.grade}
        - Subject: {request.subject}
        - Chapter: "{request.chapter}"

        **Original ELO to Regenerate:**
        - **ELO:** "{request.elo_to_regenerate.elo}"
        - **Bloom's Level:** "{request.elo_to_regenerate.blooms_taxonomy}"

        **Other Existing ELOs (Do NOT repeat these):**
        {other_elos_formatted}

        **Definition of Learning Outcomes (Apply these principles):**
        Learning outcomes are statements that describe significant and essential learning that learners have achieved and can reliably demonstrate. They focus on results (the "exit behaviors") rather than the process, answering: *"What should the student be able to DO by the end of this lesson?"*

        **Anatomy of a Learning Outcome Statement:**
        1. **Action Verb** – identifies the performance to be demonstrated, aligned to the '{request.elo_to_regenerate.blooms_taxonomy}' level.
        2. **Learning Statement** – specifies what will be demonstrated.
        3. **Criterion/Standard** – defines acceptable performance.

        **Core Regeneration Task:**
        Regenerate the original ELO. The new version must be a creative and unique rephrasing that meets the following critical criteria:
        1. **Maintain the Core Meaning:** The new ELO must preserve the original's core educational goal and intent.
        2. **Ensure Uniqueness:** The regenerated ELO must be substantially different in wording from the original and from the "Other Existing ELOs". Avoid reusing the same key verbs and phrases. Each regeneration should produce a novel phrasing.
        3. **Follow the Structure:** The ELO must be a complete statement in the form: "[action verb] [learning statement] [criterion/standard]."
        4. **Stay Aligned:** The ELO must align with the original Bloom's Taxonomy level: **{request.elo_to_regenerate.blooms_taxonomy}**.
        5. **Be Grounded:** The ELO must be based on the provided 'Reference Context (Textbook)'.
        6. **Be Concise:** The regenerated ELO should be clear and to the point, avoiding overly long or complex sentences.

        **Context for this Chapter:**
        - Core Objectives Summary: {co_summary}

        **Final Output Instructions:**
        - Produce a single, valid JSON object.
        - The JSON object must contain one key, "elo", with the new ELO text as its value.

        **Example Output Format:**
        ```json
        {{
          "elo": "A newly worded, insightful, and concise ELO that captures the essence of the original while being unique."
        }}
        ```
    """
    if reference_context:
        ctx = "\n\n**Reference Context (Textbook):**\n" + reference_context
        return base + ctx
    return base


@app.post("/ExcelSchoolAI/UnitPlan/regenerate-elo")
async def regenerate_elo(request: RegenerateEloRequest):
    try:
        reference_context = ""
        if request.file_path and os.path.exists(request.file_path):
            if request.file_path.lower().endswith(".pdf"):
                reference_context += read_pdf(request.file_path)
            elif request.file_path.lower().endswith(".txt"):
                reference_context += read_txt(request.file_path)

        eps_text = get_chapter_text_from_eps(request.grade, request.subject, request.chapter)
        if eps_text:
            reference_context += "\\n\\n" + eps_text

        prompt = create_elo_regeneration_prompt(request, reference_context.strip())

        response = client.chat.completions.create(
            model=AZURE_DEPLOYMENT_NAME,
            messages=[
                {
                    "role": "system",
                    "content": f"Act as a Class {request.grade} {request.subject} teacher. You are refining a learning outcome to be more impactful, concise, and unique. Ensure your output is a single, valid JSON object."
                },
                {"role": "user", "content": prompt}
            ],
            max_tokens=150,
            temperature=0.8,
            response_format={"type": "json_object"}
        )

        content = response.choices[0].message.content
        new_elo_data = json.loads(content)

        # Construct the full ELO object to return
        regenerated_elo = request.elo_to_regenerate.dict()
        regenerated_elo["elo"] = new_elo_data["elo"]

        return regenerated_elo

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error regenerating ELO: {str(e)}")


def create_assessment_prompt(request: AssessmentRequest, reference_context: str | None = None) -> str:
    co_context = f'- Course Outcome: "{request.course_outcome}"' if request.course_outcome else ""
    core_objectives_context = f'- Core Objectives: {"; ".join(request.core_objectives)}' if request.core_objectives else ""

    items_structure = []
    for detail in request.assessment_details:
        if detail.bloomsLevel:
            cognitive_level_display = f'exactly "{detail.bloomsLevel}"'
        else:
            cognitive_levels = get_cognitive_levels(request.Bloom_level, detail.includeLOTS)
            cognitive_level_display = format_cognitive_level_string(cognitive_levels, detail.includeLOTS)
        
        items_structure.append(f'- {detail.noOfItems} item(s) of type "{detail.itemType}". For each item, assign the Bloom\'s Taxonomy level of **{cognitive_level_display}**.')

    items_structure_str = "\n".join(items_structure)

    base_prompt = f"""
    You are an expert in creating educational assessments guided by the principle of "Assessment for Learning".

    **Guiding Philosophy: Assessment for Learning**
    The assessments you create should provide a clear snapshot of student learning and understanding as teaching happens. This allows the teacher to adjust their instructional strategies and lesson plans in real-time based on student needs.

    **Assessment Generation Task:**
    Generate a list of assessment items based on the following context and structure.
    **Crucially, all questions, answers, and options must be derived directly from the 'Reference Context (Textbook)' provided below.**

    - Grade: {request.grade}
    - Subject: {request.subject}
    - Topic: {request.topic}
    - Expected Learning Outcome (ELO): "{request.elo}"
    {co_context}
    {core_objectives_context}

    Required Assessment Structure:
{items_structure_str}

    Instructions:
    1.  Generate a single JSON response containing a list of all requested assessment items.
    2.  Each item in the list must be a JSON object with the following structure:
        - "question": The question text.
        - "itemType": The type of the assessment item (e.g., "mcq", "fill-blank").
        - "answer": The correct answer.
        - "bloomsLevel": The Bloom's Taxonomy level of the question. **This must be a single, specific level as requested.**
        - "options": A list of 4 strings for "mcq" items, otherwise null.
        - "context": A detailed scenario for "case-study" items, otherwise null.
    3.  Ensure the response is a single, valid JSON object with a key "assessment_items" that contains the list of items.
    4.  For "case-study" items, the "context" should be a detailed, multi-faceted scenario that requires students to apply their knowledge and critical thinking skills. Avoid simplistic scenarios.
    5.  For "fill-blank" items, the "question" should be a simple sentence containing one to three blanks.
    """
    
    if reference_context:
        return f"{base_prompt}\n\nReference Context (Textbook):\n{reference_context}\n\nRespond ONLY with a valid JSON object."
    return f"{base_prompt}\nRespond ONLY with a valid JSON object."



@app.post("/ExcelSchoolAI/UnitPlan/generate-assessment-items")
async def generate_assessment_items(request: AssessmentRequest):
    try:
        # Fetch reference context for the chapter (topic)
        reference_context = ""
        if request.file_path and os.path.exists(request.file_path):
            if request.file_path.lower().endswith(".pdf"):
                reference_context += read_pdf(request.file_path)
            elif request.file_path.lower().endswith(".txt"):
                reference_context += read_txt(request.file_path)

        # Always try to get context from EPS directory structure
        logger.info(f"Attempting to load chapter text from EPS for Grade: {request.grade}, Subject: {request.subject}, Chapter: {request.topic}")
        eps_text = get_chapter_text_from_eps(request.grade, request.subject, request.topic)
        if eps_text:
            reference_context += "\n\n" + eps_text
            logger.info(f"Successfully loaded chapter text from EPS (length: {len(eps_text)} chars)")
        else:
            logger.warning(f"Could not load chapter content from EPS for '{request.topic}'.")

        prompt = create_assessment_prompt(request, reference_context.strip())
        total_items = sum(detail.noOfItems for detail in request.assessment_details)
        
        items_list = None
        for attempt in range(3): # Retry up to 3 times
            try:
                response = client.chat.completions.create(
                    model=AZURE_DEPLOYMENT_NAME,
                    messages=[
                        {"role": "system", "content": "You are an assessment generation expert. Your ONLY output must be a single, valid, complete JSON object. Do not include any other text, markdown, or explanations before or after the JSON."},
                        {"role": "user", "content": prompt}
                    ],
                    max_tokens=400 * total_items,
                    temperature=0.7,
                    response_format={"type": "json_object"}
                )
                content = response.choices[0].message.content
                items_data = json.loads(content)
                items_list = items_data.get("assessment_items")
                if items_list is not None:
                    break # Success, exit loop
                else:
                    raise ValueError("'assessment_items' key not found.")
            except (json.JSONDecodeError, ValueError) as e:
                logger.warning(f"Attempt {attempt + 1} failed to generate/parse assessment items: {e}")
                if attempt == 2: # Last attempt failed
                    raise HTTPException(status_code=500, detail=f"Failed to parse assessment items after 3 attempts: {e}")
                continue

        # Get the requested bloomsLevel if it exists (for regeneration)
        requested_blooms_level = None
        if request.assessment_details and request.assessment_details[0].bloomsLevel:
            requested_blooms_level = request.assessment_details[0].bloomsLevel

        # Normalize and enforce bloomsLevel for each item
        normalized_items = []
        for item in items_list:
            # If a specific bloomsLevel was requested for regeneration, enforce it.
            if requested_blooms_level:
                item["bloomsLevel"] = requested_blooms_level
            else:
                # Fallback mapping for other cases if needed
                if "bloomsLevel" not in item:
                    if "bloomLevel" in item:
                        item["bloomsLevel"] = item["bloomLevel"]
                    elif "blooms_level" in item:
                        item["bloomsLevel"] = item["blooms_level"]
                    else:
                        item["bloomsLevel"] = ""
            
            # Handle cases where 'answer' might be a list for fill-in-the-blanks
            if isinstance(item.get("answer"), list):
                item["answer"] = ", ".join(map(str, item["answer"]))

            normalized_items.append(AssessmentItem(**item))
        
        # Group by ELO
        elo_grouped_assessments = {
            "0": {
                "eloname": request.elo,
                "assessment": normalized_items
            }
        }
        
        return elo_grouped_assessments

    except Exception as e:
        logger.error(f"Error generating assessment items: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error generating assessment items: {str(e)}")


@app.post("/ExcelSchoolAI/UnitPlan/regenerate-assessment-items")
async def regenerate_assessment_items(request: AssessmentRequest):
    try:
        # Fetch reference context for the chapter (topic)
        reference_context = ""
        if request.file_path and os.path.exists(request.file_path):
            if request.file_path.lower().endswith(".pdf"):
                reference_context += read_pdf(request.file_path)
            elif request.file_path.lower().endswith(".txt"):
                reference_context += read_txt(request.file_path)

        # Always try to get context from EPS directory structure
        logger.info(f"Attempting to load chapter text from EPS for Grade: {request.grade}, Subject: {request.subject}, Chapter: {request.topic}")
        eps_text = get_chapter_text_from_eps(request.grade, request.subject, request.topic)
        if eps_text:
            reference_context += "\n\n" + eps_text
            logger.info(f"Successfully loaded chapter text from EPS (length: {len(eps_text)} chars)")
        else:
            logger.warning(f"Could not load chapter content from EPS for '{request.topic}'.")

        prompt = create_assessment_prompt(request, reference_context.strip())
        prompt += "\n\nIMPORTANT: This is a regeneration request. Ensure the new questions are substantially different from any previous versions for this ELO."
        total_items = sum(detail.noOfItems for detail in request.assessment_details)

        items_list = None
        for attempt in range(3): # Retry up to 3 times
            try:
                response = client.chat.completions.create(
                    model=AZURE_DEPLOYMENT_NAME,
                    messages=[
                        {"role": "system", "content": "You are an assessment generation expert. Your ONLY output must be a single, valid, complete JSON object. You are fulfilling a regeneration request, so you must provide new and different questions. Do not include any other text, markdown, or explanations before or after the JSON."},
                        {"role": "user", "content": prompt}
                    ],
                    max_tokens=500 * total_items,
                    temperature=0.8,
                    response_format={"type": "json_object"}
                )
                content = response.choices[0].message.content
                items_data = json.loads(content)
                items_list = items_data.get("assessment_items")
                if items_list is not None:
                    break # Success, exit loop
                else:
                    raise ValueError("'assessment_items' key not found.")
            except (json.JSONDecodeError, ValueError) as e:
                logger.warning(f"Attempt {attempt + 1} failed to regenerate/parse assessment items: {e}")
                if attempt == 2: # Last attempt failed
                    raise HTTPException(status_code=500, detail=f"Failed to parse assessment items after 3 attempts: {e}")
                continue

        # Get the requested bloomsLevel if it exists (for regeneration)
        requested_blooms_level = None
        if request.assessment_details and request.assessment_details[0].bloomsLevel:
            requested_blooms_level = request.assessment_details[0].bloomsLevel

        # Normalize and enforce bloomsLevel for each item
        normalized_items = []
        for item in items_list:
            # If a specific bloomsLevel was requested for regeneration, enforce it.
            if requested_blooms_level:
                item["bloomsLevel"] = requested_blooms_level
            else:
                # Fallback mapping for other cases if needed
                if "bloomsLevel" not in item:
                    if "bloomLevel" in item:
                        item["bloomsLevel"] = item["bloomLevel"]
                    elif "blooms_level" in item:
                        item["bloomsLevel"] = item["blooms_level"]
                    else:
                        item["bloomsLevel"] = ""
            
            # Handle cases where 'answer' might be a list for fill-in-the-blanks
            if isinstance(item.get("answer"), list):
                item["answer"] = ", ".join(map(str, item["answer"]))

            normalized_items.append(AssessmentItem(**item))
        
        # Group by ELO
        elo_grouped_assessments = {
            "0": {
                "eloname": request.elo,
                "assessment": normalized_items
            }
        }
        
        return elo_grouped_assessments

    except Exception as e:
        logger.error(f"Error regenerating assessment items: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error regenerating assessment items: {str(e)}")


# ---------- Request Model ----------
class GetUnitPlanRequest(BaseModel):
    OrgCode: str
    AppCode: str
    CustCode: str
    UserCode: str
    ClassID: int = 0
    SubjectId: int = 0
    ChapterId: int = 0
    SearchText: str = ''
    UserType: int = 0

# ---------- POST Endpoint ----------
@app.post("/ExcelSchoolAI/UnitPlan/get-unit-plan-details")
def get_unit_plan_details(request: GetUnitPlanRequest):
    try:
        conn = get_exceschoolai_db_connection()
        cursor = conn.cursor()
        refcursor_name = "S"

        cursor.execute("""
            CALL lesson.uspGetUnitPlanDetails(
                %s, %s, %s, %s, %s, %s, %s, %s, %s, %s
            )
        """, (
            request.AppCode,
            request.CustCode,
            request.OrgCode,
            request.UserCode,
            request.ClassID,
            request.SubjectId,
            request.ChapterId,
            request.SearchText,
            request.UserType,
            refcursor_name
        ))

        cursor.execute(f'FETCH ALL IN "{refcursor_name}"')
        rows = cursor.fetchall()

        colnames = [desc[0] for desc in cursor.description]

        from datetime import datetime, date
        from decimal import Decimal

        def serialize(val):
            if isinstance(val, (datetime, date)):
                return val.isoformat()
            if isinstance(val, Decimal):
                return float(val)
            return val

        result = [
            {col: serialize(val) for col, val in zip(colnames, row)}
            for row in rows
        ]

        cursor.execute("COMMIT")
        cursor.close()
        conn.close()

        return JSONResponse(content={"unit_plans": result}, status_code=200)

    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})

# ---------- Request Model ----------
class SaveUnitPlanRequest(BaseModel):
    AppCode: str
    CustCode: str
    OrgCode: str
    UserCode: str
    ClassName: str
    ClassId: int
    SubjectName: str
    SubjectId: int
    PlanClassId: Optional[int] = None
    ChapterId: int
    ChapterName: str
    UnitPlanTitle: str
    AILessonPlan: dict
    ModifiedLessonPlan: dict
    InputToken: Optional[int] = 0
    ResponseToken: Optional[int] = 0
    Elo: dict

# ---------- POST Endpoint ----------
@app.post("/ExcelSchoolAI/UnitPlan/save-unit-plan-details")
def save_unit_plan_details(request: SaveUnitPlanRequest):
    try:
        conn = get_exceschoolai_db_connection()
        cursor = conn.cursor()

        # Use ClassId as PlanClassId if not provided
        plan_class_id = request.PlanClassId or request.ClassId
        status = ''

        # Prepare CALL statement for procedure with 17 parameters (last one is INOUT)
        cursor.execute("""
            CALL lesson.uspsaveunitplan(
                %s, %s, %s, %s,
                %s, %s, %s, %s,
                %s, %s, %s, %s,
                %s::jsonb, %s::jsonb,
                %s, %s, %s::jsonb, %s
            )
        """, (
            request.AppCode,
            request.CustCode,
            request.OrgCode,
            request.UserCode,
            request.ClassName,
            request.ClassId,
            request.SubjectName,
            request.SubjectId,
            plan_class_id,
            request.ChapterId,
            request.ChapterName,
            request.UnitPlanTitle,
            json.dumps(request.AILessonPlan),
            json.dumps(request.ModifiedLessonPlan),
            request.InputToken,
            request.ResponseToken,
            json.dumps(request.Elo),
            status
            
        ))

        conn.commit()
        cursor.close()
        conn.close()

        return {"Status": "Success", "Message": "Unit plan saved successfully"}

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")
        

    
@app.post("/ExcelSchoolAI/UnitPlan/delete_unit_plan_by_id")
async def delete_lesson_plan(request: Request):
    try:
        body = await request.json()
        unitplanid = body.get("unitplanid")
        status = ''

        conn = get_exceschoolai_db_connection()
        cursor = conn.cursor()

        sql = """
            CALL lesson.uspdeleteunitplandetails(
                %s::bigint,
                %s::character varying
            )
        """

        cursor.execute(sql, (
            unitplanid,
            status
        ))

        conn.commit()
        cursor.close()
        conn.close()

        return JSONResponse(content={"message": "Lesson plan deleted successfully"}, status_code=200)

    except Exception as e:
        return JSONResponse(content={"error": str(e)}, status_code=500)
    
@app.post("/ExcelSchoolAI/UnitPlan/Update_LessonPlan")
async def update_lesson_plan(request: Request):
    try:
        body = await request.json()
        unitplanid = body.get("unitplanid")
        Lessonplanjson = json.dumps(body.get("modifiedlessonplan")),
        status = ''

        conn = get_exceschoolai_db_connection()
        cursor = conn.cursor()

        sql = """
            CALL lesson.uspupdateunitplandetails(
                %s::jsonb,
                %s::bigint,
                %s::character varying
            )
        """

        cursor.execute(sql, (
            Lessonplanjson,
            unitplanid,
            status
        ))

        conn.commit()
        cursor.close()
        conn.close()

        return JSONResponse(content={"message": "Lesson plan updated successfully"}, status_code=200)

    except Exception as e:
        return JSONResponse(content={"error": str(e)}, status_code=500)

# ---------- check user ----------


# Define the input and output models for the API
class UserCredentials(BaseModel):
    username: str
    password: str

class ResponseStatus(BaseModel):
    status: str
    usercode: str = None
    custcode: str = None
    orgcode: str = None
    username: str = None
    userrole: str = None

# API endpoint to check user credentials
@app.post("/ExcelSchoolAI/UnitPlan/check-user", response_model=ResponseStatus)
async def check_user(credentials: UserCredentials):
    conn = None
    try:
        # Connect to the database
        conn = get_exceschoolai_db_connection()
        with conn.cursor() as cur:
            # Define the refcursor
            refcursor_name = 's'

            # Begin transaction
            cur.execute("BEGIN;")

            # Call the stored procedure with the refcursor
            cur.execute("""
                CALL admin.uspcheckuser(
                    %s, %s, NULL, %s
                );
            """, (
                credentials.username,    # par_username
                credentials.password,    # par_password
                refcursor_name           # par_ref (the refcursor name)
            ))

            # Fetch the data from the refcursor
            cur.execute(f"FETCH ALL FROM {refcursor_name};")
            result = cur.fetchall()

            # Check if result is empty or not
            if result:
                # Assuming that the result set is a tuple (usercode, custcode, orgcode, username, userrole)
                # Extract values from the tuple
                user_info = result[0]  # Fetch the first tuple from the result set
                
                # Map values directly from the tuple
                usercode, custcode, orgcode, username, userrole = user_info

                return ResponseStatus(
                    status="S001",
                    usercode=usercode,
                    custcode=custcode,
                    orgcode=orgcode,
                    username=username,
                    userrole=userrole
                )
            else:
                return ResponseStatus(status="F001")

    except psycopg2.Error as e:
        if conn:
            conn.rollback()
        raise HTTPException(status_code=500, detail=f"Database error: {e}")
    
    finally:
        # Commit and close the connection
        if conn:
            conn.commit()
            conn.close()


@app.post("/ExcelSchoolAI/UnitPlan/generate-pdf-from-html")
async def generate_pdf_from_html(content: HTMLContent):
    try:
        async with async_playwright() as p:
            browser = await p.chromium.launch()
            page = await browser.new_page()

            # Set a viewport that resembles a standard document width
            await page.set_viewport_size({"width": 1200, "height": 800})

            await page.set_content(content.html, wait_until='networkidle')

            pdf_bytes = await page.pdf(
                format="A4",
                print_background=True,
                margin={"top": "25mm", "bottom": "25mm", "left": "25mm", "right": "25mm"},
                scale=0.7 # Adjust scale to fit content better on the page
            )
            await browser.close()

            return StreamingResponse(
                io.BytesIO(pdf_bytes),
                media_type="application/pdf",
                headers={"Content-Disposition": "attachment; filename=LP_UnitPlan.pdf"}
            )
    except Exception as e:
        logger.error(f"PDF generation error: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail={
                "status": "error",
                "message": f"Failed to generate PDF: {str(e)}"
            }
        )


if __name__ == "__main__":
    import uvicorn
    # uvicorn.run(app, host="0.0.0.0", port=8060)
    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("FLASK_RUN_PORT_UNITPLAN", 8061)))
