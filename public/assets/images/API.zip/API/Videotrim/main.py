import os
import subprocess
import shutil
from fastapi import FastAPI, UploadFile, File, Form, BackgroundTasks, Query
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from typing import List
import ffmpeg
import uuid
import json
import yt_dlp
import httpx
from datetime import datetime

# --- Selenium Imports ---
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import pickle
import time
from dotenv import load_dotenv

import asyncio
import logging
import sys
from pathlib import Path

from concurrent.futures import ThreadPoolExecutor

# --- Logging configuration (add file log for job status) ---
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("job_status.log")
    ]
)
logger = logging.getLogger(__name__)

# --- Load env vars and configure ffmpeg path ---
load_dotenv()
FFMPEG_PATH = os.getenv('FFMPEG_PATH', 'ffmpeg')
os.environ["FFMPEG_BINARY"] = FFMPEG_PATH

if FFMPEG_PATH != "ffmpeg" and not os.path.isfile(FFMPEG_PATH):
    logging.error(f"FFMPEG_PATH not found: {FFMPEG_PATH}")
    raise FileNotFoundError(f"ffmpeg binary not found at: {FFMPEG_PATH}")

def verify_ffmpeg():
    """Check that ffmpeg binary exists and is executable."""
    if FFMPEG_PATH == 'ffmpeg':
        logger.info("Using system ffmpeg. Make sure it is in PATH.")
        return
    if not os.path.isfile(FFMPEG_PATH):
        logger.error(f"FFMPEG_PATH does not exist or is not a file: {FFMPEG_PATH}")
        raise FileNotFoundError(f"ffmpeg binary not found at: {FFMPEG_PATH}")
    logger.info(f"Using ffmpeg binary at: {FFMPEG_PATH}")

verify_ffmpeg()

# --- Chrome config ---
SELENIUM_COOKIES_PATH = "files/cookies.pkl"
SELENIUM_CHROME_PATH = os.getenv('SELENIUM_CHROME_PATH', r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe")
SELENIUM_DRIVER_PATH = os.getenv('SELENIUM_DRIVER_PATH', r"F:\SarasApplicationDeployment\ExcelSchoolAI\Service\Video_Trim\chromedriver-win64\chromedriver.exe")

YOUTUBE_LOGIN_URL = "https://accounts.google.com/ServiceLogin?service=youtube"
YOUTUBE_URL = "https://www.youtube.com"

YOUTUBE_EMAIL = os.getenv("YOUTUBE_EMAIL")
YOUTUBE_PASSWORD = os.getenv("YOUTUBE_PASSWORD")

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR = "files"
PROCESSED_DIR = "processed"
CLIPS_DIR = "temp"

os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(PROCESSED_DIR, exist_ok=True)
os.makedirs(CLIPS_DIR, exist_ok=True)
os.makedirs("status", exist_ok=True)

# --- Status tracking helpers ---
def set_status(user, job_id, status, extra=None):
    status_dir = Path("status")
    status_file = status_dir / f"{user}_{job_id}.json"
    payload = {"status": status}
    if extra:
        payload.update(extra)
    with open(status_file, "w") as f:
        json.dump(payload, f)
    logger.info(f"JobStatus: user={user} job_id={job_id} status={status} extra={extra}")

def get_status(user, job_id):
    status_file = Path("status") / f"{user}_{job_id}.json"
    if status_file.exists():
        with open(status_file) as f:
            return json.load(f)
    return {"status": "not_found"}

def get_youtube_cookies_and_driver(headless=True):
    logger.info("Starting Selenium to get YouTube cookies...")
    chrome_options = Options()
    if headless:
        chrome_options.add_argument("--headless=new")
    chrome_options.add_argument("--disable-gpu")
    chrome_options.add_argument("--log-level=3")
    chrome_options.add_argument("--window-size=1920,1080")
    chrome_options.binary_location = SELENIUM_CHROME_PATH

    service = Service(executable_path=SELENIUM_DRIVER_PATH)
    driver = webdriver.Chrome(service=service, options=chrome_options)
    driver.get(YOUTUBE_URL)
    time.sleep(2)

    try:
        driver.find_element(By.XPATH, "//button[contains(@aria-label, 'Account')]")
        print("Already logged in to YouTube.")
    except Exception:
        print("Logging in to YouTube...")
        driver.get(YOUTUBE_LOGIN_URL)
        wait = WebDriverWait(driver, 20)

        with open("debug_youtube_login.html", "w", encoding="utf-8") as f:
            f.write(driver.page_source)
        driver.save_screenshot("debug_youtube_login.png")

        # Cookie Consent Overlay
        try:
            consent_button = driver.find_element(By.XPATH, "//button[contains(text(), 'I agree') or contains(text(), 'Accept all')]")
            driver.execute_script("arguments[0].click();", consent_button)
            time.sleep(1)
        except Exception:
            pass

        # Step 1: Enter email
        email_input = wait.until(EC.visibility_of_element_located((By.XPATH, "//input[@type='email']")))
        driver.execute_script("arguments[0].scrollIntoView(true);", email_input)
        email_input.clear()
        email_input.send_keys(YOUTUBE_EMAIL)
        next_btn = wait.until(EC.element_to_be_clickable((By.ID, "identifierNext")))
        driver.execute_script("arguments[0].scrollIntoView(true);", next_btn)
        driver.execute_script("arguments[0].click();", next_btn)
        time.sleep(2)

        # Handle "Choose an account" intermediate page
        if "Choose an account" in driver.page_source:
            try:
                account_btn = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, "div[jsname='Tenzdc']")))
                driver.execute_script("arguments[0].click();", account_btn)
                time.sleep(2)
            except Exception:
                pass

        # Step 2: Enter password
        password_input = wait.until(EC.visibility_of_element_located((By.XPATH, "//input[@type='password']")))
        driver.execute_script("arguments[0].scrollIntoView(true);", password_input)
        password_input.clear()
        password_input.send_keys(YOUTUBE_PASSWORD)
        password_next_btn = wait.until(EC.element_to_be_clickable((By.ID, "passwordNext")))
        driver.execute_script("arguments[0].scrollIntoView(true);", password_next_btn)
        driver.execute_script("arguments[0].click();", password_next_btn)
        time.sleep(5)

    cookies = driver.get_cookies()
    with open(SELENIUM_COOKIES_PATH, "wb") as f:
        pickle.dump(cookies, f)
    print(f"Saved cookies to {SELENIUM_COOKIES_PATH}")
    return cookies, driver

def save_cookies_txt(cookies, path="cookies.txt"):
    with open(path, "w") as f:
        f.write("# Netscape HTTP Cookie File\n")
        f.write("# This file was generated by youtube_cookie_manager.py\n\n")
        for cookie in cookies:
            domain = cookie.get('domain', '')
            flag = "TRUE" if domain.startswith('.') else "FALSE"
            path_ = cookie.get('path', '/')
            secure = "TRUE" if cookie.get('secure', False) else "FALSE"
            expiry = str(int(cookie.get('expiry', 0)))
            name = cookie.get('name', '')
            value = cookie.get('value', '')
            if name and value:
                f.write(f"{domain}\t{flag}\t{path_}\t{secure}\t{expiry}\t{name}\t{value}\n")
    print(f"Cookies exported to {path}")

def fetch_and_save_cookies_and_driver():
    print("Fetching YouTube cookies inside fetch_and_save_cookies_and_driver()...")
    cookies, driver = get_youtube_cookies_and_driver(headless=False)
    print(f"Fetched {len(cookies)} cookies.")
    save_cookies_txt(cookies, path="cookies.txt")
    return driver

def ensure_mp4(input_path):
    output_path = input_path[:-4] + ".fixed.mp4" if input_path.lower().endswith(".mp4") else input_path + ".mp4"
    if os.path.exists(output_path):
        return output_path
    cmd = [
        FFMPEG_PATH, "-y", "-i", input_path,
        "-c:v", "libx264", "-c:a", "aac", "-movflags", "+faststart",
        output_path
    ]
    logger.info(f"Running ffmpeg cmd: {' '.join(cmd)}")
    try:
        proc = subprocess.run(cmd, check=True)
        if proc.returncode != 0:
            raise Exception("ffmpeg failed")
    except Exception as e:
        logger.error(f"ffmpeg re-encode error: {e}")
        raise
    return output_path

def download_youtube_video(youtube_url, outtmpl):
    print("Using ffmpeg at:", FFMPEG_PATH)
    ydl_opts = {
        'ffmpeg_location': FFMPEG_PATH,
        'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/mp4',
        'merge_output_format': 'mp4',
        'outtmpl': outtmpl,
        'cookiefile': 'cookies.txt',
        'user_agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.7339.128 Safari/537.36',
    }
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        ydl.download([youtube_url])

MAX_CONCURRENT_FFMPEG = int(os.getenv("MAX_CONCURRENT_FFMPEG", 1))
ffmpeg_executor = ThreadPoolExecutor(max_workers=MAX_CONCURRENT_FFMPEG)

def run_ffmpeg_subprocess(cmd):
    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        stdout, stderr = proc.communicate()
        if proc.returncode != 0:
            logger.error(f"FFmpeg failed: {stderr.decode()}")
            raise Exception(stderr.decode())
        return stdout.decode(), stderr.decode()
    finally:
        if proc and proc.poll() is None:
            proc.terminate()
        del proc

def delete_all_files(directory_path):
    try:
        for filename in os.listdir(directory_path):
            file_path = os.path.join(directory_path, filename)
            if os.path.isfile(file_path):
                os.remove(file_path)
                print(f"Deleted: {file_path}")
    except OSError as e:
        print(f"Error deleting files in {directory_path}: {e}")

def delete_directory(directory_path):
    if os.path.exists(directory_path):
        try:
            shutil.rmtree(directory_path)
            print(f"Deleted user upload directory: {directory_path}")
        except Exception as e:
            print(f"Error deleting user upload directory: {e}")
    else:
        print(f"User upload directory does not exist: {directory_path}")

# --- Endpoints ---

@app.post("/ExcelSchooAI/videotrimer/upload")
async def upload_video(
    youtube_url: str = Form(None),
    file: UploadFile = File(None),
    username: str = Form(...),
    background_tasks: BackgroundTasks = None,
):
    username = username.strip()
    user_upload_base_dir = os.path.join(UPLOAD_DIR, username)
    os.makedirs(user_upload_base_dir, exist_ok=True)
    user_upload_dir = os.path.join(user_upload_base_dir, "uploads")
    os.makedirs(user_upload_dir, exist_ok=True)

    if youtube_url:
        job_id = str(uuid.uuid4())
        outtmpl = os.path.join(user_upload_dir, f'{job_id}.mp4')
        set_status(username, job_id, "queued", {"video_path": outtmpl})

        def download_task():
            try:
                driver = fetch_and_save_cookies_and_driver()
                download_youtube_video(youtube_url, outtmpl)
                driver.quit()
                if not os.path.exists(outtmpl):
                    raise Exception('Video file not found after download')
                set_status(username, job_id, "done", {"video_path": outtmpl})
            except Exception as e:
                logger.error(f"Error downloading video: {e}", exc_info=True)
                set_status(username, job_id, "error", {"error": str(e)})

        if background_tasks:
            background_tasks.add_task(download_task)
            return {"job_id": job_id, "status": "queued"}
        else:
            download_task()
            return {"job_id": job_id, "status": get_status(username, job_id)["status"]}
    elif file:
        job_id = str(uuid.uuid4())
        out_file = os.path.join(user_upload_dir, f"{job_id}_{file.filename}")
        with open(out_file, "wb") as f:
            shutil.copyfileobj(file.file, f)
        set_status(username, job_id, "done", {"video_path": out_file})
        return {"job_id": job_id, "video_path": out_file, "status": "done"}
    else:
        return JSONResponse(status_code=400, content={"error": "No input provided"})

@app.get("/ExcelSchooAI/videotrimer/uploadstatus")
def upload_status(username: str, job_id: str):
    return get_status(username, job_id)

@app.post("/ExcelSchooAI/videotrimer/saveClip")
async def save_clip(
    start_time: float = Form(...),
    end_time: float = Form(...),
    video_path: str = Form(...),
    username: str = Form(...),
    background_tasks: BackgroundTasks = None,
):
    username = username.strip()
    video_clips_dir = os.path.join(UPLOAD_DIR, username, "video_clips")
    os.makedirs(video_clips_dir, exist_ok=True)

    if end_time <= start_time:
        return JSONResponse(status_code=400, content={"error": "End time must be greater than start time"})

    fixed_video_path = os.path.join(r"./", video_path)
    if not os.path.exists(fixed_video_path):
        return JSONResponse(status_code=404, content={"error": f"Video file not found: {fixed_video_path}"})

    job_id = str(uuid.uuid4())
    clip_path = os.path.join(video_clips_dir, f"{job_id}_clip.mp4")
    ffmpeg_path = r"C:\ffmpeg\bin\ffmpeg.exe"

    def ffmpeg_task():
        set_status(username, job_id, "processing", {"clip_path": clip_path})
        try:
            run_ffmpeg_subprocess([
                ffmpeg_path,
                "-y",
                "-ss", str(start_time),
                "-i", fixed_video_path,
                "-t", str(end_time - start_time),
                "-c:v", "libx264",
                "-c:a", "aac",
                "-movflags", "+faststart",
                clip_path
            ])
            set_status(username, job_id, "done", {"clip_path": clip_path})
        except Exception as e:
            logger.error(f"General error in save_clip: {e}", exc_info=True)
            set_status(username, job_id, "error", {"error": str(e), "clip_path": clip_path})

    if background_tasks:
        set_status(username, job_id, "queued", {"clip_path": clip_path})
        background_tasks.add_task(ffmpeg_task)
        return {"job_id": job_id, "clip_path": clip_path, "status": "queued"}
    else:
        ffmpeg_task()
        return {"job_id": job_id, "clip_path": clip_path, "status": get_status(username, job_id)["status"]}

@app.get("/ExcelSchooAI/videotrimer/jobstatus")
def job_status(username: str, job_id: str):
    return get_status(username, job_id)

def reencode_clip(input_path, output_path):
    ffmpeg_path = r"C:\ffmpeg\bin\ffmpeg.exe"
    cmd = [
        ffmpeg_path,
        "-y",
        "-i", input_path,
        "-c:v", "libx264",
        "-c:a", "aac",
        "-vf", "scale=1280:720",
        "-r", "30",
        output_path
    ]
    stdout, stderr = run_ffmpeg_subprocess(cmd)

@app.post("/ExcelSchooAI/videotrimer/clipsPreview")
async def process_video(
    clips: str = Form(...),
    isSSO: str = Form("false"),
    username: str = Form(...),
    background_tasks: BackgroundTasks = None,
):
    clips = json.loads(clips)
    job_id = str(uuid.uuid4())
    out_path = os.path.join(PROCESSED_DIR, f"{job_id}.mp4")
    print(f"Output path: {out_path}")
    files_to_concat = [clip['clipFile'] for clip in clips]

    uniform_files_to_concat = []
    for idx, fp in enumerate(files_to_concat):
        uniform_fp = os.path.join(PROCESSED_DIR, f"uniform_{idx}_{uuid.uuid4()}.mp4")
        reencode_clip(fp, uniform_fp)
        uniform_files_to_concat.append(uniform_fp)

    def concat_task():
        set_status(username, job_id, "processing", {"file_path": out_path})
        try:
            if len(uniform_files_to_concat) > 1:
                concat_file = os.path.join(PROCESSED_DIR, f"{uuid.uuid4()}_concat.txt")
                with open(concat_file, "w") as f:
                    for fp in uniform_files_to_concat:
                        f.write(f"file '{os.path.abspath(fp)}'\n")
                ffmpeg_path = r"C:\ffmpeg\bin\ffmpeg.exe"
                cmd = [
                    ffmpeg_path,
                    "-y",
                    "-f", "concat",
                    "-safe", "0",
                    "-i", concat_file,
                    "-c", "copy",
                    out_path
                ]
                stdout, stderr = run_ffmpeg_subprocess(cmd)
                os.remove(concat_file)
            elif len(uniform_files_to_concat) == 1:
                shutil.copy(uniform_files_to_concat[0], out_path)
            else:
                set_status(username, job_id, "error", {"error": "No valid clips to process."})
                return
            set_status(username, job_id, "done", {"file_path": out_path})
        except Exception as e:
            logger.error(f"ffmpeg error in clipsPreview: {e}", exc_info=True)
            set_status(username, job_id, "error", {"error": str(e)})

    if background_tasks:
        set_status(username, job_id, "queued", {"file_path": out_path})
        background_tasks.add_task(concat_task)
        return {"job_id": job_id, "file_path": out_path, "status": "queued"}
    else:
        concat_task()
        return {"job_id": job_id, "file_path": out_path, "status": get_status(username, job_id)["status"]}

@app.post("/ExcelSchooAI/videotrimer/download")
async def download_video(
    filename: str = Form(...),
    username: str = Form(...)
):
    file_path = os.path.join(PROCESSED_DIR, filename)
    print("Cleaning up temporary files for user")
    file_path_to_delete = os.path.join(UPLOAD_DIR, username)
    delete_directory(file_path_to_delete)
    print(f"Downloading file: {file_path}")
    return FileResponse(file_path, media_type="video/mp4", filename="output.mp4")

@app.get("/ExcelSchooAI/videotrimer/uploaded_video")
async def get_uploaded_video(video_path: str):
    safe_path = video_path.replace("\\", "/")
    safe_path = os.path.normpath(safe_path).replace("..", "")
    if not (safe_path.startswith("uploads/") or safe_path.startswith("uploads\\")):
        return JSONResponse(status_code=400, content={"error": "Invalid path"})
    full_path = os.path.join(os.getcwd(), safe_path)
    if not os.path.exists(full_path):
        return JSONResponse(status_code=404, content={"error": "Video not found"})
    return FileResponse(full_path, media_type="video/mp4")

@app.get("/ExcelSchooAI/videotrimer/video")
async def get_video(video_path: str = Query(..., description="Path to the video file")):
    safe_path = os.path.normpath(video_path)
    abs_path = os.path.abspath(safe_path)
    if not os.path.exists(abs_path):
        return JSONResponse(status_code=404, content={"error": "Video not found"})
    return FileResponse(abs_path, media_type="video/mp4")

@app.on_event("shutdown")
def shutdown_event():
    logger.info("Shutting down ffmpeg executor...")
    ffmpeg_executor.shutdown(wait=True)
    logger.info("FFmpeg executor shut down.")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("FLASK_RUN_PORT_VIDEOTRIM", 8063)))